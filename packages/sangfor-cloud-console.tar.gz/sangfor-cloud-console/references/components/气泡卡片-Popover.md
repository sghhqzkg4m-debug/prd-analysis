---
name: "云 BG 设计规范 - 基础组件 - 气泡卡片（Popover）"
description: "提供气泡卡片组件的设计规范、最佳实践，依赖 skills/sxf-cloud-design-system/SKILL.md 中定义的设计规范。当用户需要设计或实现气泡卡片组件时调用。"
step:
  1. 需求解析：理解用户需要创建的气泡卡片类型（基础气泡卡片、带标题气泡卡片、确认气泡卡片）
  2. 视觉设计：所有样式优先使用本技能文档预定义的尺寸规范和颜色规范，未定义部分则使用 skills/sxf-cloud-design-system/SKILL.md 中定义的设计规范
  3. 代码生成：按规范生成完整的 HTML、CSS 和 JavaScript 代码

ai_instructions:
  icon_usage_rules:
    - "必须使用本文档指定的图标类名，严禁使用其他图标替代"
    - "图标前缀统一为 vtv-icon-"
    - "严禁根据语义自行搜索图标，必须按清单使用"
  forbidden_substitutions:
    - "关闭图标：必须使用 vtv-icon-close-line，严禁使用 close、x 等"
    - "确认图标：必须使用 vtv-icon-help-circle，严禁使用 question、info 等"
  checklist_before_generate:
    - "确认所有图标类名与图标清单一致"
    - "确认图标前缀为 vtv-icon-"
    - "确认没有使用任何通用图标替代组件专用图标"

---

# 气泡卡片 Popover

> ⚠️ **图标使用强制声明**：本组件所有图标必须使用下表指定的图标类名，**严禁**使用 `close`、`x`、`question` 等通用图标替代。

## 图标清单（强制）

| 位置 | 图标类名 | 尺寸 | 颜色 | 严禁使用 |
|------|----------|------|------|----------|
| 关闭按钮 | `vtv-icon-close-line` | 16px | `gray.d40` | `close`, `x`, `times` |
| 确认图标 | `vtv-icon-help-circle` | 16px | `golden-yellow.default` | `question`, `info`, `help` |

## 概述

气泡卡片是一种轻量级的浮层组件，用于显示目标元素的详细内容或操作选项。它通过箭头指向触发元素，建立明确的视觉关联。

- **来源**：深信服云 BG 设计部
- **类型**：基础交互组件
- **适用场景**：信息展示、操作确认、快捷菜单、提示说明等

### 使用场景

| 变体 | 适用场景 | 示例 |
|------|---------|------|
| **基础气泡卡片** | 展示额外信息 | 用户详情、数据预览、快捷说明 |
| **带标题气泡卡片** | 需要标题栏的场景 | 操作菜单、设置选项 |
| **确认气泡卡片** | 二次确认操作 | 删除确认、保存确认 |

### 组件结构

| 子组件 | 功能 | 是否必需 |
|--------|------|----------|
| Popover | 气泡卡片主容器 | 必需 |
| PopoverHeader | 标题栏 | 可选 |
| PopoverContent | 内容区域 | 必需 |
| PopoverFooter | 底部操作区 | 可选 |
| Arrow | 箭头指示器 | 必需 |
| CloseButton | 关闭按钮 | 可选 |

## 视觉设计规范

### 颜色规范

#### 基础样式（所有变体共用）

| 元素 | 属性 | Token |
|------|------|-------|
| 容器 | background | `gray.l60` |
| 容器 | border | `blue-gray.l10` |
| 容器 | box-shadow | `shadow.lg` |
| 容器 | border-radius | `radius.default` |
| 内容文字 | color | `gray.d50` |
| 箭头 | border | `blue-gray.l10` |
| 箭头填充 | background | `gray.l60` |

#### 变体特定样式

**带标题气泡卡片**：

| 元素 | 属性 | Token |
|------|------|-------|
| 标题栏 | background | `blue-gray.l50` |
| 标题栏 | border-bottom | `blue-gray.l10` |
| 关闭按钮 | color | `gray.d40` |
| 关闭按钮悬浮 | color | `gray.d50` |

**确认气泡卡片**：

| 元素 | 属性 | Token |
|------|------|-------|
| 图标 | color | `golden-yellow.default` |
| 标题 | font-weight | 500 |
| 描述文字 | color | `gray.d40` |
| 描述文字 | font-size | 12px |

### 尺寸规范

#### 默认尺寸 (Normal)

| 元素 | 尺寸 | 说明 |
|------|------|------|
| 卡片宽度 | 最小 200px，最大 400px | 自适应内容 |
| 内边距 | 8px 16px | 内容区域内边距（上下8px，左右16px） |
| 标题栏高度 | 44px | 标题栏固定高度 |
| 标题栏内边距 | 0 16px | 标题栏水平内边距 |
| 圆角 | 4px (`radius.sm`) | 小圆角规格 |
| 箭头尺寸 | 8px | 等腰直角三角形 |
| 字体 | 14px | 字体大小 |
| 行高 | 20px | 行高规格 |

#### 小尺寸 (Small)

| 元素 | 尺寸 | 说明 |
|------|------|------|
| 卡片宽度 | 最小 160px，最大 280px | 适用于简单提示 |
| 内边距 | 4px 8px | 内容区域内边距（上下4px，左右8px） |
| 圆角 | 2px | 小圆角规格 |
| 箭头尺寸 | 6px | 等腰直角三角形 |
| 字体 | 12px | 字体大小 |
| 行高 | 17px | 行高规格 |

### 箭头位置规范

气泡卡片支持 12 种箭头位置，覆盖四个方向的三个位置。

| 方向 | CSS类名模式 | 箭头方向 |
|------|------------|---------|
| 上 | `popover-top[-left\|-right]` | 向下 |
| 下 | `popover-bottom[-left\|-right]` | 向上 |
| 左 | `popover-left[-top\|-bottom]` | 向右 |
| 右 | `popover-right[-top\|-bottom]` | 向左 |

**默认位置**：`popover-top-left`（向左上角）
**偏移位置**：使用 `-left`、`-right`、`-top`、`-bottom` 后缀

## 交互设计规范

### 状态定义

| 状态 | 表现 | 说明 |
|------|------|------|
| 默认状态 | 卡片隐藏，触发元素正常显示 | 初始状态 |
| 悬浮状态 | 卡片显示，箭头指向触发元素 | 鼠标悬浮触发 |
| 点击状态 | 卡片显示，点击外部关闭 | 点击触发 |
| 聚焦状态 | 卡片显示，支持键盘导航 | Tab 键聚焦 |
| 关闭状态 | 卡片隐藏，支持动画过渡 | 关闭动画 |

### 触发与关闭方式

| 类型 | 支持方式 | 说明 |
|------|---------|------|
| 触发方式 | hover / click / focus | 悬浮、点击、聚焦 |
| 关闭方式 | 点击外部、关闭按钮、ESC 键 | 多种关闭途径 |
| 悬浮延迟 | 显示 100ms，隐藏 200ms | 防止闪烁 |
| 动画过渡 | 200ms ease-in-out | 显示/隐藏过渡 |

### 键盘导航

| 按键 | 行为 |
|------|------|
| `Tab` | 在气泡卡片内焦点循环 |
| `Escape` | 关闭气泡卡片 |
| `Enter/Space` | 激活焦点元素 |

## 可访问性规范

| 属性 | 值 | 说明 |
|------|-----|------|
| `role` | `dialog` | 气泡卡片角色 |
| `aria-modal` | `true` | 模态行为 |
| `aria-labelledby` | 标题ID | 关联标题 |
| `aria-describedby` | 内容ID | 关联内容 |
| `aria-hidden` | `true`/`false` | 控制可见性 |

## Ant Design 集成

| 属性 | Ant Design Popover | 本规范对应 |
|------|-------------------|-----------|
| `trigger` | `hover` \| `click` \| `focus` | 触发方式 |
| `placement` | `top` \| `bottom` \| `left` \| `right` | 气泡位置 |
| `title` | `ReactNode` | popover-header |
| `content` | `ReactNode` | popover-content |
| `arrow` | `boolean` \| `{ pointAtCenter: boolean }` | 默认显示 |

## 参数配置

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| trigger | `hover` \| `click` \| `focus` | `hover` | 触发方式 |
| placement | `top` \| `bottom` \| `left` \| `right` | `top` | 气泡位置 |
| size | `small` \| `normal` | `normal` | 尺寸规格 |
| title | `string` | - | 标题（可选） |
| content | `string` \| `ReactNode` | - | 内容区域 |
| showClose | `boolean` | `false` | 显示关闭按钮 |
| showArrow | `boolean` | `true` | 显示箭头指示器 |

## 最佳实践

### 命名规范

- **组件集**：`componentset-popover`
- **变体/示例**：
  - `popover-basic` - 基础气泡卡片
  - `popover-with-title` - 带标题气泡卡片
  - `popover-confirm` - 确认气泡卡片

### 使用原则

1. **信息层级**：气泡卡片用于展示次要信息，不应包含过多内容
2. **触发明确**：确保用户能够明确知道哪个元素触发了气泡卡片
3. **位置合理**：箭头应准确指向触发元素，避免遮挡重要内容
4. **关闭便捷**：提供多种关闭方式，确保用户体验流畅
5. **内容简洁**：气泡卡片内容应简洁明了，避免长文本

## 高约束规则

> **生成器必须严格遵守以下规则，违反将导致样式错误。**

### 引用触发条件

当在其他组件文档或生成代码中，识别到以下关键词时，**必须**引用本气泡卡片文档：
- "气泡卡片"、"popover"
- "浮层提示"、"tooltip"
- "确认框"、"confirm"
- "快捷菜单"

### 强制遵守要求

| 要求 | 说明 |
|------|------|
| **禁止自定义颜色** | 颜色值**必须**从本文档「颜色规范」表格中选取，禁止自行推断或使用其他色值 |
| **禁止自定义尺寸** | 尺寸**必须**严格遵循本文档「尺寸规范」，包括宽度、内边距、箭头尺寸 |
| **禁止省略箭头** | 气泡卡片必须包含箭头指示器，建立与触发元素的视觉关联 |
| **禁止错误位置** | 箭头位置必须准确指向触发元素，不能偏移或错位 |
| **图标来源强制** | 所有图标**必须**使用 SKILL 自带的 SVG Symbol 图标系统，Symbol ID 格式为 `vtv-icon-{图标名}` |

### 常见错误

| 错误类型 | 错误示例 | 正确做法 |
|---------|---------|---------|
| 硬编码颜色 | `background: #fff` | `background: var(--color-gray-l60)` |
| 省略箭头 | 无箭头元素 | 必须包含箭头指示器 |
| 错误阴影 | `shadow.md` | 必须使用 `shadow.lg` |
| 错误图标 | `vtv-icon-close` | `vtv-icon-close-line` |

### 验证清单

生成气泡卡片样式后，逐项核对：
- [ ] 颜色是否来自文档规定的 CSS 变量
- [ ] 尺寸是否符合尺寸规范表（宽度、内边距、箭头尺寸）
- [ ] 是否包含箭头指示器
- [ ] 箭头位置是否准确指向触发元素
- [ ] 阴影是否使用 `shadow.lg`
- [ ] 所有图标是否使用 SKILL 自带的 SVG Symbol 图标系统

## 关联文档

- [颜色规范](../../design-system.md)
- [阴影系统](../../design-system.md)
- [圆角系统](../../design-system.md)
- [按钮组件](./按钮-Button.md)
