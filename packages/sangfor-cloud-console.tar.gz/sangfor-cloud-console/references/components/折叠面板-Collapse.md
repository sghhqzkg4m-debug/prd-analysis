---
name: "云BG设计规范-基础组件-折叠面板（Collapse）"
description: "提供折叠面板组件的设计规范、交互规则与最佳实践，依赖skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。当用户需要设计或实现折叠面板、分组折叠或卡片折叠时调用。"
step:
  1. 需求解析：确认折叠类型（card/group）、视觉样式（border/shadow）、卡片头高（64px/80px）、是否手风琴、是否含图标/副标题/详情内容。
  2. 视觉设计：严格使用本文档中的尺寸、颜色、间距、圆角、边框、投影和状态，不自行推导折叠头高度或图标尺寸。
  3. 代码生成：按本文档 HTML/CSS 结构生成折叠面板，保证同一折叠组内类型、尺寸和交互模式一致。
---

# 折叠面板 Collapse

## 来源与适用范围

折叠面板用于组织可展开/收起的信息区域，适合云资源配置、硬件详情、FAQ、配置分组等场景。

本规范参考 Cloud Design 线上组件页：

- `basic-components / class-data-display / collapse`
- `er-pro/card-collapse`
- `er-pro/group-collapse`

完整静态示例见仓库根目录：`examples/collapse-examples.html`。

读取本文件生成折叠面板时，必须优先判断使用 **卡片折叠** 还是 **分组折叠**。不要继续使用旧的单一 48px 折叠头、统一边框容器或临时箭头图标方案。

## 组件能力

### 类型枚举

| 类型 | 推荐 class / 组件 | 结构特征 | 适用场景 |
| --- | --- | --- | --- |
| 卡片折叠 | `.cloud-collapse-card` / `CardCollapse` | 每个面板是独立卡片，支持 border / shadow 两种外观，支持图标、标题、副标题 | 资源模块、配置模块、详情页模块 |
| 分组折叠 | `.cloud-collapse-group` / `GroupCollapse` | 同组内连续排列，左侧 plus/minus 图标，内容区左侧有虚线引导线 | 硬件配置、层级详情、轻量设置分组 |

### 尺寸枚举

| 类型 | 尺寸名 | class | 折叠头高度 | 图标区域 | 标题字号 | 说明 |
| --- | --- | --- | ---: | ---: | --- | --- |
| 卡片折叠 | 80px 头高 | `.collapse--head-80` | 80px | 48px × 48px | 14px / 20px | 适合标题+副标题+48px 图标 |
| 卡片折叠 | 64px 头高 | `.collapse--head-64` | 64px | 40px × 40px / 可无图标 | 14px / 20px | 信息较密集的卡片模块 |
| 分组折叠 | 常规 | `.collapse--medium` | min-height 40px | 16px icon | 14px | 默认分组折叠 |
| 分组折叠 | 小尺寸 | `.collapse--small` | min-height 32px | 16px icon | 12px | 高密度配置项 |

同一个折叠组容器内不要混用不同类型和不同尺寸。业务确实需要混排时，拆成多个折叠区域。

### 展开模式

| 模式 | 参数 | 说明 |
| --- | --- | --- |
| 多项展开 | `accordion=false` | 默认模式，可同时展开多个面板 |
| 手风琴 | `accordion=true` | 同一组内同时只展开一个面板 |
| 受控展开 | `v-model` / `value` | 外部控制当前展开项 |
| 独立展开 | `CollapseItem.value` | 单个卡片项独立控制展开状态 |

## 尺寸规范

### 卡片折叠容器

| 属性 | 值 |
| --- | --- |
| 面板背景 | `var(--color-blue-gray-l60)` |
| 卡片圆角 | 2px |
| 相邻面板间距 | 8px / `var(--spacing-xs)` |
| border 外观 | `1px solid var(--color-blue-gray-l10)` |
| shadow 外观 | `0px 1px 4px 0px rgba(0, 0, 0, 0.08)` |
| 内容溢出 | `overflow: hidden` |

### 卡片折叠头

| 尺寸 | 头部最小高度 | 头部 padding | 左侧图标 | 图标与标题间距 | 右侧操作图标 |
| --- | ---: | --- | ---: | ---: | ---: |
| 80px 头高 | 80px | 上下 16px / 左右 20px | 48px × 48px | 16px | 24px |
| 64px 头高 | 64px | 上下 12px / 左右 16px | 40px × 40px / 可无图标 | 12px | 24px |

说明：

- 卡片折叠头可包含图标、标题、副标题和右侧箭头。
- 标题区域最大宽度需扣除图标、右侧箭头和间距，避免撑开布局。
- 80px 头高卡片图标固定 48px，操作区按钮使用 32px 默认尺寸按钮；64px 头高卡片图标固定 40px，操作区按钮使用 24px 小尺寸按钮。
- 右侧展开图标固定 24px，使用 `vtv-icon-arrow-down` / `vtv-icon-arrow-up`。
- 卡片头底部分割通过 `box-shadow: 0 1px 0 0 var(--color-blue-gray-l30)` 表达，不额外叠加粗边框。

### 卡片折叠内容

| 尺寸 | 内容 padding | 内容背景 | 说明 |
| --- | --- | --- | --- |
| 常规 | 上下 16px / 左右 20px | 跟随卡片背景 | 用于配置详情、说明、表格片段 |
| 小尺寸 | 16px | 跟随卡片背景 | 用于简短内容 |

内容区承载表格时必须遵循 `基础表格-basicTable.md` 的小尺寸表格规则：表头 26px、内容行 32px、表头上下边框、表体仅下边框、12px 字号。

### 分组折叠

| 属性 | 常规 | 小尺寸 | 说明 |
| --- | ---: | ---: | --- |
| 头部最小高度 | 40px | 32px | 分组折叠比卡片折叠更紧凑 |
| 标题字号 | 14px | 12px | 常规用 `font-size-m`，小尺寸用 `font-size-s` |
| 标题字重 | 500 | 500 | 保持可识别层级 |
| 左侧图标尺寸 | 16px | 16px | plus/minus 图标 |
| 图标右间距 | 8px | 8px | 图标与标题间距 |
| 内容左内边距 | 24px | 24px | 给虚线引导线和层级留空间 |
| 引导线位置 | left 7px | left 7px | 内容区左侧虚线 |

## 颜色规范

| 元素 | 颜色 | Token / 说明 |
| --- | --- | --- |
| 卡片背景 | `var(--color-blue-gray-l60)` | 卡片折叠项底色 |
| 卡片头背景 | `var(--color-white)` | 折叠头白底 |
| 卡片标题 | `var(--color-gray-d50)` | 主标题 |
| 卡片副标题 | `var(--color-gray-d30)` | 次级说明 |
| 卡片头分割线 | `var(--color-blue-gray-l30)` | 使用 1px shadow |
| border 描边 | `var(--color-blue-gray-l10)` | 卡片 border 外观 |
| shadow 投影 | `0px 1px 4px 0px rgba(0, 0, 0, 0.08)` | 卡片 shadow 外观 |
| 分组标题 | `var(--color-gray-d40)` | 分组折叠标题 |
| 分组图标 | `var(--color-blue-gray-d30)` | plus/minus 默认色 |
| 分组引导线 | `var(--color-blue-gray-d30)` | 内容区虚线 |
| Hover 背景 | 卡片头保持白底；分组头可用 `#F5F6F8` | 卡片头避免与展开内容区融合 |
| Focus | `#1770E6` 或等效 focus ring | 键盘聚焦态 |
| Disabled | 透明度 50% 或文本灰化 | 禁用态不响应 hover |

## 状态规范

| 状态 | 卡片折叠 | 分组折叠 |
| --- | --- | --- |
| Default | 展示标题、副标题、向下箭头；未展开内容隐藏 | plus 图标，内容隐藏 |
| Hover | 卡片头底色不变化，鼠标为 pointer | 头部可轻微变浅灰，鼠标为 pointer |
| Active / Expanded | 右侧箭头改为向上，内容显示 | 图标从 plus 变为 minus，内容显示 |
| Disabled | 整项透明度 50%，鼠标 not-allowed | 整项透明度 50%，鼠标 not-allowed |
| Focus | 头部出现 1px 主色描边或等效 focus ring | 头部出现 1px 主色描边或等效 focus ring |

## DOM 结构

### 卡片折叠

生成时必须使用稳定结构，方便样式复用：

```html
<div class="cloud-collapse-card collapse--head-80 collapse--border">
  <section class="cloud-collapse-card-item is-open">
    <button class="cloud-collapse-card-header" type="button" aria-expanded="true">
      <span class="cloud-collapse-card-icon">
        <svg class="icon" aria-hidden="true"><use href="#vtv-icon-resource-adiministration"></use></svg>
      </span>
      <span class="cloud-collapse-card-text">
        <span class="cloud-collapse-card-title">卡片1的标题</span>
        <span class="cloud-collapse-card-subtitle">卡片1的副标题</span>
      </span>
      <span class="cloud-collapse-card-actions">
        <span class="cloud-collapse-action">Norm</span>
        <span class="cloud-collapse-action">Norm</span>
        <span class="cloud-collapse-action cloud-collapse-action--icon" aria-label="更多">
          <svg class="icon" aria-hidden="true"><use href="#vtv-icon-comp-more"></use></svg>
        </span>
      </span>
      <svg class="icon cloud-collapse-card-arrow" aria-hidden="true">
        <use href="#vtv-icon-arrow-up"></use>
      </svg>
    </button>
    <div class="cloud-collapse-card-content">
      卡片1的内容
    </div>
  </section>
</div>
```

结构要求：

- 容器固定使用 `.cloud-collapse-card`。
- 面板固定使用 `.cloud-collapse-card-item`。
- 头部固定使用 `.cloud-collapse-card-header`，有点击行为时优先使用 `button`。
- 左侧图标区域固定使用 `.cloud-collapse-card-icon`，图标来自 `../../assets/iconfont/icon-symbols.html` 中的 `vtv-icon-*`。
- 文案区域固定使用 `.cloud-collapse-card-text`、`.cloud-collapse-card-title`、`.cloud-collapse-card-subtitle`。
- 右侧操作区固定使用 `.cloud-collapse-card-actions`；更多操作图标使用图标库 `vtv-icon-comp-more`。
- 右侧箭头固定使用 `.cloud-collapse-card-arrow`。
- 内容区域固定使用 `.cloud-collapse-card-content`。

### 分组折叠

```html
<div class="cloud-collapse-group collapse--medium">
  <section class="cloud-collapse-group-item is-active">
    <button class="cloud-collapse-group-header" type="button" aria-expanded="true">
      <svg class="icon cloud-collapse-group-icon" aria-hidden="true">
        <use href="#vtv-icon-minus"></use>
      </svg>
      <span class="cloud-collapse-group-title">CPU</span>
    </button>
    <div class="cloud-collapse-group-content">
      <dl class="cloud-collapse-detail">
        <dt>型号</dt>
        <dd>3</dd>
      </dl>
    </div>
  </section>
</div>
```

结构要求：

- 容器固定使用 `.cloud-collapse-group`。
- 面板固定使用 `.cloud-collapse-group-item`。
- 头部固定使用 `.cloud-collapse-group-header`。
- 左侧图标固定使用 `.cloud-collapse-group-icon`，展开为 `vtv-icon-minus`，收起为 `vtv-icon-plus`。
- 标题固定使用 `.cloud-collapse-group-title`，复杂标题可在内部放置 icon + label + value。
- 内容固定使用 `.cloud-collapse-group-content`，左侧 24px 内边距和虚线引导线不可省略。

## 标准 CSS

```css
.cloud-collapse-card {
  width: 100%;
}

.cloud-collapse-card-item {
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: var(--color-blue-gray-l60);
  border-radius: 2px;
}

.cloud-collapse-card-item + .cloud-collapse-card-item {
  margin-top: 8px;
}

.collapse--border .cloud-collapse-card-item {
  border: 1px solid var(--color-blue-gray-l10);
}

.collapse--shadow .cloud-collapse-card-item {
  box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, .08);
}

.cloud-collapse-card-header {
  width: 100%;
  min-height: 64px;
  padding: 16px 20px;
  border: 0;
  display: flex;
  align-items: center;
  color: var(--color-gray-d50);
  background: var(--color-white);
  box-shadow: 0 1px 0 0 var(--color-blue-gray-l30);
  text-align: left;
  cursor: pointer;
}

.collapse--head-80 .cloud-collapse-card-header {
  min-height: 80px;
  padding: 16px 20px;
}

.collapse--head-64 .cloud-collapse-card-header {
  min-height: 64px;
  padding: 12px 16px;
}

.cloud-collapse-card-header:focus-visible {
  outline: 1px solid #1770E6;
  outline-offset: -1px;
}

.cloud-collapse-card-icon {
  width: 48px;
  height: 48px;
  flex: 0 0 48px;
  margin-right: 16px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.collapse--head-64 .cloud-collapse-card-icon {
  width: 40px;
  height: 40px;
  flex-basis: 40px;
  margin-right: 12px;
}

.cloud-collapse-card-text {
  min-width: 0;
  max-width: calc(100% - 88px);
  flex: 1 1 auto;
  padding-right: 16px;
}

.cloud-collapse-card-actions {
  flex: 0 0 auto;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-right: 16px;
}

.cloud-collapse-action {
  height: 32px;
  padding: 0 12px;
  border: 1px solid var(--color-blue-gray-l10);
  border-radius: 2px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: var(--color-gray-d50);
  background: var(--color-white);
  font-size: 14px;
  line-height: 20px;
  white-space: nowrap;
}

.cloud-collapse-action--icon {
  width: 32px;
  padding: 0;
}

.collapse--head-64 .cloud-collapse-action {
  height: 24px;
  padding: 0 8px;
  font-size: 12px;
  line-height: 17px;
}

.collapse--head-64 .cloud-collapse-action--icon {
  width: 24px;
}

.cloud-collapse-card-title {
  display: block;
  color: var(--color-gray-d50);
  font-size: 14px;
  line-height: 20px;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.cloud-collapse-card-subtitle {
  display: block;
  margin-top: 4px;
  color: var(--color-gray-d30);
  font-size: 12px;
  line-height: 16px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.cloud-collapse-card-arrow {
  width: 24px;
  height: 24px;
  color: #5F6B7A;
  transition: transform .2s ease;
}

.cloud-collapse-card-item.is-open .cloud-collapse-card-arrow {
  transform: rotate(180deg);
}

.cloud-collapse-card-content {
  padding: 16px 20px;
  overflow: hidden;
}

.collapse--head-64 .cloud-collapse-card-header {
  padding: 12px 16px;
}

.collapse--head-64 .cloud-collapse-card-icon {
  width: 40px;
  height: 40px;
  flex-basis: 40px;
  margin-right: 12px;
}

.collapse--head-64 .cloud-collapse-card-text {
  max-width: calc(100% - 76px);
}

.collapse--head-64 .cloud-collapse-card-content {
  padding: 16px;
}

.cloud-collapse-group {
  width: 100%;
}

.cloud-collapse-group-item {
  display: flex;
  flex-direction: column;
}

.cloud-collapse-group-header {
  width: 100%;
  min-height: 40px;
  padding: 0;
  border: 0;
  display: flex;
  align-items: center;
  color: var(--color-gray-d40);
  background: var(--color-white);
  font-size: 14px;
  font-weight: 500;
  text-align: left;
  cursor: pointer;
}

.cloud-collapse-group-header:hover {
  background: #F5F6F8;
}

.cloud-collapse-group-icon {
  width: 16px;
  height: 16px;
  margin-right: 8px;
  color: var(--color-blue-gray-d30);
  background: var(--color-white);
}

.cloud-collapse-group-title {
  min-width: 0;
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.cloud-collapse-group-content {
  position: relative;
  box-sizing: border-box;
  padding-left: 24px;
  overflow: hidden;
  background: var(--color-white);
}

.cloud-collapse-group-content::before {
  content: "";
  position: absolute;
  top: 0;
  left: 7px;
  height: 100%;
  border-left: 1px dashed var(--color-blue-gray-d30);
}

.collapse--small .cloud-collapse-group-header {
  min-height: 32px;
  font-size: 12px;
}

.cloud-collapse-card-item.is-disabled,
.cloud-collapse-group-item.is-disabled {
  opacity: .5;
  cursor: not-allowed;
}

.cloud-collapse-card-item.is-disabled .cloud-collapse-card-header,
.cloud-collapse-group-item.is-disabled .cloud-collapse-group-header {
  cursor: not-allowed;
}
```

## 使用示例

### 卡片折叠：border 外观

```html
<div class="cloud-collapse-card collapse--head-80 collapse--border" data-collapse>
  <section class="cloud-collapse-card-item is-open" data-panel>
    <button class="cloud-collapse-card-header" type="button" aria-expanded="true">
      <span class="cloud-collapse-card-icon">
        <svg class="icon" aria-hidden="true"><use href="#vtv-icon-resource-adiministration"></use></svg>
      </span>
      <span class="cloud-collapse-card-text">
        <span class="cloud-collapse-card-title">卡片1的标题</span>
        <span class="cloud-collapse-card-subtitle">卡片1的副标题</span>
      </span>
      <svg class="icon cloud-collapse-card-arrow" aria-hidden="true"><use href="#vtv-icon-arrow-up"></use></svg>
    </button>
    <div class="cloud-collapse-card-content">卡片1的内容</div>
  </section>
</div>
```

### 卡片折叠：shadow 外观

```html
<div class="cloud-collapse-card collapse--head-64 collapse--shadow" data-collapse>
  <section class="cloud-collapse-card-item" data-panel>
    <button class="cloud-collapse-card-header" type="button" aria-expanded="false">
      <span class="cloud-collapse-card-text">
        <span class="cloud-collapse-card-title">资源高级配置</span>
        <span class="cloud-collapse-card-subtitle">用于低频但重要的配置项</span>
      </span>
      <svg class="icon cloud-collapse-card-arrow" aria-hidden="true"><use href="#vtv-icon-arrow-down"></use></svg>
    </button>
    <div class="cloud-collapse-card-content">高级配置内容</div>
  </section>
</div>
```

### 分组折叠：硬件详情

```html
<div class="cloud-collapse-group collapse--small" data-collapse>
  <section class="cloud-collapse-group-item is-active" data-panel>
    <button class="cloud-collapse-group-header" type="button" aria-expanded="true">
      <svg class="icon cloud-collapse-group-icon" aria-hidden="true"><use href="#vtv-icon-minus"></use></svg>
      <span class="cloud-collapse-group-title">CPU：8 核</span>
    </button>
    <div class="cloud-collapse-group-content">
      <dl class="cloud-collapse-detail">
        <dt>虚拟插槽数</dt>
        <dd>4</dd>
        <dt>每个插槽核数</dt>
        <dd>5</dd>
      </dl>
    </div>
  </section>
</div>
```

## 生成决策

| 用户描述 | 应选类型 | 尺寸 / 外观 |
| --- | --- | --- |
| 资源详情页、模块化配置、标题+副标题 | 卡片折叠 | `head-80 + border` |
| 需要更强层级或页面模块较少 | 卡片折叠 | `head-80/head-64 + shadow` |
| 高密度配置项、硬件详情、轻量层级 | 分组折叠 | `small` |
| FAQ 或普通问题列表 | 分组折叠或基础描边折叠 | `medium`，可启用 `accordion` |
| 同一组只允许展开一个 | 任意折叠类型 | 启用 `accordion=true` |

## 交互规则

- 点击头部：展开或收起当前面板。
- 卡片折叠：右侧图标在收起时为向下箭头，展开时为向上箭头。
- 分组折叠：左侧图标在收起时为 plus，展开时为 minus。
- 手风琴：展开一个面板时，同组其他面板必须自动收起。
- 内容区动画：可以使用 height / opacity 过渡，但不得导致页面布局抖动。
- 操作区：如果标题右侧放置按钮或链接，点击操作区不得触发展开/收起；更多操作使用 `vtv-icon-comp-more`。
- 长文本：标题和副标题都必须单行省略，不允许撑高折叠头。
- 禁用态：禁用项不响应 hover、click 和键盘触发。

## 可访问性

- 有点击行为的折叠头优先使用 `button`。
- 折叠头必须设置 `aria-expanded="true/false"`。
- 折叠头和内容区建议通过 `aria-controls` 与 `id` 关联。
- 禁用项使用 `disabled` 或 `aria-disabled="true"`。
- 键盘聚焦态必须可见，不能只依赖 hover。

## 禁止事项

- 禁止继续使用旧的统一 48px 折叠头。
- 禁止卡片折叠内混用 `border` 和 `shadow` 外观。
- 禁止同一个折叠组内混用 `small` 和 `medium`。
- 禁止用 CSS 伪元素临时绘制 plus/minus/arrow 图标，必须使用图标库。
- 禁止标题或副标题多行撑高折叠头。
- 禁止把关键错误、阻塞状态或必须立即处理的信息默认收起。
- 禁止嵌套超过 3 层；复杂层级优先使用树组件或独立详情页。

## 生成前检查

- [ ] 是否明确使用卡片折叠或分组折叠。
- [ ] 卡片折叠是否明确使用 `border` 或 `shadow`。
- [ ] 卡片折叠是否明确使用 64px 或 80px 头高。
- [ ] 80px 卡片头部图标是否为 48px。
- [ ] 80px 卡片头部操作区按钮是否为 32px。
- [ ] 64px 卡片头部图标是否为 40px，操作区按钮是否为 24px。
- [ ] 内容区表格是否遵循基础表格小尺寸规范。
- [ ] 分组常规头部是否为 40px，小尺寸是否为 32px。
- [ ] 分组内容区是否保留 24px 左内边距和左侧虚线。
- [ ] 标题和副标题是否单行省略。
- [ ] Hover、Expanded、Disabled、Focus 状态是否完整。
- [ ] 手风琴模式下是否保证同组只展开一项。
- [ ] 操作区点击是否阻止触发展开/收起。
