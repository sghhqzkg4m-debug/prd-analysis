---
name: "云BG设计规范-基础组件-日期选择器（date-picker）"
description: "提供日期选择器组件的设计规范、最佳实践,依赖skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。当用户需要设计或实现日期选择器组件时调用。"
step:
  1. 需求解析：理解用户需要创建的日期选择器类型（日期/日期时间/日期范围/时间选择）
  2. 视觉设计：所有样式必须先使用本技能文档预定义的尺寸规范和颜色规范，未定义部分则使用skills/sxf-cloud-design-system/SKILL.md中定义的设计规范
  3. 代码生成：按规范生成完整的HTML、CSS和JavaScript代码
---

# 日期选择器 DatePicker

## 概述

日期选择器用于用户选择日期或日期时间，支持单个日期、日期范围、时间选择等场景。

- **来源**：深信服云BG设计部
- **类型**：表单组件
- **适用场景**：表单填写、时间范围查询、数据筛选

## 使用场景

日期选择器组件适用于以下情况：

- **日期选择**：选择单个日期
- **日期时间选择**：选择日期和时间
- **日期范围选择**：选择开始和结束日期
- **时间选择**：仅选择时间
- **快捷操作**：今天、昨天、近7天、近30天等

## 组件结构

### 子组件结构

| 子组件 | 功能 | 是否必需 |
|--------|------|----------|
| DatePicker | 日期选择器主容器 | 必需 |
| DatePickerTrigger | 触发器（显示已选日期） | 必需 |
| DatePickerPanel | 日期面板 | 必需 |
| DatePickerHeader | 面板头部（年月切换） | 必需 |
| DatePickerContent | 日期/时间内容区 | 必需 |
| DatePickerFooter | 面板底部（操作按钮） | 可选 |

## 尺寸规范

### 触发器尺寸

| 属性 | Small | Default |
|------|-------|---------|
| 高度 | 24px | 32px |
| 内边距 | 0 8px | 0 12px |
| 字体大小 | 12px | 14px |
| 圆角 | 4px | 4px |

### 面板尺寸

| 属性 | 值 |
|------|-----|
| 面板宽度 | 280px（单日期）/ 560px（日期范围） |
| 面板高度 | 320px |
| 日期单元格宽度 | 40px |
| 日期单元格高度 | 32px |
| 月份切换按钮 | 24px × 24px |

## 颜色规范

### 触发器颜色

| 状态 | 边框色 | 背景色 | 文字色 |
|------|--------|--------|--------|
| 默认 | `blueGray.default` | `Gray.l60` | `Gray.d50` |
| 悬浮 | `blueGray.d20` | `Gray.l60` | `Gray.d50` |
| 聚焦 | `poseidonBlue.default` | `Gray.l60` | `Gray.d50` |
| 禁用 | `blueGray.default` | `Gray.l30` | `Gray.d30` |

### 面板颜色

| 元素 | 颜色 | Token |
|------|------|-------|
| 面板背景 | 白色 | `Gray.l60` |
| 面板边框 | 浅灰 | `Gray.l10` |
| 标题文字 | 深灰 | `Gray.d50` |
| 日期文字 | 深灰 | `Gray.d50` |
| 周末文字 | 灰色 | `Gray.d30` |

### 选中状态颜色

| 状态 | 背景色 | 边框色 | 文字色 |
|------|--------|--------|--------|
| 选中日期 | `poseidonBlue.default` | - | `Gray.l60` |
| 范围开始/结束 | `poseidonBlue.l20` | `poseidonBlue.default` | `poseidonBlue.default` |
| 范围内 | `poseidonBlue.l70` | - | `Gray.d50` |
| 今天标记 | `poseidonBlue.default` | - | `Gray.l60` |

### 按钮颜色

| 元素 | 颜色 | Token |
|------|------|-------|
| 切换按钮默认 | `Gray.d30` | `Gray.d30` |
| 切换按钮悬浮 | `poseidonBlue.default` | `poseidonBlue.default` |
| 确认按钮 | `poseidonBlue.default` | `Gray.l60` |
| 清除按钮 | `Gray.d30` | `Gray.d60` |

## 交互规范

### 状态定义

| 状态 | 表现 | 说明 |
|------|------|------|
| 默认 | 边框 `blueGray.default` | 初始状态 |
| 悬浮 | 边框 `blueGray.d20` | 鼠标悬停 |
| 聚焦 | 边框 `poseidonBlue.default` + 阴影 | 键盘聚焦或面板展开 |
| 禁用 | 背景 `Gray.l30`，文字 `Gray.d30` | 不可操作 |
| 只读 | 与禁用类似，但光标为默认 | 不可编辑 |

### 快捷操作

| 操作 | 说明 |
|------|------|
| 今天 | 选中当前日期 |
| 昨天 | 选中昨天日期 |
| 近7天 | 选中最近7天范围 |
| 近30天 | 选中最近30天范围 |
| 本月 | 选中本月日期范围 |
| 上月 | 选中上月日期范围 |

### 面板交互

- 点击触发器展开面板
- 点击面板外区域关闭面板
- 年/月切换支持快速跳转
- 支持键盘导航（方向键、Enter、Esc）

## CSS变量格式

```css
/* 日期选择器变量 */
:root {
  /* 触发器 */
  --datepicker-trigger-height: 32px;
  --datepicker-trigger-padding: 0 12px;
  --datepicker-trigger-border-radius: 4px;
  --datepicker-trigger-border-color: var(--color-blue-gray-default);
  --datepicker-trigger-bg: var(--color-gray-l60);
  --datepicker-trigger-text-color: var(--color-gray-d50);

  /* 面板 */
  --datepicker-panel-width: 280px;
  --datepicker-panel-height: 320px;
  --datepicker-panel-bg: var(--color-gray-l60);
  --datepicker-panel-border-radius: 6px;
  --datepicker-panel-box-shadow: var(--shadow-lg);

  /* 日期单元格 */
  --datepicker-cell-width: 40px;
  --datepicker-cell-height: 32px;

  /* 选中态 */
  --datepicker-selected-bg: var(--color-poseidon-blue-default);
  --datepicker-selected-text: var(--color-gray-l60);
  --datepicker-range-bg: var(--color-poseidon-blue-l70);
  --datepicker-in-range-border: var(--color-poseidon-blue-default);
}
```

## 使用规范

### 参数配置

| 参数 | 取值 | 说明 |
|------|------|------|
| 类型 | date / datetime / daterange / datetimerange / time | 选择器类型 |
| 尺寸 | small / default | 触发器尺寸 |
| 状态 | default / hover / focus / disabled / readonly | 交互状态 |
| 格式 | YYYY-MM-DD / YYYY-MM-DD HH:mm:ss | 日期格式 |
| 占位符 | string | 未选时的提示文字 |
| 快捷操作 | boolean | 是否显示快捷操作 |

### 使用原则

1. **默认值**：建议提供合理的默认值（如今天）
2. **格式清晰**：日期格式应符合用户习惯
3. **范围限制**：根据业务场景限制可选范围
4. **快捷操作**：常用场景提供快捷选择
5. **反馈明确**：选中后立即显示所选日期

## 最佳实践

### 正确示例

- 提供清晰的日期格式提示
- 支持快捷日期选择（今天、本周等）
- 选中状态颜色区分明显
- 禁用日期样式清晰（如周末、节假日）

### 避免事项

- 不要使用模糊的日期格式
- 不要让用户手动输入日期
- 不要忽略日期范围的连续性
- 不要在面板中隐藏快捷操作

## 关联文档

- [输入框组件](./输入框-Input.md)
- [选择器组件](./选择器-Select.md)
- [按钮组件](./按钮-Button.md)
