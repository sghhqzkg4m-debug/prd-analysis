---
name: "云BG设计规范-基础组件-按钮（button）"
description: "提供按钮组件的设计规范、最佳实践,依赖skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。当用户需要设计或实现按钮组件时调用。"
step:
  1. 需求解析：理解用户需要创建的按钮类型（主要按钮、次要按钮、边框按钮、隐藏边框按钮、文字按钮、单图标按钮）
  2. 视觉设计：所有样式优先使用本技能文档预定义的尺寸规范和颜色规范，未定义部分则使用skills/sxf-cloud-design-system/SKILL.md中定义的设计规范
  3. 代码生成：按规范生成完整的HTML、CSS和JavaScript代码
---

# 按钮 Button

## 1、概述

按钮组件用于触发交互动作，是用户与系统进行交互的重要触点。

- **来源**：深信服云BG设计部
- **类型**：基础交互组件
- **适用场景**：表单提交、页面导航、操作确认、状态切换等

### 1.1、使用场景

按钮组件适用于以下情况：

- **主要按钮**：用于主要操作，如提交表单、确认删除、创建资源等关键流程
- **次要按钮**：用于次要操作，如取消、返回、上一步等辅助流程
- **边框按钮**：用于需要突出层级关系的场景，或在工具栏中与主要按钮配合使用
- **隐藏边框按钮**：用于内联操作，或在卡片、表格等紧凑空间中放置
- **文字按钮**：用于最小化视觉干扰的场景，如工具栏中的更多操作
- **单图标按钮**：用于工具栏、状态栏等需要视觉简洁的空间

### 1.2、组件结构&组成成分

#### 组件结构

推荐将按钮组件拆分为以下稳定、可复用的子结构：

| 子组件 | 功能 | 是否必需 |
|--------|------|----------|
| Button | 按钮主容器 | 必需 |
| ButtonGroup | 按钮组容器 | 可选 |
| Icon | 图标元素 | 可选 |
| Text | 文字元素 | 可选 |
| Dropdown | 下拉箭头 | 可选 |

#### 组成成分

| 按钮类型 | 仅文字 | 图标+文字 | 文字+下拉 | 图标+文字+下拉 | 仅图标 |
|---------|--------|----------|----------|--------------|--------|
| **主要按钮** | ✓ | ✓ | ✓ | ✓ | ✓ |
| **次要按钮** | ✓ | ✓ | ✓ | ✓ | ✓ |
| **边框按钮** | ✓ | ✓ | ✓ | ✓ | ✓ |
| **隐藏边框按钮** | ✓ | ✓ | ✓ | - | - |
| **文字按钮** | ✓ | ✓ | ✓ | - | - |
| **单图标按钮** | - | - | - | - | ✓ |

| 组成类型 | 组成元素 | 说明 |
|---------|---------|------|
| 仅文字 | 文字 | 按钮中只有文字，没有图标和下拉箭头 |
| 图标+文字 | 从左到右依次是图标、文字 | 按钮中包含图标和文字，常用于工具栏操作区 |
| 文字+下拉 | 从左到右依次是文字、下拉 | 按钮中包含文字和下拉箭头 |
| 图标+文字+下拉 | 从左到右依次是图标、文字、下拉 | 按钮中包含图标、文字和下拉箭头 |
| 仅图标 | 图标 | 仅图标按钮 |

> **组成成分与样式的映射规则**：
> - 组成成分决定按钮**显示什么内容**（文字、图标、下拉箭头的组合），按钮类型决定按钮**视觉样式**（背景色、边框色等）。
> - 当组成成分中缺少某一列时（如"仅图标"缺少文字色列），直接去掉该列，其余样式列保持不变，**不要切换为其他按钮变体**。
> - 例如："次要按钮 + 仅图标" = 使用次要按钮的样式表，去掉文字色列，保留背景色、图标色、边框色、线宽不变。

## 视觉设计规范

### 颜色规范

#### 颜色引用规范（强制）

**颜色Token格式**：`{颜色名}.{色阶}` → `var(--color-{颜色名}-{色阶})`

**颜色转换规则：**
生成代码时，将自然语言颜色转换为CSS变量格式：`{颜色名}.{色阶}` → `var(--color-{颜色名}-{色阶})`

#### 设计Token使用规范

**禁止硬编码规则：**
生成代码时，文档中定义的所有设计Token（如颜色、间距、圆角、字体等）**必须**使用CSS变量引用，**禁止**直接使用硬编码值。

**正确示例：**
```css
color: var(--color-gray-d50);
border: 1px solid var(--color-blue-gray-l30);
```

**错误示例：**
```css
color: #404655;
border: 1px solid #EBEDF0;
```

### 状态颜色详情

#### 主要按钮 Primary Button

| 状态 | 背景色 | 文字色 | 图标色 | 边框色 | 线宽 |
|------|--------|--------|--------|--------|------|
| 默认 | `poseidon-blue.default` | `gray.l60` | `gray.l60` | `poseidon-blue.d10` | 1px |
| 悬浮 | `poseidon-blue.l10` | `gray.l60` | `gray.l60` | `poseidon-blue.default` | 1px |
| 点击/选中 | `poseidon-blue.d10` | `gray.l60` | `gray.l60` | `poseidon-blue.d20` | 1px |
| 聚焦 | `poseidon-blue.l20` | `gray.l60` | `gray.l60` | `poseidon-blue.default (20% opacity)` | 3px |
| 禁用 | `poseidon-blue.default (40% opacity)` | `gray.l60 (40% opacity)` | `gray.l60 (40% opacity)` | `poseidon-blue.d10 (40% opacity)` | `-` |

#### 次要按钮 Secondary Button

| 状态 | 背景色 | 文字色 | 图标色 | 边框色 | 线宽 |
|------|--------|--------|--------|--------|------|
| 默认 | `gray.l60` | `gray.d50` | `graphite-black.l30` | `blue-gray.default` | 1px |
| 悬浮 | `gray.l60` | `gray.d50` | `graphite-black.l30` | `blue-gray.d20` | 1px |
| 点击/选中 | `gray.l60` | `gray.d50` | `graphite-black.l30` | `poseidon-blue.l20` | 1px |
| 聚焦 | `gray.l60` | `gray.d50` | `graphite-black.l30` | `poseidon-blue.l20 (20% opacity)` | 3px |
| 禁用 | `gray.l60 (40% opacity)` | `gray.d50 (40% opacity)` | `graphite-black.l30 (40% opacity)` | `blue-gray.default (40% opacity)` | 1px |

#### 边框按钮 Ghost Button

| 状态 | 背景色 | 文字色 | 图标色 | 边框色 | 线宽 |
|------|--------|--------|--------|--------|------|
| 默认 | `transparent` | `gray.d50` | `graphite-black.l30` | `blue-gray.default` | 1px |
| 悬浮 | `transparent` | `gray.d50` | `graphite-black.l30` | `blue-gray.d20` | 1px |  
| 点击/选中 | `transparent` | `gray.d50` | `graphite-black.l30` | `poseidon-blue.d20` | 1px |
| 聚焦 | `transparent` | `gray.d50` | `graphite-black.l30` | `poseidon-blue.default (20% opacity)` | 3px |
| 禁用 | `transparent` | `gray.d50 (40% opacity)` | `graphite-black.l30 (40% opacity)` | `graphite-black.default (40% opacity)` | 1px |

#### 隐藏边框按钮 Hidden Border Button

| 状态 | 背景色 | 文字色 | 图标色 | 边框色 |
|------|--------|--------|--------|--------|
| 默认 | `transparent` | `gray.d50` | `graphite-black.l30` | `none` |
| 悬浮 | `transparent` | `gray.d50` | `graphite-black.l30` | `blue-gray.d20 (全框, 1px)` |
| 点击/选中 | `transparent` | `gray.d50` | `graphite-black.l30` | `poseidon-blue.d20 (全框, 1px)` |
| 聚焦 | `transparent` | `gray.d50` | `graphite-black.l30` | `poseidon-blue.default (20% opacity) 3px` |
| 禁用 | `transparent` | `gray.d50 (40% opacity)` | `blue-gray.d20 (40% opacity)` | `none` |

#### 文字按钮 Text Button

| 状态 | 背景色 | 文字色 | 图标色 | 边框色 |
|------|--------|--------|--------|--------|
| 默认 | `transparent` | `poseidon-blue.d10` | `poseidon-blue.d10` | `none` |
| 悬浮 | `transparent` | `poseidon-blue.l10` | `poseidon-blue.l10` | `none` |
| 点击/选中 | `transparent` | `poseidon-blue.d30` | `poseidon-blue.d30` | `none` |
| 聚焦 | `-` | `-` | `-` | `-` |
| 禁用 | `transparent` | `poseidon-blue.d10 (40% opacity)` | `poseidon-blue.d10 (40% opacity)` | `none` |

#### 单图标按钮 Single Icon Button

| 状态 | 背景色 | 图标色 | 边框色 |
|------|--------|--------|--------|
| 默认 | `transparent` | `graphite-black.l30 (80% opacity)` | `none` |
| 悬浮 | `transparent` | `graphite-black.l30` | `none` |
| 点击/选中 | `transparent` | `poseidon-blue.default` | `none` |
| 聚焦 | `transparent` | `poseidon-blue.default` | `none` |
| 禁用 | `transparent` | `graphite-black.l30 (40% opacity)` | `none` |

### 常用图标引用表

| 图标名称 | 图标ID | 适用按钮类型 | 使用场景 |
|---------|--------|------------|---------|
| 添加/创建/新增 | `vtv-icon-add` | primary / secondary / ghost / link | 创建、新增、添加 |
| 编辑/修改/更新 | `vtv-icon-edit` | secondary / ghost / link | 修改内容、编辑信息 |
| 删除/移除 | `vtv-icon-delete` | secondary / ghost / link | 删除条目、移除资源 |
| 查看 | `vtv-icon-check-detail` | secondary / ghost / link | 查看详情 |
| 关闭 | `vtv-icon-close-line` | secondary / ghost / link | 关闭弹窗、取消操作 |
| 确认/提交 | `vtv-icon-enable` | primary / secondary | 确认操作、提交保存 |
| 启用/勾选 | `vtv-icon-enable` | primary / secondary | 启用操作、勾选操作 |
| 上传 | `vtv-icon-upload` | primary / secondary | 上传文件、提交数据 |
| 下载 | `vtv-icon-download` | secondary / ghost / link | 下载文件、导出数据 |
| 设置 | `vtv-icon-setting` | secondary / ghost / link | 系统设置、配置管理 |
| 刷新 | `vtv-icon-refresh` | secondary / ghost / icon | 刷新页面、重新加载 |
| 更多 | `vtv-icon-more` | text / icon | 更多操作、下拉菜单 |
| 筛选 | `vtv-icon-filter` | ghost / link | 数据筛选、条件过滤 |
| 排序 | `vtv-icon-sort` | ghost / link | 数据排序、调整顺序 |
| 用户 | `vtv-icon-user` | secondary / ghost | 用户中心、账号设置 |
| 菜单 | `vtv-icon-nav-map` | icon | 导航菜单、侧边栏切换 |
| 返回 | `vtv-icon-return` | secondary / ghost / icon | 返回上一页、返回上级 |
| 左箭头 | `vtv-icon-arrow-left` | secondary / ghost / icon | 返回上一页、上一步 |
| 右箭头 | `vtv-icon-arrow-right` | secondary / ghost / icon | 下一步、跳转链接 |
| 上箭头 | `vtv-icon-arrow-up` | icon | 收起、回到顶部 |
| 下拉 | `vtv-icon-comp-angle-down` | secondary / ghost / text | 展开、下拉选择 |
| 复制 | `vtv-icon-copy` | secondary / ghost / icon | 复制内容、复制链接 |
| 分享 | `vtv-icon-share` | secondary / ghost / icon | 分享资源、发送链接 |
| 详情 | `vtv-icon-detail` | text / secondary | 查看详情、展开信息 |
| 导出 | `vtv-icon-export` | primary / secondary / text | 导出数据、导出报表 |

### 尺寸规范

按钮提供三种尺寸规格，图标尺寸统一为 16px。

#### 间距规范

| 尺寸规格 | 图标与文字间距 | 文字与下拉间距 | 水平内边距(带下拉) | 水平内边距(不带下拉) |
|---------|--------------|--------------|-------------------|-------------------|
| 小尺寸 (24px) | 4px | 8px | 左8px 右4px | 左8px 右8px |
| 默认尺寸 (32px) | 8px | 12px | 左12px 右8px | 左12px 右12px |
| 大尺寸 (36px) | 12px | 16px | 左16px 右12px | 左16px 右16px |

#### 小尺寸 (Small)

| 元素 | 尺寸 | 说明 |
|------|------|------|
| 高度 | 24px | 按钮高度 |
| 宽度 | 自适应，最小80px | 最小宽度限制 |
| 圆角 | 2px (radius.xs) | 圆角规格 |
| 字体 | 12px | 字体大小 |
| 行高 | 17px | 行高规格 |
| 图标 | 16px | 图标尺寸（所有尺寸统一） |

#### 默认尺寸 (Normal)

| 元素 | 尺寸 | 说明 |
|------|------|------|
| 高度 | 32px | 按钮高度 |
| 宽度 | 自适应，最小80px | 最小宽度限制 |
| 圆角 | 4px (radius.sm) | 圆角规格 |
| 字体 | 14px | 字体大小 |
| 行高 | 20px | 行高规格 |
| 图标 | 16px | 图标尺寸（所有尺寸统一） |

#### 大尺寸 (Large)

| 元素 | 尺寸 | 说明 |
|------|------|------|
| 高度 | 36px | 按钮高度 |
| 宽度 | 自适应，最小80px | 最小宽度限制 |
| 圆角 | 4px (radius.sm) | 圆角规格 |
| 字体 | 14px | 字体大小 |
| 行高 | 20px | 行高规格 |
| 图标 | 16px | 图标尺寸（所有尺寸统一） |

## 交互设计规范

| 状态 | 表现 | 说明 |
|------|------|------|
| 默认状态 | 各变体默认颜色样式 | 组件初始状态 |
| 悬浮状态 | 背景色变浅/边框色加深/显示下划线 | 提供交互反馈 |
| 点击/选中状态 | 背景色加深/边框色加深 | 表示已触发 |
| 聚焦状态 | 显示聚焦边框（3px）或阴影 | 键盘导航支持 |
| 禁用状态 | 透明度降低（40%） | 表示不可操作 |

**说明：**
- 悬浮状态仅作用于被指向的按钮，不影响其他元素
- 所有可点击按钮都应支持悬浮状态
- 键盘聚焦状态必须可见，不依赖悬浮状态才出现
- 禁用状态应同时设置 `cursor: not-allowed`


## 参数配置

在使用按钮组件时，需要配置以下参数：

| 参数 | 取值 | 说明 |
|------|------|------|
| 类型 | primary / secondary / ghost / link / text / icon | 按钮变体样式 |
| 尺寸 | small / normal / large | 按钮高度 |
| 状态 | default / hover / active / focus / disabled | 按钮交互状态 |
| 图标 | boolean | 是否显示图标 |
| 图标位置 | left / right | 图标相对于文字的位置 |
| 加载中 | boolean | 是否显示加载状态 |
| 禁用 | boolean | 是否禁用 |

## 最佳实践

### 命名规范

为了便于设计师和开发者检索与维护，推荐使用以下命名：

- **组件集**：`componentset-button`
- **变体/示例**：
  - `button-primary` - 主要按钮
  - `button-secondary` - 次要按钮
  - `button-ghost` - 边框按钮
  - `button-link` - 隐藏边框按钮
  - `button-text` - 文字按钮
  - `button-icon` - 单图标按钮

### 使用原则

1. **主次分明**：一个操作区域应有一个主要按钮，其他为次要按钮
2. **状态可见**：所有按钮状态都必须可区分，尤其是禁用状态
3. **无障碍支持**：聚焦状态必须可见，不依赖悬浮状态才出现
4. **层级一致**：同类型按钮的尺寸、圆角、间距应保持一致
5. **禁用谨慎**：禁用按钮应同时提供工具提示说明原因

## 6、CSS示例代码

### 6.1 CSS变量定义

```css
:root {
  --color-poseidon-blue-default: #1770E6;
  --color-poseidon-blue-l10: #4A90F5;
  --color-poseidon-blue-l20: #7BB0FA;
  --color-poseidon-blue-d10: #0F5BC4;
  --color-poseidon-blue-d20: #0A44A2;
  --color-poseidon-blue-d30: #062E7F;
  
  --color-gray-l60: #FFFFFF;
  --color-gray-l50: #F5F5F5;
  --color-gray-l40: #E8E8E8;
  --color-gray-l30: #D6D6D6;
  --color-gray-default: #999999;
  --color-gray-d10: #666666;
  --color-gray-d20: #4D4D4D;
  --color-gray-d30: #333333;
  --color-gray-d50: #404655;
  --color-gray-d60: #1F2329;
  
  --color-graphite-black-default: #000000;
  --color-graphite-black-l30: #434343;
  
  --color-blue-gray-default: #D9DDE5;
  --color-blue-gray-l30: #EBEDF0;
  --color-blue-gray-d20: #9CA3AF;
  
  --radius-xs: 2px;
  --radius-sm: 4px;
  --radius-default: 8px;
  
  --font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  --font-size-xs: 12px;
  --font-size-sm: 14px;
}
```

### 6.2 基础按钮样式

```css
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-family: var(--font-family);
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  border: none;
  outline: none;
  position: relative;
}

.btn::after {
  content: '';
  position: absolute;
  inset: -2px;
  border-radius: inherit;
  opacity: 0;
  transition: opacity 0.2s ease;
  pointer-events: none;
}

.btn:focus-visible::after {
  opacity: 1;
}
```

### 6.3 按钮变体样式

```css
.btn-primary {
  background: var(--color-poseidon-blue-default);
  color: var(--color-gray-l60);
  border: 1px solid var(--color-poseidon-blue-d10);
}

.btn-primary:hover {
  background: var(--color-poseidon-blue-l10);
  border-color: var(--color-poseidon-blue-default);
}

.btn-primary:active {
  background: var(--color-poseidon-blue-d10);
  border-color: var(--color-poseidon-blue-d20);
}

.btn-primary:focus-visible::after {
  border: 3px solid rgba(23, 112, 230, 0.2);
}

.btn-primary:disabled {
  background: rgba(23, 112, 230, 0.4);
  color: rgba(255, 255, 255, 0.4);
  border-color: rgba(15, 91, 196, 0.4);
  cursor: not-allowed;
}

.btn-secondary {
  background: var(--color-gray-l60);
  color: var(--color-gray-d50);
  border: 1px solid var(--color-blue-gray-default);
}

.btn-secondary:hover {
  border-color: var(--color-blue-gray-d20);
}

.btn-secondary:active {
  border-color: var(--color-poseidon-blue-l20);
}

.btn-secondary:focus-visible::after {
  border: 3px solid rgba(74, 144, 245, 0.2);
}

.btn-secondary:disabled {
  background: rgba(255, 255, 255, 0.4);
  color: rgba(64, 70, 85, 0.4);
  border-color: rgba(217, 221, 229, 0.4);
  cursor: not-allowed;
}

.btn-ghost {
  background: transparent;
  color: var(--color-gray-d50);
  border: 1px solid var(--color-blue-gray-default);
}

.btn-ghost:hover {
  border-color: var(--color-blue-gray-d20);
}

.btn-ghost:active {
  border-color: var(--color-poseidon-blue-d20);
}

.btn-ghost:focus-visible::after {
  border: 3px solid rgba(23, 112, 230, 0.2);
}

.btn-ghost:disabled {
  color: rgba(64, 70, 85, 0.4);
  border-color: rgba(0, 0, 0, 0.4);
  cursor: not-allowed;
}

.btn-link {
  background: transparent;
  color: var(--color-gray-d50);
  border: none;
}

.btn-link:hover {
  border: 1px solid var(--color-blue-gray-d20);
}

.btn-link:active {
  border: 1px solid var(--color-poseidon-blue-d20);
}

.btn-link:focus-visible::after {
  border: 3px solid rgba(23, 112, 230, 0.2);
}

.btn-link:disabled {
  color: rgba(64, 70, 85, 0.4);
  cursor: not-allowed;
}

.btn-text {
  background: transparent;
  color: var(--color-poseidon-blue-d10);
  border: none;
}

.btn-text:hover {
  color: var(--color-poseidon-blue-l10);
}

.btn-text:active {
  color: var(--color-poseidon-blue-d30);
}

.btn-text:disabled {
  color: rgba(15, 91, 196, 0.4);
  cursor: not-allowed;
}

.btn-icon {
  background: transparent;
  color: rgba(67, 67, 67, 0.8);
  border: none;
}

.btn-icon:hover {
  color: var(--color-graphite-black-l30);
}

.btn-icon:active,
.btn-icon:focus-visible {
  color: var(--color-poseidon-blue-default);
}

.btn-icon:disabled {
  color: rgba(67, 67, 67, 0.4);
  cursor: not-allowed;
}
```

### 6.4 尺寸样式

```css
.btn-sm {
  height: 24px;
  padding: 0 8px;
  font-size: var(--font-size-xs);
  line-height: 17px;
  border-radius: var(--radius-xs);
}

.btn-sm svg + span,
.btn-sm span + svg {
  margin-left: 4px;
}

.btn-sm span + svg:last-child {
  margin-left: 8px;
}

.btn-normal {
  height: 32px;
  padding: 0 12px;
  font-size: var(--font-size-sm);
  line-height: 20px;
  border-radius: var(--radius-sm);
  min-width: 80px;
}

.btn-normal svg + span,
.btn-normal span + svg {
  margin-left: 8px;
}

.btn-normal span + svg:last-child {
  margin-left: 12px;
}

.btn-lg {
  height: 36px;
  padding: 0 16px;
  font-size: var(--font-size-sm);
  line-height: 20px;
  border-radius: var(--radius-sm);
  min-width: 80px;
}

.btn-lg svg + span,
.btn-lg span + svg {
  margin-left: 12px;
}

.btn-lg span + svg:last-child {
  margin-left: 16px;
}

.btn-icon-only {
  width: 32px;
  height: 32px;
  padding: 0;
  border-radius: var(--radius-sm);
}

.btn-icon-only.btn-sm {
  width: 24px;
  height: 24px;
}

.btn-icon-only.btn-lg {
  width: 36px;
  height: 36px;
}
```

### 6.5 图标样式

```css
.icon {
  width: 1em;
  height: 1em;
  vertical-align: middle;
  fill: currentColor;
  overflow: hidden;
  font-size: 16px;
}
```

### 6.6 按钮组样式

```css
.btn-group-horizontal {
  display: flex;
  border-radius: var(--radius-sm);
  overflow: hidden;
  border: 1px solid var(--color-blue-gray-default);
}

.btn-group-horizontal .btn {
  border-radius: 0;
  border: none;
  border-right: 1px solid var(--color-blue-gray-default);
  min-width: 80px;
}

.btn-group-horizontal .btn:last-child {
  border-right: none;
}

.btn-group-horizontal .btn:not(:disabled):hover {
  background: var(--color-gray-l50);
}

.btn-group-horizontal .btn:not(:disabled):active {
  background: var(--color-blue-gray-l30);
}
```

### 6.7 加载状态样式

```css
.loading-spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-top-color: var(--color-gray-l60);
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.btn-primary .loading-spinner {
  border-color: rgba(255, 255, 255, 0.3);
  border-top-color: var(--color-gray-l60);
}

.btn-secondary .loading-spinner,
.btn-ghost .loading-spinner {
  border-color: rgba(64, 70, 85, 0.3);
  border-top-color: var(--color-gray-d50);
}
```

### 6.8 带下拉箭头按钮的内边距

根据尺寸规范，带下拉箭头的按钮应使用不对称内边距：

```css
.btn-sm.btn-has-dropdown {
  padding-left: 8px;
  padding-right: 4px;
}

.btn-normal.btn-has-dropdown {
  padding-left: 12px;
  padding-right: 8px;
}

.btn-lg.btn-has-dropdown {
  padding-left: 16px;
  padding-right: 12px;
}
```

## 7、高约束规则

> **生成器必须严格遵守以下规则，违反将导致样式错误。**

### 引用触发条件
当在其他组件文档或生成代码中，识别到以下关键词时，**必须**引用本按钮文档：
- "按钮"、"button"
- "次要按钮"、"Secondary"
- "主要按钮"、"Primary"
- "边框按钮"、"Ghost"
- "隐藏边框按钮"、"Hidden Border"
- "文字按钮"、"Text"
- "单图标按钮"、"Single Icon"

### 强制遵守要求

| 要求 | 说明 |
|------|------|
| **禁止自定义颜色** | 颜色值**必须**从本文档「颜色规范」表格中选取，禁止自行推断或使用其他色值 |
| **禁止自定义尺寸** | 尺寸**必须**严格遵循本义档「尺寸规范」，包括高度、内边距、圆角 |
| **禁止省略状态** | 所有按钮必须包含：默认、悬浮、点击/选中、聚焦、禁用 五种状态 |
| **禁止跨变体混合** | 每个按钮变体有独立的颜色规范，禁止混合不同变体的样式 |


### 错误示例

```html
<!-- ❌ 错误：自行推断次要按钮颜色 -->
<button class="btn" style="border-color: #999;">取消</button>

<!-- ✅ 正确：严格遵循次要按钮规范 -->
<button class="btn-secondary">取消</button>
```

```css
/* ❌ 错误：自行推断按钮样式 */
.btn {
    background: #e8e8e8;  /* 自行推断的灰色 */
    color: #666;
}

/* ✅ 正确：使用文档规定的颜色变量 */
.btn-secondary {
    background: var(--color-gray-l60);
    color: var(--color-gray-d50);
    border: 1px solid var(--color-blue-gray-default);
}
```

### 验证清单
生成按钮样式后，逐项核对：
- [ ] 颜色是否来自文档规定的CSS变量
- [ ] 尺寸是否符合尺寸规范表（高度、内边距、圆角）
- [ ] 是否包含全部5种状态样式
- [ ] 变体名称是否与文档一致


## 8、关联文档

- [颜色规范](../../design-system.md)
- [图标系统](../../design-system.md)
