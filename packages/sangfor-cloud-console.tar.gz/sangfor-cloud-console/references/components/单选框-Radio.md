---
name: "云BG设计规范-基础组件-单选框（radio）"
description: "提供单选框组件的设计规范、最佳实践,依赖skills/sxf-cloud-design-system/SKILL.md中定义的设计规范。当用户需要设计或实现单选框组件时调用。"
step:
  1. 需求解析：理解用户需要创建的单选框类型（基础单选框、单选按钮组、单选胶囊）
  2. 视觉设计：所有样式必须先使用本技能文档预定义的尺寸规范和颜色规范，未定义部分则使用skills/sxf-cloud-design-system/SKILL.md中定义的设计规范
  3. 代码生成：按规范生成完整的HTML、CSS和JavaScript代码
---

# 单选框 Radio

## 概述

### 功能说明

单选按钮为用户提供了一组互斥的选项。用户仅从两个或多个选项中选择一个选项。

- **来源**：深信服云BG设计部
- **类型**：表单组件

### 分类及组成

| 分类 | 组成成分 | 使用场景 |
|------|------|------|
| 基础单选框 | 圆形子弹头+文字标签+子选项面板（可选） | 默认分类，圆形选择控件，配合文字标签使用，常用于表单选项，配合子选项面板展示详细说明或关联配置表单 |
| 单选按钮组 | 不带图标的次要按钮 | 用于表单，下方常跟有需要跟随切换的其他表单内容 |
| 单选胶囊 | 胶囊形状的按钮样式，分为填充和描边两种样式 | 适用于工具栏筛选，或页面内容、视图的切换 |

## 设计规范

### 1. 基础单选框设计规范

**子弹头组成说明:**

- 外圆：子弹头的底圆（外圆），用于承载子弹头的圆点
- 内圆：子弹头的内圆点，用于表示选中状态

#### 尺寸规范

| 元素 | 尺寸 | 说明 |
|------|------|------|
| 外圆 | 14px × 14px | 外圆的尺寸 |
| 内圆 | 6px × 6px | 选中圆点的尺寸 |
| 子弹头与文字间距 | 4px | 子弹头与文字之间的间距 |

**位置说明：**子弹头的上下左右都居中对齐

#### 颜色规范（差异标记法）

**基础样式（默认状态）**

| 组成元素 | 未选中 | 选中 |
|----------|--------|------|
| 外圆边框 | var(--color-blue-gray-default) | 无 |
| 外圆填充 | var(--color-gray-l60) | var(--color-poseidon-blue-default) |
| 内圆边框 | 无 | 无 |
| 内圆外阴影 | 无 | var(--color-gray-d60)，10%透明度，（0，1px，0，0） |
| 内圆填充 | var(--color-gray-l60) | var(--color-gray-l60) |
| 文字 | var(--color-gray-d50) | var(--color-gray-d50) |

**状态差异（相对于默认状态的变化）**

| 状态 | 未选中变化 | 选中变化 |
|------|-----------|---------|
| 悬浮 | 外圆边框→blue-gray-d20 | 外圆边框→poseidon-blue-default，外圆填充→poseidon-blue-l10 |
| 点击 | 外圆边框→poseidon-blue-d20 | 外圆边框→poseidon-blue-l20 |
| 聚焦 | +外圆外描边poseidon-blue-default | +外圆外描边poseidon-blue-l20(1px) |
| 禁用 | 填充→gray-l20，文字→gray-d20，透明度40% | 填充→gray-l20，内圆填充→gray-default，文字→gray-d20，透明度40% |

#### 子选项面板 (Sub-options Panel)

**定义**：承载单选框选项的扩展说明、配置项或关联表单的折叠式内容容器。

**核心特征**：
- 与特定单选框选项绑定，选中即展开
- 同一时间仅允许一个面板展开（互斥切换）
- 可包含文本说明或子表单控件

**布局规范**

| 属性 | 规格 | 说明 |
|------|------|------|
| 对齐方式 | 面板左边缘与单选框组第一个选项左对齐 | 确保视觉层级清晰 |
| 指示器箭头 | 指向当前选中选项的子弹头（外圆）中心 | 明确指示内容归属 |
| 面板间距 | 与单选框组间距 8px | 保持呼吸感 |

**视觉样式**

| 属性 | 规格 |
|------|------|
| 内边距 | 上下 2px，左右 8px |
| 背景色 | var(--color-blue-gray-l50) |
| 边框 | 1px solid var(--color-blue-gray-l10) |
| 圆角 | 4px |
| 最大宽度 | 480px（自适应） |
| 箭头尺寸 | 8px 等腰三角形 |

**箭头位置规范**

- **指向目标**：箭头尖端指向选中选项的子弹头（外圆）中心
- **视觉要求**：箭头垂直中线与子弹头垂直中线对齐，允许误差不超过 2px
- **动态跟随**：切换选中项时，箭头应平滑移动至新选项位置

> 实现提示：可通过 JavaScript 动态计算子弹头中心位置，或使用 CSS 预设位置。

**行为规则**

1. **展开触发**：选中对应单选框时自动展开
2. **切换行为**：切换选中项时，原面板收起，新面板展开，箭头同步移动指向新选项
3. **内容推移**：面板展开时向下推移下方内容，避免遮挡用户操作
4. **溢出处理**：面板内容超出最大高度时可内部滚动

**可访问性 (ARIA)**

| 属性 | 值 | 说明 |
|------|-----|------|
| role | region | 标识为独立区域 |
| aria-labelledby | 触发选项ID | 关联触发选项 |
| aria-expanded | true/false | 展开状态 |
| aria-live | polite | 展开时通知读屏软件 |

**注意**：带子选项面板时，单选框组优先等间距排列

**可访问性 (ARIA)**

| 属性 | 值 | 说明 |
|------|-----|------|
| role | region | 标识为独立区域 |
| aria-labelledby | 触发选项ID | 关联触发选项 |
| aria-expanded | true/false | 展开状态 |
| aria-live | polite | 展开时通知读屏软件 |

**注意**：带子选项面板时，单选框组优先等间距排列

#### 基础单选框组排列说明

- 由至少 2 个基础单选框组成，优先水平排列
- **等间距排列**：当单选框组只有一行时，优先使用等间距排列，间距固定为 24px
- **等宽排列**：当单选框出现多行时，优先使用等宽排列，此时栏间距为 16px。当单选框字段长度不一致时，采用等宽排列可确保列对齐整齐，每行单选框左对齐，列宽均分，视觉呈现规整的网格布局

### 2.单选按钮组设计规范

| 属性 | 说明 |
|------|------|
| 组成数量 | 至少包含 2 个单选按钮 |
| 按钮尺寸 | 默认尺寸为 高32px，小尺寸为 高24px |
| 按钮内边距 | 默认尺寸为 左右12px，小尺寸为 左右8px |
| 整齐排列 | 按钮之间间距为 8px |
| 按钮间距 | 8px |

#### 颜色规范（差异标记法）

**基础样式（默认状态）**

| 组成元素 | 未选中 | 选中 |
|----------|--------|------|
| 填充 | var(--color-gray-l60) | var(--color-gray-l60) |
| 描边 | var(--color-blue-gray-default)，1px | var(--color-poseidon-blue-default)，1px |
| 字体 | var(--color-gray-d50)，12px | var(--color-poseidon-blue-default)，12px |

**状态差异（相对于默认状态的变化）**

| 状态 | 未选中 | 选中 |
|------|------|------|
| 悬浮 | 描边→blue-gray-d20，字体→gray-d60 | - |
| 点击 | 描边→poseidon-blue-l20，字体→gray-d60 | - |
| 禁用 | 透明度40% | 透明度40% |

### 3.单选胶囊设计规范

| 属性 | 说明 |
|------|------|
| 组成数量 | 至少包含 2 个单选按钮 |
| 按钮尺寸 | 默认尺寸为 高32px，小尺寸为 高24px |
| 按钮内边距 | 默认尺寸为 左右12px，小尺寸为 左右8px |
| 紧密排列 | 按钮之间间距为 -1px |
| 圆角处理 | 第一个标签左上左下圆角4px，最后一个标签右上右下圆角4px，中间标签无圆角 |

分为填充样式和描边样式两种：

#### 填充样式颜色规范（差异标记法）

**基础样式（默认状态）**

| 组成元素 | 未选中 | 选中 |
|----------|--------|------|
| 填充 | var(--color-gray-l60) | var(--color-poseidon-blue-default) |
| 描边 | var(--color-blue-gray-default)，1px | var(--color-blue-gray-default)，1px |
| 字体 | var(--color-gray-d50)，12px | var(--color-gray-l60)，12px |
| z-index | - | 1 |

**状态差异（相对于默认状态的变化）**

| 状态 | 未选中变化 | 选中变化 |
|------|-----------|---------|
| 悬浮 | 描边→blue-gray-d20，字体→gray-d60 | - |
| 点击 | 描边→poseidon-blue-l20，字体→gray-d60 | - |
| 禁用 | 透明度40% | 透明度40% |

#### 描边样式颜色规范（差异标记法）

**基础样式（默认状态）**

| 组成元素 | 未选中 | 选中 |
|----------|--------|------|
| 填充 | var(--color-gray-l60) | var(--color-gray-l60) |
| 描边 | var(--color-blue-gray-default)，1px | var(--color-poseidon-blue-default)，1px |
| 字体 | var(--color-gray-d50)，12px | var(--color-poseidon-blue-default)，12px |
| z-index | - | 1 |

**状态差异（相对于默认状态的变化）**

| 状态 | 未选中变化 | 选中变化 |
|------|-----------|---------|
| 悬浮 | 描边→blue-gray-d20，字体→gray-d60 | - |
| 点击 | 描边→poseidon-blue-l20，字体→gray-d60 | - |
| 禁用 | 透明度40% | 透明度40% |

### 互斥规则

- 同一组基础单选框/单选按钮组/单选胶囊中只能有一个被选中
- 选中新的选项时自动取消之前的选中
- 组名相同的单选框互斥

## 可访问性规范（ARIA）

### 属性说明

| 属性 | 值 | 说明 |
|------|-----|------|
| role | radio | 单选框角色 |
| aria-checked | true/false | 选中状态 |
| aria-disabled | true/false | 禁用状态 |
| aria-label | 描述文字 | 无障碍标签（当无文字标签时使用） |
| aria-describedby | 子选项面板ID | 关联子选项面板说明 |
| tabindex | 0/-1 | 键盘导航焦点顺序 |

### 键盘交互

| 按键 | 行为 |
|------|------|
| Tab | 聚焦到单选框组 |
| 方向键 ↑↓←→ | 在组内切换选项 |
| Space | 选中当前聚焦项 |
| Enter | 提交表单（如适用） |

### 焦点管理

- 单选框组内的选项通过方向键切换焦点
- 只有被选中的单选框在Tab导航中可获得焦点
- 聚焦状态必须有可见的视觉指示（外描边）

## 最佳实践

### 使用原则

1. **默认选中**：有预设值时应默认选中对应选项
2. **互斥明确**：同一组选项必须互斥
3. **标签清晰**：选项文案应简洁明了
4. **状态可见**：所有状态都必须可区分
5. **无障碍支持**：键盘导航必须可用，聚焦状态必须可见
6. **禁用说明**：禁用的选项应提供工具提示说明原因

## 常见问题

### 子选项面板箭头位置偏差

**问题描述**：子选项面板的指示器箭头未能准确指向选中选项的子弹头中心。

**排查方向**：
- 确认箭头基准点是否为子弹头（而非整个选项或文字标签）
- 确认切换选项时箭头位置是否正确更新
- 在响应式场景下，监听窗口 resize 事件重新计算位置

**验证方法**：
- 箭头尖端与子弹头中心的水平偏差应 ≤ 2px

### 子选项面板箭头不显示

**问题描述**：子选项面板的指示器箭头未能显示，或显示被裁剪。

**原因分析**：箭头通过 CSS 伪元素 `::before` 实现，定位在面板外部（`top: -5px`）。如果为面板容器设置了 `overflow: hidden` 属性，会将超出边界的箭头内容裁剪掉。

**解决方案**：确保面板容器不设置 `overflow: hidden` 属性，或使用其他方式实现箭头（如额外的 DOM 元素）：

```css
.radio-panel {
  margin-top: 8px;
  background: var(--color-blue-gray-l50);
  border: 1px solid var(--color-blue-gray-l10);
  border-radius: 4px;
  padding: 2px 8px;
  position: relative;
  /* 不要设置 overflow: hidden，否则箭头会被裁剪 */
}

.radio-panel::before {
  content: '';
  position: absolute;
  top: -5px;
  left: 3px;
  width: 8px;
  height: 8px;
  background: var(--color-blue-gray-l50);
  border-left: 1px solid var(--color-blue-gray-l10);
  border-top: 1px solid var(--color-blue-gray-l10);
  transform: rotate(45deg);
}
```

**适用范围**：所有使用子选项面板的场景。

### 子选项面板箭头切换后位置不更新

**问题描述**：切换选中项后，子选项面板的指示器箭头位置未跟随移动，始终指向初始选项的子弹头位置。

**原因分析**：箭头通过 CSS 伪元素 `::before` 实现。伪元素不是 DOM 节点，不存在于 DOM 树中，因此 `querySelector(':before')` 返回 `null`，无法通过 JavaScript 直接操作伪元素的样式属性。

**错误写法**：
```javascript
// ❌ querySelector(':before') 返回 null，无法操作伪元素
panel.querySelector(':before')?.style.setProperty('left', `${arrowPosition}px`);
```

**正确写法**：通过 CSS 变量间接控制伪元素的位置。在面板元素（真实 DOM 节点）上设置 CSS 变量，伪元素会自动继承：

```css
.radio-panel::before {
  content: '';
  position: absolute;
  top: -4px;
  left: var(--arrow-left, 3px);  /* 读取CSS变量，默认3px */
  width: 8px;
  height: 8px;
  background: var(--color-blue-gray-l50);
  border-left: 1px solid var(--color-blue-gray-l10);
  border-top: 1px solid var(--color-blue-gray-l10);
  transform: rotate(45deg);
  transition: left 0.3s ease;
}
```

```javascript
// ✅ 在面板元素上设置CSS变量，伪元素自动继承
panel.style.setProperty('--arrow-left', `${arrowPosition}px`);
```

**适用范围**：所有需要通过 JavaScript 动态控制 CSS 伪元素样式的场景。

### 单选胶囊描边样式选中时右边框不显示

**问题描述**：单选胶囊组件使用 `margin-left: -1px` 实现边框重叠效果以避免双边框，但当描边样式的按钮被选中时，其右边框会被下一个按钮的左边框覆盖，导致视觉上右边框消失。

**原因分析**：按钮之间使用 `margin-left: -1px` 让边框重叠，选中按钮的边框颜色变为品牌色，但由于层叠顺序问题，右边框被相邻按钮的灰色左边框遮挡。

**解决方案**：为选中状态添加 `z-index: 1`，使选中的按钮显示在其他按钮上方，确保所有边框正常显示：

```css
.radio-capsule-wrapper.outline.selected {
  background: var(--color-gray-l60);
  border-color: var(--color-poseidon-blue-default);
  color: var(--color-poseidon-blue-default);
  z-index: 1;  /* 确保选中按钮显示在上方 */
}

.radio-capsule-wrapper.fill.selected {
  background: var(--color-poseidon-blue-default);
  color: var(--color-gray-l60);
  border-color: var(--color-poseidon-blue-default);
  z-index: 1;  /* 确保选中按钮显示在上方 */
}
```

**适用范围**：填充样式和描边样式的单选胶囊组件都需要添加此修复。

## 关联文档

- [颜色系统](../../design-system.md)
- [按钮组件](./按钮-Button.md)
- [复选框组件](./复选框-Checkbox.md)
- [表单组件](./输入框-Input.md)