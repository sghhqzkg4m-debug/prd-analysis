# 云BG设计规范-基础组件-侧边导航（Side Navigation）

/---

name: "云BG设计规范-基础组件-侧边导航（Side Navigation）"
description: "提供系统主功能入口的垂直导航规范。支持默认侧边导航的向下推拉（Accordion）折叠、收纳状态切换以及与全局导航的联动交互。多层侧边导航另有特别约束（待补充）。"
step:

1. 结构布局：确定侧边栏宽度（展开/收纳）及在页面中的层级。
2. 菜单配置：配置一级菜单（图标+文字）与二级菜单（推拉列表）。
3. 状态定义：定义Normal、Hover、Active及选中父级的高亮表现。
4. 交互逻辑：实现向下推拉动画及收纳态的Tooltip/Dropdown逻辑。
5. 代码生成：输出符合深信服云设计系统视觉规范的HTML/CSS代码，禁止硬编码颜色、图标等数值。

/---

[[toc]]

---

# 一、默认侧边导航（单层）

## 1. 功能说明

侧边导航（Side Navigation）是应用系统的核心功能索引，位于页面左侧。它承载了系统的业务模块分类，通过垂直排列的方式提供清晰的层级导航体验。

## 2. 组件构成

侧边导航由以下三个部分纵向排列组成：

* **顶部固定区 (Header)**：通常放置子系统名称、Logo图标，横向排列。固定在顶部，不随菜单滚动。
* **菜单滚动区 (Content)**：承载导航项，支持一级菜单与二级菜单的向下推拉，特殊情况时也可支持菜单分类，纵向排列。
* **底部操作区 (Footer)**：放置收纳切换按钮、用户信息（用户名、头像），纵向排列。固定在底部，不随菜单滚动。

---

## 3. 内容说明

侧边导航的内容布局根据展开态和收起态呈现不同的表现形式。

### 3.1 展开态

**侧边导航容器**：
- 宽度：`224px`
- 高度：撑满整个容器（100%）

**顶部固定区（Header）**：
- 容器高度：`52px`
- 宽度：与侧边导航容器同宽
- 左右内边距：`0px`
- **Logo区域**：
  - Logo 容器：正方形 `52px × 52px`
  - Logo 图标大小：`28px`
- **子系统名称**：
  - 从 Logo 容器右侧开始，左边距为 `52px`
  - 字号：`16px` 标题字
  - 垂直居中对齐

**菜单滚动区（Content）**：
- **一级导航容器**：
  - 高度：`40px`
  - 表格页/表单页模板中左右外边距：`0px`
  - 表格页/表单页模板中内边距：左 `18px`，右 `16px`
  - 表格页/表单页模板中圆角：`0px`
- **一级导航项组成**：业务图标 + 菜单文字 + 下拉图标
  - **业务图标**：
    - 位置：靠在容器最左侧
    - 图标大小：`16px`
  - **菜单文字**：
    - 位置：在业务图标右侧
    - 与业务图标间距：`8px`
    - 字号：`14px` 标题
  - **下拉图标**：
    - 位置：靠在容器最右侧
    - 仅在该一级导航有二级子菜单时才显示
    - 收起态图标：`vtv-icon-comp-arrow-down-big`
    - 展开态图标：`vtv-icon-comp-arrow-up-big`
    - 图标大小：`16px`
  - 图标来源：根据菜单语义从图标库自动匹配或用户自定义
- **二级导航项组成**：
  - 仅包含菜单文字
  - 字号：`12px`
- **二级导航容器**：
  - 高度：`36px`
  - 表格页/表单页模板中左内边距：`48px`
- **分类标签**（默认不显示）：
  - 层级：与一级导航同级，不会被展开收起
  - 容器高度：`36px`
  - 左内边距：`20px`
  - 文字字号：`12px`
- **分割线**（默认不显示）：
  - 用途：用于一级导航之间隔开
  - 容器高度：`16px`
  - 容器左右内边距：`16px`
  - 分割线：线宽 `1px`，垂直居中

**底部操作区（Footer）**：
- **收纳切换按钮**：
  - 位置：在底部操作区最底部
  - 容器高度：`56px`
  - 上边框：`1px`
  - 左内边距：`18px`
  - 图标（展开态）：`vtv-icon-comp-menu-collapse`
  - 图标（收起态）：`vtv-icon-comp-menu-expand`
  - 图标大小：`14px`
- **用户信息**：
  - 容器高度：`36px`
  - 容器左内边距：`16px`
  - **头像**：
    - 形状：圆形
    - 容器大小：`24px`
    - 头像图标：`vtv-icon-user-maintenance-fill`
    - 图标大小：`12px`
  - **用户名**：
    - 位置：在头像右侧
    - 与头像间距：`8px`
    - 字号：`12px`

### 3.2 收起态

**侧边导航容器**：
- 宽度：`52px`

**顶部固定区（Header）**：
- 仅显示 Logo 图标（不显示子系统名称）

**菜单滚动区（Content）**：
- 仅显示一级导航的业务图标
- 分类标签：不显示
- 分割线：不显示

**底部操作区（Footer）**：
- **用户信息**：仅显示用户头像（不显示用户名）
- **收纳切换按钮**：显示收起状态图标（`vtv-icon-comp-menu-expand`）

---

## 4. 视觉规范

### 4.1 设计Token使用规范

**禁止硬编码规则：**
生成代码时，文档中定义的所有设计Token（如颜色、间距、圆角、字体等）**必须**使用CSS变量引用，**禁止**直接使用硬编码值。

**正确示例：**
```css
color: var(--color-gray-d50);
border: 1px solid var(--color-blue-gray-l30);
```

**错误示例：**
```css
color: #404655;
border: 1px solid #EBEDF0;

### 4.2 颜色规范及语义规范

**颜色引用方式：**
生成代码时，将自然语言颜色转换为CSS变量格式：`{语义}.{色阶}` → `var(--color-{语义}-{色阶})`。

**颜色转换规则：**
生成代码时，将自然语言颜色转换为CSS变量格式：`{颜色名}.{色阶}` → `var(--color-{颜色名}-{色阶})`

#### 4.2.1 容器背景

| 元素 | 颜色值（变量） | 说明 |
| :--- | :--- | :--- |
| **侧边导航容器背景** | `gray.l60` | 主体背景 |
| **侧边导航容器阴影** | `graphite-black.l30` 8% 透明度 | 外阴影 `2px 0 4px 0` |
| **顶部固定区容器背景** | 透明 | - |
| **菜单滚动区容器背景** | 透明 | - |

#### 4.2.2 一级导航容器（不可展开二级菜单）

| 状态 | 背景 | 业务图标 | 文字 | 下拉图标 |
| :--- | :--- | :--- | :--- | :--- |
| **默认** | 透明 | `graphite-black.l30` | `graphite-black.l30` | `graphite-black.l20` 40% 透明度 |
| **悬浮/点击** | `blue-gray.l50` | 与默认相同 | 与默认相同 | 与默认相同 |
| **选中** | `poseidon-blue.default` | `gray.l60` | `gray.l60` | - |

#### 4.2.3 一级导航容器（可展开二级菜单）

| 状态 | 背景 | 业务图标 | 文字 | 下拉图标 |
| :--- | :--- | :--- | :--- | :--- |
| **默认** | 透明 | `graphite-black.l30` | `graphite-black.l30` | `graphite-black.l20` 40% 透明度 |
| **悬浮/点击** | `blue-gray.l50` | 与默认相同 | 与默认相同 | 与默认相同 |
| **无选中状态** | - | - | - | - |

#### 4.2.4 二级导航容器

| 状态 | 背景 | 文字 |
| :--- | :--- | :--- |
| **默认** | 透明 | `graphite-black.l30` |
| **悬浮/点击** | `blue-gray.l50` | `graphite-black.l30` |
| **选中** | `poseidon-blue.default` | `gray.l60` 加粗 |

### 4.3 尺寸规范

* **展开宽度**：`224px` 
* **收纳宽度**：`52px` (需与全局导航菜单按钮对齐)。
* **导航项高度**：
    * 一级导航：`40px`。
    * 二级导航：`36px`。
* **间距**：表格页/表单页模板采用全宽导航项，一级和二级导航项左右外间距 `0px`，宽度 `100%`，圆角 `0px`；一级导航通过 `padding: 0 16px 0 18px` 保持图标和文字位置，二级导航文字缩进 `48px`。不要生成带左右留白的圆角胶囊选中态。

---

## 5. 交互说明

### 5.1 向下推拉（Accordion）逻辑

* **触发方式**：点击一级导航整行区域。
* **交互形式**：下方二级列表向下平滑展开，属于页面内内容推移。
* **动画参数**：`height 0.2s ease-in-out`。建议使用 `grid-template-rows` 实现高度从 0 到 1fr 的平滑过渡。
* **排他性**：建议开启单开模式，即展开一个分组时自动收起其他已展开分组，避免导航栏过长。

### 5.2 嵌套层级视觉

* **二级菜单缩进**：文字起始位需与一级菜单文字水平对齐。
    * 计算公式：一级图标左间距 12px + 图标 16px + 间距 12px = **二级文字左内边距 40px**。
* **箭头反馈**：带子级的一级菜单右侧需展示 `12px` 箭头图标，展开时顺时针旋转 180°。

### 5.3 状态联动

* **父级高亮**：当二级项处于选中态（Active）时，其所属的一级父级应保持"文字高亮（White）"状态，但背景不着色，以提示当前归属。
* **收纳态处理**：
    * 当侧边栏宽度变为 `52px` 时，隐藏所有文字、箭头和分组标题。
    * **重要逻辑**：收纳态下禁止向下推拉。点击或悬浮图标应通过 **Dropdown（侧向弹出）** 形式展示二级菜单。

---

## 6. 前端实现指南

### 6.1 关键CSS结构建议

```css
/* 容器 */
.side-nav {
  width: var(--sidebar-width-expand, 224px);
  background: var(--color-gray-l60);
  transition: width 0.2s;
  display: flex;
  flex-direction: column;
}

/* 导航项基础 */
.nav-item {
  height: var(--nav-item-height-level1, 40px);
  width: 100%;
  margin: 0;
  display: flex;
  align-items: center;
  padding: 0 16px 0 18px;
  border-radius: 0;
  color: var(--color-graphite-black-l30);
  cursor: pointer;
  white-space: nowrap;
}

/* 导航项悬浮态 */
.nav-item:hover {
  background: var(--color-blue-gray-l40);
}

/* 导航项选中态 */
.nav-item.active {
  background: var(--color-poseidon-blue-default);
  color: var(--color-gray-l60);
}

/* 推拉容器动画 */
.sub-menu-wrapper {
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows 0.2s ease-in-out;
  overflow: hidden;
}
.sub-menu-wrapper.expanded {
  grid-template-rows: 1fr;
}

/* 二级导航项 */
.sub-nav-item {
  height: var(--nav-item-height-level2, 36px);
  width: 100%;
  margin: 0;
  padding-left: var(--subnav-indent, 48px);
  border-radius: 0;
  font-size: var(--font-size-xs, 12px);
  color: var(--color-graphite-black-l30);
}

/* 二级导航项悬浮态 */
.sub-nav-item:hover {
  background: var(--color-blue-gray-l40);
}

/* 二级导航项选中态 */
.sub-nav-item.active {
  background: var(--color-poseidon-blue-default);
  color: var(--color-gray-l60);
  font-weight: bold;
}
```

---

## 7. 常见问题 (FAQ)

### 7.1 菜单过多导致无法显示完全

**解决方案**：侧边栏菜单区设置 `overflow-y: auto`。滚动条样式建议定制为极细且仅在 Hover 时显现。

### 7.2 二级菜单标题过长

**解决方案**：禁止换行，使用 `text-overflow: ellipsis` 截断，并在悬浮时通过 Tooltip 显示全称。

### 7.3 与全局导航共存时的用户信息显示

**问题描述**：当侧边导航与全局导航共同存在于页面时，存在用户信息重复显示的问题。

**解决方案**：侧边导航的用户信息区域应设置为不显示，避免与全局导航中的用户信息重复。页面顶部全局导航已承载完整的用户信息和账户管理功能，侧边导航无需重复展示。

**设计原则**：
- 全局导航位于页面顶部，承载用户信息和账户管理的完整功能
- 侧边导航位于页面左侧，专注于导航功能
- 两者共存时，侧边导航应隐藏用户信息区域，保持功能单一性
- 侧边导航的底部操作区仅保留收纳切换按钮

### 7.4 关于语义化变量层的使用规范

**问题描述**：是否需要在设计Token之上增加一层语义化变量（如 `--nav-bg`、`--nav-icon-default`、`--nav-text-primary` 等）？

**官方规范**：**禁止使用语义化变量层**，必须直接使用设计系统定义的Token变量。

**错误示例（不推荐）**：
```css
/* 语义化变量层 - 不推荐 */
--nav-bg: var(--color-gray-l60);
--nav-icon-default: var(--color-graphite-black-l30);
--nav-text-primary: var(--color-graphite-black-l30);

/* 使用时 - 间接引用 */
.side-nav {
  background: var(--nav-bg);
}
.nav-item-icon {
  color: var(--nav-icon-default);
}
```

**正确示例（必须使用）**：
```css
/* 直接使用设计Token变量 */
.side-nav {
  background: var(--color-gray-l60);
}
.nav-item-icon {
  color: var(--color-graphite-black-l30);
}
.nav-item.active {
  background: var(--color-poseidon-blue-default);
  color: var(--color-gray-l60);
}
```

**禁止原因**：
1. **维护成本**：增加中间层会增加变量定义和维护的复杂度
2. **语义冗余**：设计Token本身已具备语义化命名（如 `--color-gray-l60`、`--color-poseidon-blue-default`）
3. **增加认知负担**：开发者需要记忆额外的语义化变量名
4. **降低透明度**：隐藏了真实的Token引用，不利于主题切换和全局样式调整
5. **违背设计系统原则**：设计系统Token就是为了统一使用，不应再封装

**Token命名规则参考**：
- 颜色：`--color-{颜色名}-{色阶}`（如 `--color-graphite-black-l30`）
- 间距：`--spacing-{尺寸}`（如 `--spacing-xs`、`--spacing-sm`）
- 圆角：`--radius-{尺寸}`（如 `--radius-sm`）
- 字号：`--font-size-{尺寸}`（如 `--font-size-xs`）

---

# 二、多层侧边导航

> **待补充**
>
> 多层侧边导航规范正在完善中，预计支持三级及以上的嵌套菜单场景。
>
> 如需紧急使用，请联系设计系统团队获取预览版本。

### 计划包含内容

* 三级及以上的嵌套菜单规范
* 多层级缩进计算规则
* 深层级导航的性能优化建议
* 移动端适配策略

---
