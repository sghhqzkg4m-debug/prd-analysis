---
name: "云 BG 设计规范 - 基础组件 - 标签页（tabs）"
description: "提供标签页组件的设计规范、最佳实践，依赖 skills/sxf-cloud-design-system/SKILL.md 中定义的设计规范。当用户需要设计或实现标签页组件时调用。"
step:
  1. 需求解析：理解用户需要创建的标签页类型（卡片式标签页、下划线标签页）
  2. 视觉设计：所有样式优先使用本技能文档预定义的尺寸规范和颜色规范，未定义部分则使用 skills/sxf-cloud-design-system/SKILL.md 中定义的设计规范
  3. 代码生成：按规范生成完整的 HTML、CSS 和 JavaScript 代码

ai_instructions:
  icon_usage_rules:
    - "必须使用本文档指定的图标类名，严禁使用其他图标替代"
    - "图标前缀统一为 vtv-icon-"
    - "严禁根据语义自行搜索图标，必须按清单使用"
  forbidden_substitutions:
    - "添加图标：必须使用 vtv-icon-add，严禁使用 plus、create 等"
    - "关闭图标：必须使用 vtv-icon-close-line，严禁使用 x、delete 等"
  checklist_before_generate:
    - "确认所有图标类名与图标清单一致"
    - "确认图标前缀为 vtv-icon-"
    - "确认没有使用任何通用图标替代组件专用图标"

---

# 标签页 Tabs

> ⚠️ **图标使用强制声明**：本组件所有图标必须使用下表指定的图标类名，**严禁**使用 `plus`、`x`、`delete` 等通用图标替代。

## 图标清单（强制）

| 位置 | 图标类名 | 尺寸 | 颜色 | 严禁使用 |
|------|----------|------|------|----------|
| 添加图标 | `vtv-icon-add` | 16px | 跟随标签文字颜色 | `plus`, `create`, `new` |
| 关闭图标 | `vtv-icon-close-line` | 16px | 跟随标签文字颜色 | `x`, `delete`, `remove` |

## 常见的错误与正确用法

| 场景 | ❌ 错误用法 | ✅ 正确用法 | 说明 |
|------|------------|------------|------|
| 添加图标 | `vtv-icon-plus` | `vtv-icon-add` | 必须使用组件专用添加图标 |
| 关闭图标 | `vtv-icon-x` | `vtv-icon-close-line` | 必须使用关闭图标 |

---

## 概述

标签页 Tab 包含一系列选项卡，用户可以通过每个选项卡在不同任务、视图、模式之间切换，它具有全局导航的作用，将区域内容进行合理的收纳和展现，让界面信息结构更清晰。

- **来源**：深信服云 BG 设计部
- **类型**：导航组件
- **适用场景**：
  - **卡片式标签页（投影样式）**：需要通过阴影区分层级的内容分区
  - **卡片式标签页（描边样式）**：需要通过边框区分层级的内容分区
  - **下划线标签页**：需要简洁风格的内容切换，如表单步骤、设置面板
  - **可关闭标签页**：需要动态添加/关闭标签的场景，如浏览器标签页

---

## 设计规范（统一入口）

### 尺寸规范

| 元素 | 尺寸 | 说明 |
|------|------|------|
| 容器高度 | 自适应 | 由标签高度决定 |
| 标签高度 | sm: 36px / md: 44px / lg: 48px | 三种尺寸可选 |
| 标签内边距 | 水平 20px | 垂直居中，无上下内边距 |
| 标签间距 | 8px | 标签之间间距（与 antd 一致） |
| 容器圆角 | 6px | 外容器圆角 |
| 标识线高度 | 2px | 选中状态标识线高度 |
| 字体大小 | 14px | 标签文字大小 |
| 行高 | 20px | 标签文字行高 |

### 颜色规范

**颜色 Token 格式**：`{颜色名}.{色阶}` → `var(--color-{颜色名}-{色阶})`

| 颜色名称 | Token 前缀 | 参考色值 |
|----------|-----------|----------|
| 波塞顿蓝 | poseidon-blue. | (参考：#1770E6) |
| 中性灰 | gray. | (参考：#CCCCCC) |
| 石墨黑 | graphite-black. | (参考：#242A33) |
| 蓝灰度 | blue-gray. | (参考：#CCD1D9) |

**设计 Token 使用规范**：
- ✅ **正确**：`color: var(--color-gray-d60);`
- ❌ **错误**：`color: #404655;`（禁止硬编码）

### 状态 Token

| 状态 | 背景 Token | 文字 Token | 标识线 |
|------|------------|------------|--------|
| 默认 | `--color-blue-gray-l50` | `--color-gray-d60` | 无 |
| 悬浮 | `--color-blue-gray-l60` | `--color-gray-d60` | 无 |
| 选中 | `--color-gray-l60` | `--color-poseidon-blue-default` | 顶部/底部 |
| 点击 | `--color-blue-gray-l40` | `--color-poseidon-blue-default` | 有 |
| 禁用 | `--color-blue-gray-l60` | `--color-gray-default` | 无 |

**过渡时长**：悬浮 0.2s / 点击 0.1s / 选中 0.3s

---

## 组件类型

| 类型 | 说明 | 备注 |
|------|------|------|
| 卡片式标签页 | 一般作为页面内容区一级标签页，相比下划线样式，此样式更强调 | • 默认选中第一项<br>• 支持横向/纵向2种样式 |
| 下划线标签页 | 一般作为页面内容区次级标签页（页面中与卡片式标签页共同使用时，下划线标签页层级更低） | • 默认选中第一项<br>• 仅支持横向样式 |
| 纵向轻量标签页 | 一般作为下划线标签的次级内容区划分，仅支持纵向样式 | • 默认选中第一项 |

---

## 类型与变体（差异说明）

### 卡片式标签页 - 投影样式（横向）

**组件层级**：一级标签页

**样式特征**：使用阴影区分层级，应用于浅灰色背景

**类型特定样式**：
- 外层容器背景：`blue-gray.l30`
- 标签栏容器：无背景、无边距、无圆角、高度自适应
- 默认标签背景：`blue-gray.l50`
- 选中标签背景：`gray.l60`
- 所有标签：无边框、无圆角
- 选中标识线位置：顶部
- 内容区域背景：`gray.l60`
- 内容区域：无边框、无圆角、小投影、最小高度 48px

**备注**：默认选中第一项

### 卡片式标签页 - 描边样式（横向）

**组件层级**：一级标签页

**样式特征**：使用边框区分层级

**类型特定样式**：
- 容器：带边框，无圆角，使用伪元素实现底部边框线
- 标签：使用 `inline-flex`，默认透明边框，激活时显示边框
- 选中状态边框：左右边框显示，上边框去除，下边框为 `gray.l60`（与内容区背景一致）
- 选中标签：`margin-bottom: -1px`，`z-index: 1`，遮住容器底部边框
- 选中标识线位置：顶部
- 面板：顶部边框保留，无圆角
- 实现要点：使用容器边框 + 标签透明边框方案，避免相邻标签双边框问题

**完整 CSS 实现**：
```css
.tabs-card-border {
  position: relative;
}

.tabs-card-border .tab {
  display: inline-flex;
  border: 1px solid var(--color-blue-gray-default);
  border-bottom: none;
  background: var(--color-blue-gray-l50);
  position: relative;
  margin-bottom: -1px;
  z-index: 0;
}

.tabs-card-border .tab.tab-active {
  background: var(--color-gray-l60);
  border-color: var(--color-blue-gray-default);
  border-bottom-color: var(--color-gray-l60);
  z-index: 1;
}

.tabs-card-border .tab.tab-active::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background-color: var(--color-poseidon-blue-l20);
}

.tabs-card-border .tab-panel {
  border: 1px solid var(--color-blue-gray-default);
  z-index: 0;
  position: relative;
}
```

**备注**：默认选中第一项

### 卡片式标签页 - 纵向样式

**组件层级**：一级标签页

**样式特征**：标签垂直排列，标识线位于右侧

**类型特定样式**：
- 容器：`flex-direction: column`
- 标签宽度：100%（填满容器宽度）
- 标签高度：40px（固定高度）
- 标签内边距：水平 16px，垂直 10px
- 标签间距：0（标签之间无间隙）
- 默认标签背景：`transparent`
- 选中标签背景：`gray.l60`
- 选中标识线位置：右侧
- 选中标识线宽度：3px
- 选中标识线颜色：`poseidon-blue.default`
- 内容区域：位于标签右侧，自适应宽度

**适用场景**：
- 侧边导航菜单
- 设置页面分类导航
- 需要节省水平空间的场景

**备注**：默认选中第一项

### 下划线标签页（横向）

**组件层级**：次级标签页（与卡片式共同使用时层级更低）

**样式特征**：通过下划线标识选中状态

**类型特定覆盖**：
- 背景始终为 `transparent`
- 容器底部边框：`1px solid var(--color-blue-gray-l30)`
- 选中标识线位置：底部
- 选中标识线颜色：`poseidon-blue.default`

**备注**：默认选中第一项；仅支持横向样式

### 纵向描边标签页（配置页面）

**组件层级**：下划线标签的次级内容区划分

**样式特征**：标签垂直排列，激活态标签白色背景与内容区域融为一体

**类型特定样式**：

| 元素 | 属性 | 值 |
|------|------|-----|
| 外层容器 | display / border | `flex` / `1px solid blue-gray.default` |
| 标签栏 | width / background / border-right | `200px` / `blue-gray.l50` / `1px solid blue-gray.default` |
| 标签 | height / padding | `48px` / `0 16px` |
| 内容区 | background / padding | `gray.l60` / `16px 32px` |

**状态样式**：

| 状态 | 背景 | 文字 | 边框 |
|------|------|------|------|
| 默认 | `transparent` | `gray.d60` | 无 |
| 悬浮 | `blue-gray.l60` | `gray.d60` | 无 |
| 选中 | `gray.l60` | `poseidon-blue.default` | 上下边框 `blue-gray.default` |

**实现要点**：
- 未激活标签无边框，使用 `::after` 伪元素实现底部分隔线
- 激活标签通过 `margin-right: -1px` 和白色背景遮蔽右侧容器边框
- 层级控制：`z-index: 2`（激活标签）> `z-index: 1`（标签栏）

**适用场景**：
- 复杂配置页面
- 设置向导
- 需要清晰区分标签层级的场景

**备注**：默认选中第一项

---

## 实现指南

### CSS 样式（设计 Token）

```css
/* 基础变量 */
:root {
  --tab-height: 36px;
  --tab-padding: 8px 20px;
  --tab-gap: 8px;
  --tab-indicator-height: 2px;
}

/* 基础容器 */
.tabs {
  display: flex;
  gap: var(--tab-gap);
}

/* 基础标签 */
.tab {
  height: var(--tab-height);
  padding: var(--tab-padding);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease-in-out;
  border: none;
  background-color: var(--color-blue-gray-l50);
  color: var(--color-gray-d60);
}

/* 状态样式 */
.tab:hover { background-color: var(--color-blue-gray-l60); }
.tab-active { 
  background-color: var(--color-gray-l60); 
  color: var(--color-poseidon-blue-default);
  position: relative;
}
.tab:active { background-color: var(--color-blue-gray-l40); }
.tab-disabled { opacity: 0.4; cursor: not-allowed; }
.tab:focus-visible { box-shadow: 0 0 0 3px rgba(23, 112, 230, 0.2); }

/* 卡片式投影 */
.tabs-card-shadow { box-shadow: var(--shadow-sm); }
.tabs-card-shadow .tab-active::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: var(--tab-indicator-height);
  background-color: var(--color-poseidon-blue-l20);
}

/* 卡片式描边 - 完整实现 */
.tabs-card-border {
  position: relative;
}

.tabs-card-border .tab {
  display: inline-flex;
  border: 1px solid var(--color-blue-gray-default);
  border-bottom: none;
  background: var(--color-blue-gray-l50);
  position: relative;
  margin-bottom: -1px;
  z-index: 0;
}

.tabs-card-border .tab-active {
  background: var(--color-gray-l60);
  border-color: var(--color-blue-gray-default);
  border-bottom-color: var(--color-gray-l60);
  z-index: 1;
}

.tabs-card-border .tab-active::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background-color: var(--color-poseidon-blue-l20);
}

.tabs-card-border .tab-panel {
  border: 1px solid var(--color-blue-gray-default);
  z-index: 0;
  position: relative;
}

/* 下划线 */
.tabs-underline { border-bottom: 1px solid var(--color-blue-gray-l30); }
.tabs-underline .tab { background-color: transparent; }
.tabs-underline .tab-active::after {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: var(--tab-indicator-height);
  background-color: var(--color-poseidon-blue-default);
}

/* 垂直型 */
.tabs-vertical {
  flex-direction: column;
  gap: 0;
  width: 200px;
}

.tabs-vertical .tab {
  width: 100%;
  height: 40px;
  padding: 10px 16px;
  justify-content: flex-start;
  background-color: transparent;
  border: none;
}

.tabs-vertical .tab:hover { background-color: var(--color-blue-gray-l50); }

.tabs-vertical .tab-active {
  background-color: var(--color-gray-l60);
}

.tabs-vertical .tab-active::after {
  content: '';
  position: absolute;
  right: 0;
  top: 0;
  bottom: 0;
  width: 3px;
  background-color: var(--color-poseidon-blue-default);
}

/* 纵向描边 */
.tabs-vertical-border-wrapper {
  display: flex;
  background-color: #fff;
  border: 1px solid var(--color-blue-gray-default);
  position: relative;
}

.tabs-vertical-border {
  position: relative;
  flex-direction: column;
  width: 200px;
  background-color: var(--color-blue-gray-l30);
  margin-right: -1px;
}

.tabs-vertical-border .tab {
  width: 100%;
  height: 48px;
  padding: 0 16px;
  justify-content: flex-start;
  background-color: transparent;
  position: relative;
  z-index: 0;
}

.tabs-vertical-border .tab:hover {
  background-color: var(--color-blue-gray-l60);
}

.tabs-vertical-border .tab:active {
  background-color: var(--color-blue-gray-l40);
}

.tabs-vertical-border .tab.tab-active {
  background-color: #fff;
  color: var(--color-poseidon-blue-default);
  border-right: 1px solid #fff;
  border-left: 1px solid #fff;
  z-index: 1;
  position: relative;
}

.tabs-vertical-border ~ .tab-panel {
  flex: 1;
  padding: 16px 32px;
  background-color: #fff;
  border-left: 1px solid var(--color-blue-gray-default);
  position: relative;
  z-index: 0;
}

/* 标签面板 */
.tab-panel {
  padding: 24px;
  background-color: var(--color-gray-l60);
  border: 1px solid var(--color-blue-gray-default);
}
```

### JavaScript 交互

```javascript
class Tabs {
  constructor(container) {
    this.container = container;
    this.tabs = container.querySelectorAll('[role="tab"]');
    this.panels = container.querySelectorAll('[role="tabpanel"]');
    this.init();
  }
  
  init() {
    this.tabs.forEach((tab, index) => {
      tab.addEventListener('click', () => this.selectTab(index));
      tab.addEventListener('keydown', (e) => this.handleKeydown(e, index));
    });
  }
  
  selectTab(index) {
    this.tabs.forEach((tab, i) => {
      const isActive = i === index;
      tab.classList.toggle('tab-active', isActive);
      tab.setAttribute('aria-selected', isActive);
      tab.setAttribute('tabindex', isActive ? '0' : '-1');
      this.panels[i]?.toggleAttribute('hidden', !isActive);
    });
    this.tabs[index].focus();
  }
  
  handleKeydown(e, index) {
    const keys = { ArrowLeft: -1, ArrowRight: 1, Home: -index, End: this.tabs.length - 1 - index };
    if (keys[e.key]) {
      e.preventDefault();
      const newIndex = (index + keys[e.key] + this.tabs.length) % this.tabs.length;
      this.selectTab(newIndex);
    }
  }
}

document.querySelectorAll('.tabs').forEach(t => new Tabs(t));
```

---

## 可访问性

### 键盘导航

| 按键 | 行为 |
|------|------|
| `Tab` | 聚焦当前选中标签 |
| `←` / `→` | 切换标签 |
| `Home` / `End` | 跳转首尾标签 |

### ARIA 属性

```html
<div role="tablist" aria-label="资源管理">
  <button role="tab" aria-selected="true" aria-controls="panel-1" id="tab-1">概览</button>
</div>
<div role="tabpanel" id="panel-1" aria-labelledby="tab-1"></div>
```

### 对比度

- 默认/选中文字：符合 WCAG AA 标准
- 禁用状态：允许较低对比度

---

## 响应式

```css
@media (max-width: 768px) {
  .tabs { overflow-x: auto; scrollbar-width: none; }
  .tabs::-webkit-scrollbar { display: none; }
  .tab { min-width: 80px; flex-shrink: 0; }
}
```

---

## 图标使用

| 场景 | 图标 | 位置 |
|------|------|------|
| 关闭标签 | vtv-icon-close-line | 标签右侧 |
| 添加标签 | vtv-icon-add | 标签栏末尾 |

---

## 最佳实践

### 命名规范

- **组件集**：`componentset-tabs`
- **变体**：
  - `tabs-card-shadow` - 卡片式投影
  - `tabs-card-border` - 卡片式描边
  - `tabs-underline` - 下划线
  - `tab-item` - 单个标签项
  - `tab-panel` - 标签面板

### 使用原则

1. **层级清晰**：选中状态应明显区别于未选中状态
2. **标签适量**：建议不超过 7 个，避免信息过载
3. **语义明确**：标签名称简洁明了，体现内容分类
4. **状态可见**：所有状态都必须可区分，尤其是禁用状态
5. **无障碍支持**：键盘导航必须可用，聚焦状态必须可见
6. **动画适度**：切换动画 0.2-0.3s 为宜
7. **关闭确认**：关闭重要标签前提供确认提示
8. **新增位置**：添加按钮放置在标签栏末尾

---

## 高约束规则（强制执行）

### 引用触发条件

识别到以下关键词时，**必须**引用本文档：
- "标签页"、"tabs"
- "选项卡"、"tab"
- "卡片式标签页"、"Card Tabs"
- "下划线标签页"、"Underline Tabs"
- "可关闭标签"、"Closable Tab"

### 强制遵守要求

| 要求 | 说明 |
|------|------|
| **禁止自定义颜色** | 颜色值必须从本文档选取，禁止自行推断 |
| **禁止自定义尺寸** | 尺寸必须严格遵循本文档规范 |
| **禁止省略状态** | 必须包含：默认、悬浮、选中、点击、禁用 五种状态 |
| **禁止跨变体混合** | 每个变体有独立规范，禁止混合样式 |
| **禁止错误图标** | 必须使用文档指定的图标类名 |

### 验证清单

- [ ] 颜色是否来自文档规定的 CSS 变量
- [ ] 尺寸是否符合尺寸规范表
- [ ] 是否包含全部 5 种状态样式
- [ ] 变体名称是否与文档一致
- [ ] 图标类名是否与图标清单一致
- [ ] 标识线位置和颜色是否正确
- [ ] 是否实现键盘导航支持
- [ ] 对比度是否达到 WCAG AA 标准

---

## 规则总结

### 变体选择指南

| 使用场景 | 推荐变体 | 关键特征 |
|----------|----------|----------|
| 浅灰背景、需要阴影层级 | 卡片式投影 | 阴影区分、标识线顶部 |
| 白色背景、需要边框层级 | 卡片式描边 | 边框分隔、激活标签遮罩 |
| 简洁风格、表单步骤 | 下划线 | 透明背景、底部标识线 |
| 侧边导航、设置页面 | 垂直型 | 标识线右侧、3px宽度 |
| 配置页面、复杂向导 | 纵向描边 | 边框分隔、选中白色背景 |

### 核心设计原则

1. **统一激活态背景**：所有变体的选中标签背景统一为 `gray.l60`（纵向描边为 `white`）
2. **标识线规范**：
   - 水平变体：顶部或底部，2px高度
   - 垂直变体：右侧，3px宽度
   - 颜色：`poseidon-blue.l20` 或 `poseidon-blue.default`
3. **边框处理**：
   - 卡片式描边：激活标签 `margin-bottom: -1px` 遮罩内容边框
   - 纵向描边：容器带 1px 边框，标签栏右边框分隔
4. **尺寸规范**：
   - 标签高度：sm 36px / md 44px / lg 48px
   - 标签间距：8px（水平）/ 0（垂直）
   - 内容区内边距：16px 32px（纵向描边）/ 24px（其他）

### 颜色使用规范

| 元素 | 颜色 Token | 说明 |
|------|------------|------|
| 默认标签背景 | `blue-gray.l50` | 浅灰背景 |
| 悬浮标签背景 | `blue-gray.l60` | 稍浅 |
| 选中标签背景 | `gray.l60` | 统一激活态 |
| 选中标签文字 | `poseidon-blue.default` | 品牌蓝色 |
| 内容区域背景 | `gray.l60` / `white` | 根据变体调整 |
| 边框颜色 | `blue-gray.default` | 统一边框色 |

### 图标强制规范

- 添加图标：`vtv-icon-add`（16px）
- 关闭图标：`vtv-icon-close-line`（16px）
- 禁止替代：严禁使用 `plus`、`x`、`delete` 等通用图标

---

## 关联文档

- [颜色系统](../../design-system.md)
- [阴影系统](../../design-system.md)
- [全局导航组件](./全局导航-GlobalNavigation.md)
- [按钮](./按钮-Button.md)
