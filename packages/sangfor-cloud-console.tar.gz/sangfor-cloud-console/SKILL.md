---
name: sangfor-cloud-console
description: 当需要创建或修改深信服云 BG 控制台 HTML 项目时使用。适用于由多个单页 HTML 组成的后台管理项目，以及资源表格页、表单页、列表页、功能介绍页、详情页等必须贴合深信服云 BG 视觉体系的页面。
---

# 深信服云控制台

创建贴近生产环境的深信服云 BG 控制台页面。项目可以包含多个页面，规则是一个页面一个 HTML。每个 HTML 默认尽量自包含，CSS 和页面 JavaScript 内联；图片、图标资源可以共享。

## 核心原则

1. **控制台优先**：生成真实可用的管理界面，不做营销页或落地页。
2. **还原模板**：匹配深信服云 BG 的布局密度、字号、颜色、侧边导航、表格和表单行为。
3. **一页一 HTML**：多页面项目使用多个独立 HTML 文件，页面之间用普通相对链接跳转。
4. **默认自包含**：页面级 CSS 和 JavaScript 写在 HTML 内；图片和图标资源允许放在共享资源目录。
5. **浏览器自适应**：页面要根据浏览器尺寸自适应。全局导航和侧边导航保持稳定，滚动发生在内容区或组件内部。

## 视觉语言

目标界面是高密度企业级云管理控制台：

- 顶部使用石墨黑全局导航。
- 左侧使用白色侧边导航。
- 页面画布使用浅蓝灰背景。
- 表单、表格、详情、列表主体使用白色内容面板。
- 主操作、选中态、当前步骤使用波塞冬蓝。
- 默认界面文字保持紧凑：正文 12px，字段和控件 14px，导航/产品标题 16px。
- 使用模板定义的小圆角、层级样式、紧凑间距和清晰的操作层级；表单主内容卡片不得因这条规则额外添加投影或描边。

避免营销式构图、大 Hero、大圆角卡片、装饰渐变、大面积留白、随意换色，以及通用 SaaS Dashboard 风格。

## 响应式规则

这些约束适用于所有页面：

- `body` 不作为主要滚动容器。
- 顶部全局导航固定高度，左侧导航固定宽度。
- 主内容区使用 flex 伸缩，内部区域负责滚动。
- 1366px 宽场景必须贴近设计稿比例。
- 窄屏时优先通过组件内部滚动、表格横向滚动或面板横向承载来适配，不随意改变设计稿规定的内容区留白。
- 表单页的横向步骤条和表单项不允许因为窄屏错行、变成两行或变成上下结构。
- 文本不得重叠或溢出按钮、输入框、表格单元格。

## 模板和组件锁定

顶部全局导航、服务目录入口、侧边导航、内容区容器和滚动结构属于页面壳层，必须从对应模板复用，不得按业务页面重新发明。除非用户明确提出要修改顶部导航或服务目录，否则顶部导航和服务目录必须整块全量复用模板，包括 DOM 层级、class、基础 CSS、图标、图片资源、文案、产品分组、搜索框、交互和显隐逻辑；不要为了贴合业务主题替换、删减或简化。侧边导航只允许修改项目名、菜单文案、菜单数量、跳转链接、当前高亮项和业务菜单图标；不得修改壳层 DOM 层级、class、基础 CSS、尺寸、展开收起行为和服务目录接入方式。

壳层图标必须保留模板指定 symbol：服务目录入口图标、侧边导航展开/收起图标不得替换为业务图标或语义相近的 arrow、menu、collapse 图标。不要新增可见的“收起导航”“展开导航”等控件文案；业务菜单图标可以按语义替换，但必须来自 `assets/iconfont/icon-symbols.html` 的真实 `vtv-icon-*`。

页面正文用到哪个组件，就必须先按 [component-reading-map.md](component-reading-map.md) 读取对应 `references/components/` 文档。读取后必须复用组件文档中的 DOM 层级、class、尺寸、状态、图标和交互规则，只允许替换字段名、选项、文案、默认值、mock 数据和业务事件。

禁止用原生 `<select>`、临时 `.input`、`.select`、`.alert`、`.notice`、`.tip` 等泛化 class 冒充设计系统组件；禁止用业务区内联 `style` 临时拼组件布局。如果组件文档缺失，选择最接近的已有组件并在交付说明中说明，不得自造新规范。

表单页、详情页、配置页和测试页的主内容卡片样式以 `templates/form-page/form-page.html` 的 `.form-panel` 实际 CSS 为准。不得用 `.panel`、`.card`、`.content-card`、`.compare-card` 或 `.trace-canvas` 重新定义主内容卡片；不得给 `.form-panel` 添加 `border`、`box-shadow`、临时 `margin`、临时 `height` 或临时 `flex`。若文字规范与模板 CSS 冲突，以模板 CSS 为准。

---

## Phase 0：判断模式

先判断用户任务属于哪一种：

- **模式 A：新建多页面项目**：根据用户需求批量生成多个 HTML 页面。
- **模式 B：新建单页面**：根据页面类型选择对应模板生成一个 HTML。
- **模式 C：修改已有页面**：先读取已有 HTML，保留原有壳层和组件风格后再修改。
- **模式 D：根据需求生成页面**：用户提供需求内容后，自动推断页面清单和页面类型，并生成 HTML 文件。
- **模式 E：扩展模板**：补充或优化本 skill 的模板、参考文档和可复用资源。

需要需求文档时由用户输入。除非用户明确要求，不要主动输出需求文档。

## Phase 1：需求解析

读取用户需求，确认：

- 项目名称或模块名称。
- 需要生成单页面还是多页面。
- 页面类型和页面清单。
- 每个页面的核心字段、主要操作和跳转关系。
- 是否有 MasterGo / Seer Design 设计链接。
- 是否需要 mock 数据和页面内交互。

解析页面清单前先读取 [interaction-patterns.md](interaction-patterns.md)，把每个业务动作归类为主页面、对话框、抽屉、下钻页或跨系统跳转。不要把创建、编辑、查看、测试、部署、连接、删除、查看地址等动作自动拆成独立页面或左侧菜单。只有模块级主页面、复杂下钻详情页、长表单或多步骤流程才生成独立 HTML；轻量创建/编辑优先用对话框，行内查看/测试/诊断/地址/日志/结果对比优先用抽屉，跨系统动作表达为跳转或新窗口。

如果用户没有给完整页面清单，读取 [page-selection.md](page-selection.md) 自动推断，并在交付说明中写清假设。

## Phase 2：设计稿读取

当用户提供 MasterGo / Seer Design 链接时，必须使用 Computer Use 或等价的界面读取工具查看真实设计页面。设计页面可访问时，不要只根据截图判断。

查看设计页面时至少确认：

- 当前选中的画板名称和页面类型。
- 右侧标注面板中的画板尺寸。
- 左侧图层中的模板名称和变体名称。
- 右侧面板展示的填充色、间距、位置和布局比例。
- 当前模板是基础表单、横向步骤条、纵向步骤条、左 Tab 表单、表格页，还是其他页面类型。

除非用户明确要求，不要在设计工具里编辑、评论、分享、导出或提交任何内容。

## Phase 3：页面类型与模板选择

根据意图选择模板：

- 资源管理、数据查询、日志、任务：表格页，读取 [table-page.md](table-page.md)。
- 创建、编辑、申请、配置、开通：表单页，读取 [form-page.md](form-page.md)。
- 消息、事件、告警、任务流：列表页，读取 [list-page.md](list-page.md)。
- 产品能力、服务开通说明、功能概览：功能介绍页，读取 [feature-intro-page.md](feature-intro-page.md)。
- 单个资源查看、配置汇总、关联资源：详情页，按表格页/表单页规则组合；从列表页、父级页面或其他资源页进入的下钻详情页必须使用表单页模板的面包屑头部，不使用普通标题栏。
- 有分类或层级筛选的管理场景：左树 + 表格页。
- 多阶段开通或配置流程：步骤条表单页。

生成表单页时，使用 [templates/form-page/form-page.html](templates/form-page/form-page.html) 作为基准模板。生成表格页时，优先使用 [templates/table-page/带侧边导航.html](templates/table-page/带侧边导航.html) 作为基准模板。生成列表页时，按 [list-page.md](list-page.md) 选择 [templates/list-page/basic-list-page.html](templates/list-page/basic-list-page.html)、[templates/list-page/overview-list-page.html](templates/list-page/overview-list-page.html)、[templates/list-page/collapse-list-page.html](templates/list-page/collapse-list-page.html)、[templates/list-page/card-list-page.html](templates/list-page/card-list-page.html)。生成功能介绍页时，使用 [templates/feature-intro-page/feature-intro-page.html](templates/feature-intro-page/feature-intro-page.html) 作为基准模板；修改已有功能介绍页时，优先保留正文规范，只替换导航和必要壳层。

页面变体也必须沿用对应页面模板的框架。左树右表、详情页、步骤条表单、左 Tab 表单、复杂筛选表格等变体，先继承最接近的页面模板壳层、内容区滚动结构、间距、颜色 token、导航和基础 class，再在业务内容区按需调整布局或组合组件。详情页、配置页、编辑页等下钻页面必须继承 `templates/form-page/form-page.html` 的面包屑区域，面包屑第一项承担返回入口，不要生成 `.title-bar`、蓝色竖线标题或单独“返回 xxx”按钮替代面包屑。只有现有模板无法覆盖页面骨架时，才根据 [component-reading-map.md](component-reading-map.md) 读取组件规范自定义页面；自定义页面仍必须复用最接近模板的全局导航、侧边导航、内容区容器和验收规则。

页面类型选择时必须复核 [interaction-patterns.md](interaction-patterns.md)：模块主入口通常是表格页或列表页；短创建/编辑表单不生成表单页，改为对话框；行内查看、测试、诊断、查看地址、日志、结果对比不生成详情页，优先用抽屉；部署、发布、同步到外部平台等跨系统动作不生成本地伪页面。

## Phase 4：生成页面

生成规则：

- 每个页面输出一个独立 `.html` 文件。
- 多页面项目读取 [project-structure.md](project-structure.md)。
- 页面级 CSS 和 JavaScript 内联。
- 共享图片和图标资源可以放在输出项目的 `assets/` 目录。
- 生成正文前先列出本页组件清单，再按 [component-reading-map.md](component-reading-map.md) 读取对应 `references/components/` 组件规范；表单、选择器、输入框、按钮、步骤条、面包屑、导航、提示条、表格和分页等不得凭经验手写一套新规范。
- 生成交互前先列出本页动作清单，并标注每个动作的载体：页面跳转、对话框、抽屉、跨系统跳转或行内状态变化。实现必须与 [interaction-patterns.md](interaction-patterns.md) 一致。
- 组件必须复用对应文档的 DOM 层级、class、尺寸、状态、图标和交互规则。只允许替换字段名、选项、文案、默认值、mock 数据和业务事件。
- 禁止用原生 `<select>`、临时 `.input`、`.select`、`.alert`、`.notice`、`.tip` 等泛化 class 冒充设计系统组件；禁止用业务区内联 `style` 临时拼组件布局。
- 表单类页面必须复用 `templates/form-page/form-page.html` 的 `.form-panel`、`.form-scroll`、`.form-body`、`.form-section` 和 `.form-footer`。普通内容分组使用 `.form-section` 或组件内部结构，不额外套描边卡片或投影卡片。
- 图标必须优先使用 `assets/iconfont/icon-symbols.html` 中的 `vtv-icon-*`，禁止用临时手写 SVG path 替代图标库；禁止新造 `i-*`、`icon-*` 等临时 symbol。单文件 HTML 可通过内联真实 `vtv-icon-*` symbol 或相对路径 `<use href="assets/iconfont/icon-symbols.html#vtv-icon-xxx">` 引用。
- 设计系统颜色、字号、间距、阴影读取 [design-system.md](design-system.md)。
- 侧边导航必须复用表格页模板中的 class、结构和行为。导航文案、数量、链接和当前项可以修改；容器、展开收起控件、基础 CSS 和图标显隐规则不得修改。
- 服务目录导航是独立壳层模板，读取 [service-catalog-nav.md](service-catalog-nav.md)。所有带顶部全局导航的生成页面，都必须自动把左上角菜单按钮关联到服务目录浮层；除非用户明确要求修改服务目录，否则必须全量复用服务目录模板，不替换产品分组、图片资源、搜索框结构、图标和交互；服务目录作为页面壳层能力接入，不属于业务页面正文。

## Phase 5：验收与交付

交付前读取 [acceptance-checklist.md](acceptance-checklist.md) 检查：

- 每个生成的 HTML 都可以独立打开。
- 页面壳层使用固定顶部全局导航和左侧导航。
- `body` 不作为主要滚动容器。
- 主内容区能适配常见浏览器尺寸，尤其是 1366px 宽的设计稿场景。
- 文本不重叠，不溢出按钮、输入框、选择器、表格单元格。
- 按钮、输入框、步骤条、表格、侧边导航使用深信服云 BG 的颜色和密度。
- 多页面项目中的链接可以跳转。

---

## 支持文件

| 文件 | 用途 | 读取时机 |
| --- | --- | --- |
| [design-system.md](design-system.md) | 深信服云 BG 设计系统总规范 | 需要颜色、字体、间距、阴影、品牌风格时 |
| [page-selection.md](page-selection.md) | 页面类型选择规则 | Phase 1 / Phase 3 |
| [interaction-patterns.md](interaction-patterns.md) | 产品交互载体和页面拆分规则 | Phase 1 / Phase 3 / Phase 4 |
| [project-structure.md](project-structure.md) | 多页面 HTML 项目结构规则 | Phase 4 |
| [component-reading-map.md](component-reading-map.md) | 组件文档读取顺序 | Phase 4 |
| [acceptance-checklist.md](acceptance-checklist.md) | 验收检查清单 | Phase 5 |
| [table-page.md](table-page.md) | 表格页规则和模板使用方式 | 创建或修改表格页 |
| [form-page.md](form-page.md) | 表单页布局、变体和还原规则 | 创建或修改表单页 |
| [list-page.md](list-page.md) | 列表页规则和模板使用方式 | 创建或修改列表页 |
| [feature-intro-page.md](feature-intro-page.md) | 功能介绍页规则和模板使用方式 | 创建或修改功能介绍页 |
| [global-navigation.md](global-navigation.md) | 顶部全局导航摘要规则 | 修改壳层导航时 |
| [service-catalog-nav.md](service-catalog-nav.md) | 服务目录导航规则和模板使用方式 | 创建或复用产品与服务目录 |
| [side-navigation.md](side-navigation.md) | 左侧导航摘要规则 | 修改侧边导航时 |
| [templates/form-page/form-page.html](templates/form-page/form-page.html) | 表单页独立 HTML 基准模板 | 创建表单页 |
| [templates/table-page/带侧边导航.html](templates/table-page/带侧边导航.html) | 带侧边导航的表格页基准模板 | 创建表格页或复用侧边导航 |
| [templates/table-page/statistics-table-page.html](templates/table-page/statistics-table-page.html) | 统计表格页模板，复用概览列表框架并将列表替换为表格 | 创建资源概览、指标统计、报表汇总类表格页 |
| [templates/list-page/basic-list-page.html](templates/list-page/basic-list-page.html) | 基础列表页独立 HTML 基准模板 | 创建基础列表页 |
| [templates/list-page/overview-list-page.html](templates/list-page/overview-list-page.html) | 概览列表页占位模板 | 创建概览列表页 |
| [templates/list-page/collapse-list-page.html](templates/list-page/collapse-list-page.html) | 折叠列表页占位模板 | 创建折叠列表页 |
| [templates/list-page/card-list-page.html](templates/list-page/card-list-page.html) | 卡片列表页占位模板 | 创建卡片列表页 |
| [templates/feature-intro-page/feature-intro-page.html](templates/feature-intro-page/feature-intro-page.html) | 功能介绍页独立 HTML 基准模板 | 创建功能介绍页或替换功能介绍页导航 |
| [templates/service-catalog-nav/service-catalog-nav.html](templates/service-catalog-nav/service-catalog-nav.html) | 服务目录导航独立 HTML 基准模板 | 创建或复用产品与服务目录 |
