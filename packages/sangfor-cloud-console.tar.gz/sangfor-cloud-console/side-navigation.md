# 侧边导航摘要

完整规范见 `references/components/侧边导航-SideNavigation.md`。HTML 基准见 `templates/table-page/带侧边导航.html`。

## 必须保留

- 展开宽度 224px。
- 收起宽度 52px，必须与顶部全局导航菜单按钮宽度对齐。
- 白色背景。
- 轻阴影。
- 顶部子系统名称区域高度 52px，Logo 容器 52×52px，标题从 Logo 右侧起始。
- 中部导航滚动区。
- 底部收起按钮。
- 底部展开/收起按钮的 DOM、class、图标 symbol 和显隐逻辑。
- 一级导航高度 40px，hover/选中背景横向铺满侧边导航容器，外边距 0px，圆角 0px；通过内部 padding 保持图标和文字位置。
- 二级导航高度 36px，hover/选中背景横向铺满侧边导航容器，外边距 0px，圆角 0px；文字缩进 48px。
- 一级导航右侧展开/收起箭头距离侧边导航容器右侧 16px；不要在箭头自身再叠加右外边距。
- 选中态使用波塞冬蓝背景。

## 生成规则

- 尽量复用参考 HTML 的 class。
- 侧边导航样式和壳层控件必须复用模板；导航内容可以按业务修改，包括子系统名称、一级/二级菜单文案、菜单数量、层级关系、当前高亮项和业务菜单图标语义。
- 当前页面对应导航项必须高亮。
- 选中态和 hover 态不得做成带左右留白的圆角胶囊；必须铺满侧边导航宽度。
- 表格页和表单页必须采用模板覆盖规则：`.nav-item` 和 `.sub-nav-item` 均为 `width: 100%`、`margin: 0`、`border-radius: 0`，通过内部 padding 控制图标和文字位置。
- 不要把组件详细文档里的 8px 左右外边距、4px 圆角导航项应用到表格页或表单页壳层。
- 有子菜单时使用向下推拉结构。
- 收起态隐藏业务菜单文字，只保留业务菜单图标。
- 展开/收起控件不得新增可见文案，例如“收起导航”“展开导航”。如果模板内部包含辅助文本，只能用于无障碍或折叠显隐，不得作为页面可见说明文字展示。

## 壳层图标锁定

- 侧边导航展开/收起按钮属于壳层控件，必须保留模板原始 icon symbol、class、尺寸和旋转/显隐逻辑。
- 不要用 `vtv-icon-arrow-left`、`vtv-icon-arrow-down`、`vtv-icon-menu`、`vtv-icon-collapse` 或业务模块图标替代模板中的展开/收起控件图标，除非模板本身就是该 symbol。
- 一级导航的子菜单展开箭头必须保留模板指定 symbol 和位置，不得因为菜单文案变化而替换。
- 业务菜单图标可以按菜单语义替换，但只能从 `assets/iconfont/icon-symbols.html` 选择真实 `vtv-icon-*`，不得手写 path 或临时 symbol。

## 云主机控制台图标映射

生成云主机管理、表格页或表单页时，侧边导航优先使用下列图标。所有图标必须来自 `assets/iconfont/icon-symbols.html`；单文件 HTML 可以内联这些 symbol，但不得手写替代 path。

| 导航位置 | 图标 |
| --- | --- |
| 子系统标题：云主机管理 | `vtv-icon-vm-cloud-fill` |
| 总览 | `vtv-icon-home` |
| 云主机 | `vtv-icon-vm` |
| 镜像 | `vtv-icon-app-line` |
| 云硬盘 | `vtv-icon-storage` |
| 网络 | `vtv-icon-internet-line` |
| 安全组 | `vtv-icon-security-line` |
| 监控告警 | `vtv-icon-surveillance-camera-line` |

不要使用语义接近但视觉差异明显的图标替代，例如不要用普通云朵表示“云主机管理”，不要用图片图标表示“镜像”，不要用显示器图标表示“监控告警”。
