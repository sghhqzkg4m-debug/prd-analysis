# 完整图标映射表

> 共 950 个图标

## 使用说明

本表包含图标库中的所有 950 个图标。

### 使用方式

如果你想使用某个图标，可以：

1. **直接告诉 AI 图标名称**，例如：
   ```
   使用"标签"图标
   添加一个"新增"按钮
   使用"首页"图标
   ```

2. **直接使用 Symbol ID**，例如：
   ```
   使用 vtv-icon-sold-out-fill 这个图标
   ```

3. **如果知道 Unicode**，可以在 `icon-unicode-map.json` 中查找对应的 Symbol ID

### 格式说明

```html
<!-- HTML 使用方式 -->
<svg class="icon"><use href="#vtv-icon-{font_class}"></use></svg>
```

---

## 完整映射表

| Unicode | 图标名称 | font_class | Symbol ID |
|---------|---------|-----------|-----------|
| &#x53d1; | 发票 | invoice | vtv-icon-invoice |
| &#xe602; | 未知 | unknow-line | vtv-icon-unknow-line |
| &#xe603; | 共享 | share-line | vtv-icon-share-line |
| &#xe606; | 安全_01 | security-alert-line | vtv-icon-security-alert-line |
| &#xe607; | 云主机 | vm | vtv-icon-vm |
| &#xe608; | 备份 | backups | vtv-icon-backups |
| &#xe609; | 计划 | plan | vtv-icon-plan |
| &#xe60a; | 维护 | maintain | vtv-icon-maintain |
| &#xe60b; | dig-fill | dig-fill | vtv-icon-dig-fill |
| &#xe60c; | 漏洞 | loophole-line | vtv-icon-loophole-line |
| &#xe60d; | 展开 | expand | vtv-icon-expand |
| &#xe60e; | 安全感知 | sip | vtv-icon-sip |
| &#xe60f; | 收起 | unexpand | vtv-icon-unexpand |
| &#xe610; | windows7 | windows | vtv-icon-windows |
| &#xe611; | 智安全 | edr | vtv-icon-edr |
| &#xe612; | Kafka-color | kafka-color | vtv-icon-kafka-color |
| &#xe613; | linux-others | linux | vtv-icon-linux |
| &#xe614; | 云IT | cloud-it | vtv-icon-cloud-it |
| &#xe615; | SANGFOR | sangfor | vtv-icon-sangfor |
| &#xe616; | 部门 | department | vtv-icon-department |
| &#xe617; | DAS-color | das-color | vtv-icon-das-color |
| &#xe618; | Oracle-color | oracle-color | vtv-icon-oracle-color |
| &#xe619; | 绑定 | bangding | vtv-icon-bangding |
| &#xe61a; | loading | comp-loading | vtv-icon-comp-loading |
| &#xe61b; | MongoDB-color | mongodb-color | vtv-icon-mongodb-color |
| &#xe61c; | Redis-color | redis-color | vtv-icon-redis-color |
| &#xe61d; | MySQL-color | mysql-color | vtv-icon-mysql-color |
| &#xe61e; | servers | server-circle | vtv-icon-server-circle |
| &#xe61f; | 管理存储标签-01-01 | manage | vtv-icon-manage |
| &#xe620; | 钥匙 | auth-key | vtv-icon-auth-key |
| &#xe621; | HDD | disk | vtv-icon-disk |
| &#xe622; | 暂停 | pause | vtv-icon-pause |
| &#xe623; | AF-color | af-color | vtv-icon-af-color |
| &#xe624; | VMware集群 | vmware | vtv-icon-vmware |
| &#xe625; | 灾备集群 | acloud | vtv-icon-acloud |
| &#xe626; | 阿里云 | ali-acloud | vtv-icon-ali-acloud |
| &#xe627; | 容灾状态 | dr-status | vtv-icon-dr-status |
| &#xe628; | SSL VPN-color | sslvpn-color | vtv-icon-sslvpn-color |
| &#xe629; | 加载中-01 | loading | vtv-icon-loading |
| &#xe62a; | rabbitmq-color | rabbitmq-color | vtv-icon-rabbitmq-color |
| &#xe62b; | logs-line-color | logs-line-color | vtv-icon-logs-line-color |
| &#xe62c; | 回迁2-01 | migrate-back | vtv-icon-migrate-back |
| &#xe62d; | AD-color | ad-color | vtv-icon-ad-color |
| &#xe62e; | 演练2-01 | rehearse | vtv-icon-rehearse |
| &#xe62f; | 收起-01 | fold | vtv-icon-fold |
| &#xe630; | 展开-01 | unfold | vtv-icon-unfold |
| &#xe631; | 执行 | execute | vtv-icon-execute |
| &#xe632; | 双活 | double-live | vtv-icon-double-live |
| &#xe633; | security-line-color | security-line-color | vtv-icon-security-line-color |
| &#xe634; | 管理 | manage-single | vtv-icon-manage-single |
| &#xe635; | 重启 | restart | vtv-icon-restart |
| &#xe636; | subnet-line-color | subnet-line-color | vtv-icon-subnet-line-color |
| &#xe637; | data-line-color | data-line-color | vtv-icon-data-line-color |
| &#xe638; | vm-line-color | vm-line-color | vtv-icon-vm-line-color |
| &#xe639; | 解锁 | unlock | vtv-icon-unlock |
| &#xe63a; | 检测诊断 | analyse | vtv-icon-analyse |
| &#xe63b; | 立即评估 | evaluate-now | vtv-icon-evaluate-now |
| &#xe63c; | 擦除 | erase-line | vtv-icon-erase-line |
| &#xe63d; | 阿里云 | ali-line | vtv-icon-ali-line |
| &#xe63e; | ip-line-color | ip-line-color | vtv-icon-ip-line-color |
| &#xe63f; | site-color | site-color | vtv-icon-site-color |
| &#xe640; | pool-line-color | pool-line-color | vtv-icon-pool-line-color |
| &#xe641; | 策略 | policy-line | vtv-icon-policy-line |
| &#xe642; | jingxiang-color | jingxiang-color | vtv-icon-jingxiang-color |
| &#xe643; | public-line-color | public-line-color | vtv-icon-public-line-color |
| &#xe644; | icon-伞 | guard | vtv-icon-guard |
| &#xe645; | 撤销 | undo | vtv-icon-undo |
| &#xe646; | 应用 | application | vtv-icon-application |
| &#xe647; | 还原 | restore | vtv-icon-restore |
| &#xe648; | 告警 | alert-line | vtv-icon-alert-line |
| &#xe649; | 分配 | distribution-line | vtv-icon-distribution-line |
| &#xe64a; | 隔离文件 | quarantine-file | vtv-icon-quarantine-file |
| &#xe64b; | 图片 | image | vtv-icon-image |
| &#xe64c; | 复制 | copy-line | vtv-icon-copy-line |
| &#xe64d; | 公开 | public-line | vtv-icon-public-line |
| &#xe64e; | 角色 | role-line | vtv-icon-role-line |
| &#xe64f; | 日历 | calendar | vtv-icon-calendar |
| &#xe650; | 批量处理 | multi-opr | vtv-icon-multi-opr |
| &#xe651; | 费用 | cost-line | vtv-icon-cost-line |
| &#xe652; | 列表 | list-line | vtv-icon-list-line |
| &#xe653; | 日志 | logs-line | vtv-icon-logs-line |
| &#xe654; | 身份 | id-line | vtv-icon-id-line |
| &#xe655; | eth | eth | vtv-icon-eth |
| &#xe656; | 发送消息 | send | vtv-icon-send |
| &#xe657; | 时间 | time-line | vtv-icon-time-line |
| &#xe658; | 数据 | data-line | vtv-icon-data-line |
| &#xe659; | 锁定 | lock-line | vtv-icon-lock-line |
| &#xe65a; | 维修 | maintain-line | vtv-icon-maintain-line |
| &#xe65b; | 资源管理 | resource-management | vtv-icon-resource-management |
| &#xe65c; | 仪表盘 | dashboard-line | vtv-icon-dashboard-line |
| &#xe65d; | 网络 | internet-line | vtv-icon-internet-line |
| &#xe65e; | 物理机 | server-line | vtv-icon-server-line |
| &#xe65f; | 应用 | app-line | vtv-icon-app-line |
| &#xe660; | 用户组 | user-group--line | vtv-icon-user-group--line |
| &#xe661; | 云环境 | cloud-line | vtv-icon-cloud-line |
| &#xe662; | 提示-关闭 | comp-tip-close | vtv-icon-comp-tip-close |
| &#xe663; | 应用中心 | app-center | vtv-icon-app-center |
| &#xe664; | 资产态势监控 | monitor | vtv-icon-monitor |
| &#xe665; | 大屏 | big-screen | vtv-icon-big-screen |
| &#xe666; | 关闭审核 | stop-audit | vtv-icon-stop-audit |
| &#xe667; | 对象存储账号 | eds | vtv-icon-eds |
| &#xe668; | 证书 | certificate-line | vtv-icon-certificate-line |
| &#xe669; | 站点 | site-line | vtv-icon-site-line |
| &#xe66a; | 安装 | install | vtv-icon-install |
| &#xe66b; | todo | todo | vtv-icon-todo |
| &#xe66c; | 历史 | history | vtv-icon-history |
| &#xe66d; | pci-vga | pcivga | vtv-icon-pcivga |
| &#xe66e; | user | user-thin | vtv-icon-user-thin |
| &#xe66f; | 催单 | clock | vtv-icon-clock |
| &#xe670; | 双箭头-向上 | double-arrow-up | vtv-icon-double-arrow-up |
| &#xe671; | 双箭头-向下 | double-arrow-down | vtv-icon-double-arrow-down |
| &#xe672; | EDR-color | edr-color | vtv-icon-edr-color |
| &#xe673; | 状态 | analyse-line | vtv-icon-analyse-line |
| &#xe674; | HCI | hci-line | vtv-icon-hci-line |
| &#xe675; | sso | sso-line | vtv-icon-sso-line |
| &#xe676; | 存储 | storage-line | vtv-icon-storage-line |
| &#xe677; | 退出全屏 | exit-full-screen | vtv-icon-exit-full-screen |
| &#xe678; | 计费 | billing | vtv-icon-billing |
| &#xe679; | 全屏 | full-screen | vtv-icon-full-screen |
| &#xe67a; | 推荐 | good | vtv-icon-good |
| &#xe67b; | 置零 | setzero | vtv-icon-setzero |
| &#xe67c; | alarm | alarm | vtv-icon-alarm |
| &#xe67d; | workflow | workflow | vtv-icon-workflow |
| &#xe67e; | iso | iso | vtv-icon-iso |
| &#xe67f; | 默认头像 | avatar | vtv-icon-avatar |
| &#xe680; | 恢复 | recover | vtv-icon-recover |
| &#xe681; | 立即备份 | backup-now | vtv-icon-backup-now |
| &#xe682; | qingcloud | qingcloud | vtv-icon-qingcloud |
| &#xe683; | HCI | hci | vtv-icon-hci |
| &#xe684; | aliyun | aliyun | vtv-icon-aliyun |
| &#xe685; | VMWARE | vmware-type | vtv-icon-vmware-type |
| &#xe686; | Tencent cloud | qcloud | vtv-icon-qcloud |
| &#xe687; | xyclouds | xyclouds | vtv-icon-xyclouds |
| &#xe688; | acloud | acloud-type | vtv-icon-acloud-type |
| &#xe689; | 监控信息 | monitor-info | vtv-icon-monitor-info |
| &#xe68a; | aws | aws | vtv-icon-aws |
| &#xe68b; | 云间互联 | tunnel | vtv-icon-tunnel |
| &#xe68c; | 全部隧道 | tunnel-all | vtv-icon-tunnel-all |
| &#xe68d; | laptop | laptop | vtv-icon-laptop |
| &#xe68e; | synchro | synchro | vtv-icon-synchro |
| &#xe68f; | cloud | cloud | vtv-icon-cloud |
| &#xe690; | 基本信息 | base-info | vtv-icon-base-info |
| &#xe691; | 弹性IP | eip | vtv-icon-eip |
| &#xe692; | 防火墙 | firewall | vtv-icon-firewall |
| &#xe693; | 归档 | archive | vtv-icon-archive |
| &#xe694; | 消息 | message-line | vtv-icon-message-line |
| &#xe695; | 分组 | file-folder-line | vtv-icon-file-folder-line |
| &#xe696; | 信息 | info-line | vtv-icon-info-line |
| &#xe697; | 池 | pool-line | vtv-icon-pool-line |
| &#xe698; | 高级 | advanced-line | vtv-icon-advanced-line |
| &#xe699; | keys-group | keys-group | vtv-icon-keys-group |
| &#xe69a; | 恢复 | recovery-line | vtv-icon-recovery-line |
| &#xe69b; | 日历 | date-line | vtv-icon-date-line |
| &#xe69c; | 返回12 | return | vtv-icon-return |
| &#xe69d; | ecloud | ecloud | vtv-icon-ecloud |
| &#xe69e; | seed | seed | vtv-icon-seed |
| &#xe69f; | DNS | dns-line | vtv-icon-dns-line |
| &#xe6a0; | 邮箱 | mail-line | vtv-icon-mail-line |
| &#xe6a1; | 登录 | login-line | vtv-icon-login-line |
| &#xe6a2; | IP | ip-line | vtv-icon-ip-line |
| &#xe6a3; | 安全 | security-line | vtv-icon-security-line |
| &#xe6a4; | 下载 | download-line | vtv-icon-download-line |
| &#xe6a5; | vmware | vmware-line | vtv-icon-vmware-line |
| &#xe6a6; | 路由 | route-line | vtv-icon-route-line |
| &#xe6a7; | 编辑 | edit-line | vtv-icon-edit-line |
| &#xe6a8; | SDS | sds | vtv-icon-sds |
| &#xe6a9; | 并发 | concurrency | vtv-icon-concurrency |
| &#xe6aa; | 吞吐量 | handling-capacity | vtv-icon-handling-capacity |
| &#xe6ab; | 链接 | link | vtv-icon-link |
| &#xe6ac; | 连通域 | connected-line | vtv-icon-connected-line |
| &#xe6ad; | 子网 | subnet-line | vtv-icon-subnet-line |
| &#xe6ae; | 箭头-右 | arrorw-right-line | vtv-icon-arrorw-right-line |
| &#xe6af; | 更多 | more-line | vtv-icon-more-line |
| &#xe6b0; | 管理员 | admin-line | vtv-icon-admin-line |
| &#xe6b1; | 印章 | seal-line | vtv-icon-seal-line |
| &#xe6b2; | 自定义表单 | custom-form | vtv-icon-custom-form |
| &#xe6b3; | 电源 | battery | vtv-icon-battery |
| &#xe6b4; | 风扇 | fan | vtv-icon-fan |
| &#xe6b5; | 其他系统 | os-other | vtv-icon-os-other |
| &#xe6b6; | dmp | dmp-line | vtv-icon-dmp-line |
| &#xe6b7; | cssp | cssp | vtv-icon-cssp |
| &#xe6b8; | 上下居中 | center-vertically-fill | vtv-icon-center-vertically-fill |
| &#xe6b9; | 环形 | annular-fill | vtv-icon-annular-fill |
| &#xe6ba; | 退出 | exit | vtv-icon-exit |
| &#xe6bb; | 水平分布 | horizontal-fill | vtv-icon-horizontal-fill |
| &#xe6bc; | 树形 | tree-fill | vtv-icon-tree-fill |
| &#xe6bd; | 左右居中 | center-horizontally-fill | vtv-icon-center-horizontally-fill |
| &#xe6be; | 垂直分布 | vertical-fill | vtv-icon-vertical-fill |
| &#xe6bf; | 用户-关闭 | user-close-fill | vtv-icon-user-close-fill |
| &#xe6c0; | cssp-close | cssp-close-line | vtv-icon-cssp-close-line |
| &#xe6c1; | 线路监控 | circuit-line | vtv-icon-circuit-line |
| &#xe6c2; | 交换机 | switch-line | vtv-icon-switch-line |
| &#xe6c3; | 忽略 | hide-line | vtv-icon-hide-line |
| &#xe6c4; | SCP | scp | vtv-icon-scp |
| &#xe6c5; | 全选 | checkbox-all | vtv-icon-checkbox-all |
| &#xe6c6; | 半选 | checkbox-half | vtv-icon-checkbox-half |
| &#xe6c7; | 机架 | rack-line | vtv-icon-rack-line |
| &#xe6c8; | 二维码 | qrcode-fill | vtv-icon-qrcode-fill |
| &#xe6c9; | 挂起 | suspend | vtv-icon-suspend |
| &#xe6ca; | 回收站 | recycle | vtv-icon-recycle |
| &#xe6cb; | 关闭电源 | power-off | vtv-icon-power-off |
| &#xe6cc; | 重启 | reboot | vtv-icon-reboot |
| &#xe6cd; | 移动到分组 | move-to-group | vtv-icon-move-to-group |
| &#xe6ce; | 新增 | add | vtv-icon-add |
| &#xe6cf; | 清空 | emptied | vtv-icon-emptied |
| &#xe6d0; | 删除 | delete | vtv-icon-delete |
| &#xe6d1; | 开机 | power-on | vtv-icon-power-on |
| &#xe6d2; | 批量新增 | batch-add | vtv-icon-batch-add |
| &#xe6d3; | 关机 | shutdown | vtv-icon-shutdown |
| &#xe6d4; | 新增分组 | add-group | vtv-icon-add-group |
| &#xe6d5; | building | building-fill | vtv-icon-building-fill |
| &#xe6d6; | 升级 | upgrade | vtv-icon-upgrade |
| &#xe6d7; | 平台 | platform-line | vtv-icon-platform-line |
| &#xe6d8; | 上移 | up | vtv-icon-up |
| &#xe6d9; | 下移 | down | vtv-icon-down |
| &#xe6da; | 排序 | sort | vtv-icon-sort |
| &#xe6db; | 帮助Tips | tips-help | vtv-icon-tips-help |
| &#xe6dc; | 帮助 | help | vtv-icon-help |
| &#xe6dd; | 禁用 | disable | vtv-icon-disable |
| &#xe6de; | 启用 | enable | vtv-icon-enable |
| &#xe6df; | 弹窗关闭 | win-close | vtv-icon-win-close |
| &#xe6e0; | Tab关闭 | tab-close | vtv-icon-tab-close |
| &#xe6e1; | 刷新 | refresh | vtv-icon-refresh |
| &#xe6e2; | 搜索 | search | vtv-icon-search |
| &#xe6e3; | 批量管理 | mult-manage | vtv-icon-mult-manage |
| &#xe6e4; | 过滤 | filter | vtv-icon-filter |
| &#xe6e5; | 选择日期 | date | vtv-icon-date |
| &#xe6e6; | 编辑 | edit | vtv-icon-edit |
| &#xe6e7; | 导入 | import | vtv-icon-import |
| &#xe6e8; | 重命名 | rename | vtv-icon-rename |
| &#xe6e9; | 标记为已读 | mark-read | vtv-icon-mark-read |
| &#xe6ea; | 时间 | time | vtv-icon-time |
| &#xe6eb; | 配比管理 | quota | vtv-icon-quota |
| &#xe6ec; | 扩容 | capacity-expansion | vtv-icon-capacity-expansion |
| &#xe6ed; | 复制 | copy | vtv-icon-copy |
| &#xe6ee; | 数据库 | data-base | vtv-icon-data-base |
| &#xe6ef; | disk-HDD | disk-hdd | vtv-icon-disk-hdd |
| &#xe6f0; | disk-SSD | disk-ssd | vtv-icon-disk-ssd |
| &#xe6f1; | handled-color | handled-color | vtv-icon-handled-color |
| &#xe6f2; | telephone | telephone-fill | vtv-icon-telephone-fill |
| &#xe6f3; | pending-color | pending-color | vtv-icon-pending-color |
| &#xe6f4; | 立方体 | cube | vtv-icon-cube |
| &#xe6f5; | VPC网络 | vpc-fill | vtv-icon-vpc-fill |
| &#xe6f6; | EP | ep | vtv-icon-ep |
| &#xe6f7; | OP | op | vtv-icon-op |
| &#xe6f8; | 全屏 | full-screen-line | vtv-icon-full-screen-line |
| &#xe6f9; | 弹窗-告警 | win-alert | vtv-icon-win-alert |
| &#xe6fa; | 弹窗-停止服务 | win-stop | vtv-icon-win-stop |
| &#xe6fb; | 退出全屏 | exit-full-screen-line | vtv-icon-exit-full-screen-line |
| &#xe6fc; | 弹窗-关机 | win-shutdown | vtv-icon-win-shutdown |
| &#xe6fd; | 弹窗-删除到回收站 | win-recycle | vtv-icon-win-recycle |
| &#xe6fe; | 弹窗-永久删除 | win-delete | vtv-icon-win-delete |
| &#xe6ff; | 弹窗-重启 | win-reboot | vtv-icon-win-reboot |
| &#xe700; | 缩略图 | thumbnail-line | vtv-icon-thumbnail-line |
| &#xe701; | 新浪 | sina | vtv-icon-sina |
| &#xe702; | 微信 | wechat | vtv-icon-wechat |
| &#xe703; | 更多-圆 | more-round-fill | vtv-icon-more-round-fill |
| &#xe704; | 浏览器 | ie | vtv-icon-ie |
| &#xe705; | 线路 | circuit-fill | vtv-icon-circuit-fill |
| &#xe706; | 集群 | cluster-line | vtv-icon-cluster-line |
| &#xe707; | 服务器 | server-color | vtv-icon-server-color |
| &#xe708; | 授权 | authorize | vtv-icon-authorize |
| &#xe709; | 文件夹 展开 | file-expand | vtv-icon-file-expand |
| &#xe70a; | 文件夹 | file | vtv-icon-file |
| &#xe70b; | 视图-9grid | view-grid-small | vtv-icon-view-grid-small |
| &#xe70c; | 导航左菜单-收起 | comp-arrow-right-big | vtv-icon-comp-arrow-right-big |
| &#xe70d; | 导航左菜单-展开 | comp-arrow-down-big | vtv-icon-comp-arrow-down-big |
| &#xe70e; | 视图-list | view-list | vtv-icon-view-list |
| &#xe70f; | Webshell通信行为 | webshell | vtv-icon-webshell |
| &#xe710; | 病毒传播 | virus | vtv-icon-virus |
| &#xe711; | 密钥 | cipher | vtv-icon-cipher |
| &#xe712; | 连通域 | connected | vtv-icon-connected |
| &#xe713; | form待激活 | form-waiting | vtv-icon-form-waiting |
| &#xe714; | form挂起 | form-suspend | vtv-icon-form-suspend |
| &#xe715; | form-告警 | form-alert | vtv-icon-form-alert |
| &#xe716; | form离线 | form-offline | vtv-icon-form-offline |
| &#xe717; | form关机 | form-shutdown | vtv-icon-form-shutdown |
| &#xe718; | 应用软件漏洞 | application-loophole | vtv-icon-application-loophole |
| &#xe719; | form失败 | form-failed | vtv-icon-form-failed |
| &#xe71a; | form运行中 | form-running | vtv-icon-form-running |
| &#xe71b; | form执行中 | form-executing | vtv-icon-form-executing |
| &#xe71c; | 折叠 | triangle-fold | vtv-icon-triangle-fold |
| &#xe71d; | 展开 | triangle-unfold | vtv-icon-triangle-unfold |
| &#xe71e; | form极速恢复 | rapid-recovery | vtv-icon-rapid-recovery |
| &#xe71f; | 更多菜单箭头 | arrow-right | vtv-icon-arrow-right |
| &#xe720; | 更多菜单 | menu-more | vtv-icon-menu-more |
| &#xe721; | nav消息 | nav-info | vtv-icon-nav-info |
| &#xe722; | 区域 | region | vtv-icon-region |
| &#xe723; | 成员 | user | vtv-icon-user |
| &#xe724; | 部门 | org | vtv-icon-org |
| &#xe725; | 硬盘灯 | light | vtv-icon-light |
| &#xe726; | 标签s | tag-expand | vtv-icon-tag-expand |
| &#xe727; | 计划内切换 | planned-conversion | vtv-icon-planned-conversion |
| &#xe728; | 更换硬盘 | change-disk | vtv-icon-change-disk |
| &#xe729; | 暴力破解 | brute-force-attack | vtv-icon-brute-force-attack |
| &#xe72a; | 勒索病毒 | ransomware | vtv-icon-ransomware |
| &#xe72b; | 镜像 | image-line | vtv-icon-image-line |
| &#xe72c; | 标签 | tag | vtv-icon-tag |
| &#xe72d; | 温度 | temp-fill | vtv-icon-temp-fill |
| &#xe72e; | robot | robot | vtv-icon-robot |
| &#xe72f; | HBA | hba-fill | vtv-icon-hba-fill |
| &#xe730; | 网络适配器 | nic-fill | vtv-icon-nic-fill |
| &#xe731; | 分配配置 | setting | vtv-icon-setting |
| &#xe732; | 威胁 | threat | vtv-icon-threat |
| &#xe733; | 存储适配器 | storage-adapter-fill | vtv-icon-storage-adapter-fill |
| &#xe734; | 云安全中心 | cbsp-line | vtv-icon-cbsp-line |
| &#xe735; | 旗子 | flag-fill | vtv-icon-flag-fill |
| &#xe736; | 备份管理 | backup-manage | vtv-icon-backup-manage |
| &#xe737; | 漏洞 | loophole-info-fill | vtv-icon-loophole-info-fill |
| &#xe738; |   漏洞扫描 | loophole-scan-fill | vtv-icon-loophole-scan-fill |
| &#xe739; | 端口 | port-color | vtv-icon-port-color |
| &#xe73a; | 模版 | template-fill | vtv-icon-template-fill |
| &#xe73b; | drop-down | drop-down | vtv-icon-drop-down |
| &#xe73c; | 等待 | win-waiting | vtv-icon-win-waiting |
| &#xe73d; | certification | certification | vtv-icon-certification |
| &#xe73e; | The attack | attacked | vtv-icon-attacked |
| &#xe73f; | attack | attack | vtv-icon-attack |
| &#xe740; | Virus isolation | virus-file-isolation | vtv-icon-virus-file-isolation |
| &#xe741; | Permanently sealed | block-ip | vtv-icon-block-ip |
| &#xe742; | Intrusion prevention | intrusion-prevention | vtv-icon-intrusion-prevention |
| &#xe743; | application-new | application-system | vtv-icon-application-system |
| &#xe744; | 导出 | export | vtv-icon-export |
| &#xe745; | 克隆 | clone | vtv-icon-clone |
| &#xe746; | 陷阱 | trap-line | vtv-icon-trap-line |
| &#xe747; |  widows | widows | vtv-icon-widows |
| &#xe748; | 已完成-32 | done | vtv-icon-done |
| &#xe749; | 格式化 | format | vtv-icon-format |
| &#xe74a; | 漏洞攻击 | exploit | vtv-icon-exploit |
| &#xe74b; | 创建快照 | snapshot | vtv-icon-snapshot |
| &#xe74c; | 解除隔离 | remove-quarantine | vtv-icon-remove-quarantine |
| &#xe74d; | 篡改 | tamper | vtv-icon-tamper |
| &#xe74e; | 持续性攻击 | persistent | vtv-icon-persistent |
| &#xe74f; | 蠕虫 | worm | vtv-icon-worm |
| &#xe750; | 空 | empty | vtv-icon-empty |
| &#xe751; | 蠕虫病毒 | worm2 | vtv-icon-worm2 |
| &#xe752; | 木马 | trojanhorse | vtv-icon-trojanhorse |
| &#xe753; | 弱密码 | weakpassword | vtv-icon-weakpassword |
| &#xe754; | 违法网站访问 | illegalaccess | vtv-icon-illegalaccess |
| &#xe755; | 文件漏洞 | filevulnerability | vtv-icon-filevulnerability |
| &#xe756; | Web漏洞 | webvulnerability | vtv-icon-webvulnerability |
| &#xe757; | 系统漏洞 | systemvulnerability | vtv-icon-systemvulnerability |
| &#xe758; | Price | price | vtv-icon-price |
| &#xe759; | 漏洞-PoC | vulnerability-poc | vtv-icon-vulnerability-poc |
| &#xe75a; | 控制台 | console | vtv-icon-console |
| &#xe75b; | 详情状态 | detail | vtv-icon-detail |
| &#xe75c; | 漏洞-EXP | vulnerability-exp | vtv-icon-vulnerability-exp |
| &#xe75d; | 第三方扫描 | third-partyscan | vtv-icon-third-partyscan |
| &#xe75e; | 0黑产牟利32 | profitfromblackproduction | vtv-icon-profitfromblackproduction |
| &#xe75f; | 预览 | preview-fill | vtv-icon-preview-fill |
| &#xe760; | 迁移 | migrate | vtv-icon-migrate |
| &#xe761; | 创建备份 | backup | vtv-icon-backup |
| &#xe762; | 虚拟补丁 | virtual-patching | vtv-icon-virtual-patching |
| &#xe763; | 中间件 | middleware-line | vtv-icon-middleware-line |
| &#xe764; | 用户组 | user-group-color | vtv-icon-user-group-color |
| &#xe765; | 平台 | platform-color | vtv-icon-platform-color |
| &#xe766; | 网络 | net-color | vtv-icon-net-color |
| &#xe767; | 财务 | finance-color | vtv-icon-finance-color |
| &#xe768; | 加入监控中心 | join-monitor | vtv-icon-join-monitor |
| &#xe769; | 交易 | transaction-color | vtv-icon-transaction-color |
| &#xe76a; | 快照管理 | snapshot-manage | vtv-icon-snapshot-manage |
| &#xe76b; | 制作镜像 | make-image | vtv-icon-make-image |
| &#xe76c; | 加密 | bar-encryption | vtv-icon-bar-encryption |
| &#xe76d; | 浏览器 | browser-color | vtv-icon-browser-color |
| &#xe76e; | 显示组织分组 | show-group | vtv-icon-show-group |
| &#xe76f; | 隐藏组织分组 | hide-group | vtv-icon-hide-group |
| &#xe770; | 主机 | host | vtv-icon-host |
| &#xe771; | 主机s | host-lack | vtv-icon-host-lack |
| &#xe772; | 集群 | cluster | vtv-icon-cluster |
| &#xe773; | 集群s | cluster-lack | vtv-icon-cluster-lack |
| &#xe774; | 存储 | storage | vtv-icon-storage |
| &#xe775; | 存储s | storage-lack | vtv-icon-storage-lack |
| &#xe776; | 移动端 | mobile-color | vtv-icon-mobile-color |
| &#xe777; | 邮件 | mail-color | vtv-icon-mail-color |
| &#xe778; | 信用卡 | credit-card-color | vtv-icon-credit-card-color |
| &#xe779; | 证券 | security-color | vtv-icon-security-color |
| &#xe77a; | ERP | erp-color | vtv-icon-erp-color |
| &#xe77b; | 柜台 | counter-color | vtv-icon-counter-color |
| &#xe77c; | BI | bi-color | vtv-icon-bi-color |
| &#xe77d; | crm | crm-color | vtv-icon-crm-color |
| &#xe77e; | OA | oa-color | vtv-icon-oa-color |
| &#xe77f; | HR | hr-color | vtv-icon-hr-color |
| &#xe780; | 计时 | time-color | vtv-icon-time-color |
| &#xe781; | 期货 | futures-color | vtv-icon-futures-color |
| &#xe782; | 保险 | insurance-color | vtv-icon-insurance-color |
| &#xe783; | 病例 | case-color | vtv-icon-case-color |
| &#xe784; | 试管 | test-tube-color | vtv-icon-test-tube-color |
| &#xe785; | 64-存储总数 | storage-large | vtv-icon-storage-large |
| &#xe786; | 64-数据中心总数 | data-center | vtv-icon-data-center |
| &#xe787; | HIS | his-color | vtv-icon-his-color |
| &#xe788; | 法院 | court-color | vtv-icon-court-color |
| &#xe789; | 指挥 | command-color | vtv-icon-command-color |
| &#xe78a; | 左侧导航-收起 | comp-menu-collapse | vtv-icon-comp-menu-collapse |
| &#xe78b; | 修改密码 | password | vtv-icon-password |
| &#xe78c; | 左侧导航-展开 | comp-menu-expand | vtv-icon-comp-menu-expand |
| &#xe78d; | 手机银行 | mobile-banking-color | vtv-icon-mobile-banking-color |
| &#xe78e; | ARM | arm | vtv-icon-arm |
| &#xe78f; | 操作日志 | log | vtv-icon-log |
| &#xe790; | 报告 | report-color | vtv-icon-report-color |
| &#xe791; | 公积金 | accumulation-fund-color | vtv-icon-accumulation-fund-color |
| &#xe792; | 健康码 | health-code-color | vtv-icon-health-code-color |
| &#xe793; | 听诊器 | echometer-color | vtv-icon-echometer-color |
| &#xe794; | 应用 | app-color | vtv-icon-app-color |
| &#xe795; | 工厂 | factory-color | vtv-icon-factory-color |
| &#xe796; | CDP | cdp | vtv-icon-cdp |
| &#xe797; | 异地 | disaster-recovery | vtv-icon-disaster-recovery |
| &#xe798; | 系统 | system-color | vtv-icon-system-color |
| &#xe799; | 质量 | quality-color | vtv-icon-quality-color |
| &#xe79a; | 报道 | reported-color | vtv-icon-reported-color |
| &#xe79b; | 播放 | play-color | vtv-icon-play-color |
| &#xe79c; | 采编 | collecting-and-editing-color | vtv-icon-collecting-and-editing-color |
| &#xe79d; | 排版 | composing-color | vtv-icon-composing-color |
| &#xe79e; | 文件 | certificate-color | vtv-icon-certificate-color |
| &#xe79f; | 制作 | make-color | vtv-icon-make-color |
| &#xe7a0; | TV | tv-color | vtv-icon-tv-color |
| &#xe7a1; | 设置 | maintain-color | vtv-icon-maintain-color |
| &#xe7a2; | 直播 | live-streaming-color | vtv-icon-live-streaming-color |
| &#xe7a3; | 集成 | backup-color | vtv-icon-backup-color |
| &#xe7a4; | 云服务器 | cloud-server | vtv-icon-cloud-server |
| &#xe7a5; | 压缩 | compress-fill | vtv-icon-compress-fill |
| &#xe7a6; | 备份 | backup-line | vtv-icon-backup-line |
| &#xe7a7; | 卡 | card-fill | vtv-icon-card-fill |
| &#xe7a8; | 全屏 | full-screen-light | vtv-icon-full-screen-light |
| &#xe7a9; | Iceberg | iceberg | vtv-icon-iceberg |
| &#xe7aa; | 容量型 | capacity | vtv-icon-capacity |
| &#xe7ab; | 隐藏密码 | hide-password | vtv-icon-hide-password |
| &#xe7ac; | 性能型 | performance | vtv-icon-performance |
| &#xe7ad; | 高性能 | high-performance | vtv-icon-high-performance |
| &#xe7ae; | 内存 | memory | vtv-icon-memory |
| &#xe7af; | CPU | cpu | vtv-icon-cpu |
| &#xe7b0; | 上传 | upload | vtv-icon-upload |
| &#xe7b1; | 授权管理 | authorize-manage | vtv-icon-authorize-manage |
| &#xe7b2; | 电子邮箱 | email | vtv-icon-email |
| &#xe7b3; | 设备运行 | status | vtv-icon-status |
| &#xe7b4; | 提示信息Tips | tip-info | vtv-icon-tip-info |
| &#xe7b5; | 提示信息 | info | vtv-icon-info |
| &#xe7b6; | 微隔离日志 | drill | vtv-icon-drill |
| &#xe7b7; | 事件管理 | manage-line | vtv-icon-manage-line |
| &#xe7b8; | 系统资源 | system-resource | vtv-icon-system-resource |
| &#xe7b9; | Doris | doris | vtv-icon-doris |
| &#xe7ba; | 系统设置 | mes | vtv-icon-mes |
| &#xe7bb; | StarRocks | starrocks | vtv-icon-starrocks |
| &#xe7bc; | form完成 | form-finish | vtv-icon-form-finish |
| &#xe7bd; | 维护 | badsector-maintenance | vtv-icon-badsector-maintenance |
| &#xe7be; | 总览 | overview | vtv-icon-overview |
| &#xe7bf; | 演示目录 | float-catalogue | vtv-icon-float-catalogue |
| &#xe7c0; | 意见反馈 | float-coment | vtv-icon-float-coment |
| &#xe7c1; | 并行 | parallel-line | vtv-icon-parallel-line |
| &#xe7c2; | 汇聚 | converge-line | vtv-icon-converge-line |
| &#xe7c3; | 条件 | if-else-line | vtv-icon-if-else-line |
| &#xe7c4; | 创建 | add-12 | vtv-icon-add-12 |
| &#xe7c5; | 编辑 | edit-12 | vtv-icon-edit-12 |
| &#xe7c6; | 云间互联-新 | cloud-connect | vtv-icon-cloud-connect |
| &#xe7c7; | 手机 | cellphone | vtv-icon-cellphone |
| &#xe7c8; | K8S | k8s-line | vtv-icon-k8s-line |
| &#xe7c9; | 光模块 | optical-module-fill | vtv-icon-optical-module-fill |
| &#xe7ca; | 路由 | router-fill | vtv-icon-router-fill |
| &#xe7cb; | 工单 | work-order | vtv-icon-work-order |
| &#xe7cc; | 不支持 | unsupported | vtv-icon-unsupported |
| &#xe7cd; | nav-紧急漏洞检测 | badsector-scan | vtv-icon-badsector-scan |
| &#xe7ce; | nav-事件统计分析 | badsector-analyse | vtv-icon-badsector-analyse |
| &#xe7cf; | 更多-light | more | vtv-icon-more |
| &#xe7d0; | 交换 | switch-fill | vtv-icon-switch-fill |
| &#xe7d1; | 安全事件 | security-ingident-fill | vtv-icon-security-ingident-fill |
| &#xe7d2; | 定位 | location-light | vtv-icon-location-light |
| &#xe7d3; | 时间 | time-light | vtv-icon-time-light |
| &#xe7d4; | 运维人员 | maintainer-line | vtv-icon-maintainer-line |
| &#xe7d5; | 更多菜单箭头-上 | arrow-up | vtv-icon-arrow-up |
| &#xe7d6; | 更多菜单箭头-下 | arrow-down | vtv-icon-arrow-down |
| &#xe7d7; | 更多菜单箭头-左 | arrow-left | vtv-icon-arrow-left |
| &#xe7d8; | 性能 | property | vtv-icon-property |
| &#xe7d9; | 设备-asan | storage-asan | vtv-icon-storage-asan |
| &#xe7da; | 设备-FC | storage-fc | vtv-icon-storage-fc |
| &#xe7db; | 设备-ISCSI | storage-iscsi | vtv-icon-storage-iscsi |
| &#xe7dc; | 负载管理 | load | vtv-icon-load |
| &#xe7dd; | 风险 | risk-line | vtv-icon-risk-line |
| &#xe7de; | d365 | d365 | vtv-icon-d365 |
| &#xe7df; | 集群 | cluster-fill | vtv-icon-cluster-fill |
| &#xe7e0; | 应用 | app-fill | vtv-icon-app-fill |
| &#xe7e1; | 定位 | orientation-fill | vtv-icon-orientation-fill |
| &#xe7e2; | 电话 | telephone-light | vtv-icon-telephone-light |
| &#xe7e3; | 单独定价 | independent-pricing-line | vtv-icon-independent-pricing-line |
| &#xe7e4; | 统一定价 | unified-pricing-line | vtv-icon-unified-pricing-line |
| &#xe7e5; | 包年包月 | yearly | vtv-icon-yearly |
| &#xe7e6; | orcl | oracle | vtv-icon-oracle |
| &#xe7e7; | SAP | sap | vtv-icon-sap |
| &#xe7e8; | RAC | rac | vtv-icon-rac |
| &#xe7e9; | SQL | sql | vtv-icon-sql |
| &#xe7ea; | 无折扣 | no-discount | vtv-icon-no-discount |
| &#xe7eb; | 税率 | tax-rate | vtv-icon-tax-rate |
| &#xe7ec; | 支付网关 | payment-gateway | vtv-icon-payment-gateway |
| &#xe7ed; | 金额 | money | vtv-icon-money |
| &#xe7ee; | 通知屏蔽 | notification-mask-line | vtv-icon-notification-mask-line |
| &#xe7ef; | 容器 | container-fill | vtv-icon-container-fill |
| &#xe7f0; | 二进制 | binary-system-fill | vtv-icon-binary-system-fill |
| &#xe7f1; | IPV6 | ipv6 | vtv-icon-ipv6 |
| &#xe7f2; | 云安全资源池 | security-resource | vtv-icon-security-resource |
| &#xe7f3; | 置顶 | sticky-top | vtv-icon-sticky-top |
| &#xe7f4; | 处理工单 | gongdan-fill | vtv-icon-gongdan-fill |
| &#xe7f5; | 服务器 | server | vtv-icon-server |
| &#xe7f6; | 报告 | report-light | vtv-icon-report-light |
| &#xe7f7; | 威胁 | weixie | vtv-icon-weixie |
| &#xe7f8; | 告警 | alert-light | vtv-icon-alert-light |
| &#xe7f9; | paas | paas | vtv-icon-paas |
| &#xe7fa; | 资产风险 | zichanfengxian | vtv-icon-zichanfengxian |
| &#xe7fb; | 设备-SQLServer-single | database-sqlserver-single | vtv-icon-database-sqlserver-single |
| &#xe7fc; | 设备-SQLServer-alwayso | database-sqlserver-alwayson | vtv-icon-database-sqlserver-alwayson |
| &#xe7fd; | 设备-oracle-rac | database-oracle-rac | vtv-icon-database-oracle-rac |
| &#xe7fe; | 设备-SQLServer | database-sqlserver | vtv-icon-database-sqlserver |
| &#xe7ff; | 设备-SQLServer-Disable | database-sqlserver-single-disabled | vtv-icon-database-sqlserver-single-disabled |
| &#xe800; | 安全 | security-light | vtv-icon-security-light |
| &#xe801; | 漏洞 | loudong | vtv-icon-loudong |
| &#xe802; | 设备-oracle-rac-gray | database-oracle-rac-disabled | vtv-icon-database-oracle-rac-disabled |
| &#xe803; | 设备-oracle-single | database-oracle-single | vtv-icon-database-oracle-single |
| &#xe804; | 向右 | turn-right | vtv-icon-turn-right |
| &#xe805; | 正在取消 | canceling | vtv-icon-canceling |
| &#xe806; | 汇报 | presentation-fill | vtv-icon-presentation-fill |
| &#xe807; | 印章 | seal-fill | vtv-icon-seal-fill |
| &#xe808; | 狩猎 | hunting-fill | vtv-icon-hunting-fill |
| &#xe809; | 安全升级 | security-update-fill | vtv-icon-security-update-fill |
| &#xe80a; | 策略检查 | policy-check-fill | vtv-icon-policy-check-fill |
| &#xe80b; | 风险分析 | alert-analyse-fill | vtv-icon-alert-analyse-fill |
| &#xe80c; | 应急 | alarm-fill | vtv-icon-alarm-fill |
| &#xe80d; | 策略调优 | policy-tuning-fill | vtv-icon-policy-tuning-fill |
| &#xe80e; | 资产风险 | equipment-alert-fill | vtv-icon-equipment-alert-fill |
| &#xe80f; | 资产管理 | equipment-management-fill | vtv-icon-equipment-management-fill |
| &#xe810; | 服务介绍 | service-fill | vtv-icon-service-fill |
| &#xe811; | 导航 | navigator | vtv-icon-navigator |
| &#xe812; | 处置 | alert-maintain | vtv-icon-alert-maintain |
| &#xe813; | 数据库容灾 | database-dr | vtv-icon-database-dr |
| &#xe814; | 串口 | serial-interface | vtv-icon-serial-interface |
| &#xe815; | drs | drs | vtv-icon-drs |
| &#xe816; | next | next | vtv-icon-next |
| &#xe817; | 续费 | renewal | vtv-icon-renewal |
| &#xe818; | port _ exception | a-port_exception | vtv-icon-a-port_exception |
| &#xe819; | coalescing port_ exception | a-coalescingport_exception | vtv-icon-a-coalescingport_exception |
| &#xe81a; | coalescing port_ normal | a-coalescingport_normal | vtv-icon-a-coalescingport_normal |
| &#xe81b; | port _ normal | a-port_normal | vtv-icon-a-port_normal |
| &#xe81c; | 按量计费 | volumetric-billing | vtv-icon-volumetric-billing |
| &#xe81d; | 专家 | master | vtv-icon-master |
| &#xe81e; | 镜像仓库 | image-warehouse-line | vtv-icon-image-warehouse-line |
| &#xe81f; | 命名空间 | namespace-line | vtv-icon-namespace-line |
| &#xe820; | 工作负载 | workload-line | vtv-icon-workload-line |
| &#xe821; | 持久卷声明 | pvc-line | vtv-icon-pvc-line |
| &#xe822; | 云主机 | vm-root | vtv-icon-vm-root |
| &#xe823; | 在线体验 | experience-line | vtv-icon-experience-line |
| &#xe824; | 预训练数据集 | pre-training-dataset-color | vtv-icon-pre-training-dataset-color |
| &#xe825; | 模型管理 | model-management-line | vtv-icon-model-management-line |
| &#xe826; | 微调数据集 | Fine-tune-the-dataset | vtv-icon-Fine-tune-the-dataset |
| &#xe827; | 模型训练 | model-training-line | vtv-icon-model-training-line |
| &#xe828; | 模型服务 | model-services-line | vtv-icon-model-services-line |
| &#xe829; | 身份认证 | identity-authentication-fill | vtv-icon-identity-authentication-fill |
| &#xe82a; | 模型训练 | model-training-faceted | vtv-icon-model-training-faceted |
| &#xe82b; | 编辑 | edit-light | vtv-icon-edit-light |
| &#xe82c; | 弹窗-错误 | win-fail | vtv-icon-win-fail |
| &#xe82d; | 弹窗-提示 | win-tip | vtv-icon-win-tip |
| &#xe82e; | 弹窗-系统错误 | win-error | vtv-icon-win-error |
| &#xe82f; | 授权 | sn-auth | vtv-icon-sn-auth |
| &#xe830; | 删除 | delete-light | vtv-icon-delete-light |
| &#xe831; | 暂停 | suspend-light | vtv-icon-suspend-light |
| &#xe832; | 刷新 | refresh-light | vtv-icon-refresh-light |
| &#xe833; | 模型调优 | model-tuning-fill | vtv-icon-model-tuning-fill |
| &#xe834; | 模型仓库 | model-Repository-fill | vtv-icon-model-Repository-fill |
| &#xe835; | 模型 | model-line | vtv-icon-model-line |
| &#xe836; | 采集指标 | collecting-indicators-faceted | vtv-icon-collecting-indicators-faceted |
| &#xe837; | 减号 | ele-minus | vtv-icon-ele-minus |
| &#xe838; | 退出 | bar-quit | vtv-icon-bar-quit |
| &#xe839; | 文件 | ele-clip | vtv-icon-ele-clip |
| &#xe83a; | 加号 | ele-add | vtv-icon-ele-add |
| &#xe83b; | 云主机 | virtual-host | vtv-icon-virtual-host |
| &#xe83c; | 弹性IP池 | ip | vtv-icon-ip |
| &#xe83d; | 收起 | menu-fold | vtv-icon-menu-fold |
| &#xe83e; | 展开 | menu-unfold | vtv-icon-menu-unfold |
| &#xe83f; | 清空 | clear | vtv-icon-clear |
| &#xe840; | 网络 | network | vtv-icon-network |
| &#xe841; | 保存 | save | vtv-icon-save |
| &#xe842; | 侧栏-展开 | menu-expand | vtv-icon-menu-expand |
| &#xe843; | 放大 | zoomin | vtv-icon-zoomin |
| &#xe844; | 侧栏-收起 | menu-collapse | vtv-icon-menu-collapse |
| &#xe845; | 流量关闭 | flux-off | vtv-icon-flux-off |
| &#xe846; | 框选 | frame-selection | vtv-icon-frame-selection |
| &#xe847; | 流量开启 | flux-on | vtv-icon-flux-on |
| &#xe848; | 缩小 | zoomout | vtv-icon-zoomout |
| &#xe849; | 下载 | download | vtv-icon-download |
| &#xe84a; | 指针 | arrow | vtv-icon-arrow |
| &#xe84b; | 原始大小 | initial-size | vtv-icon-initial-size |
| &#xe84c; | 排布 | redraw | vtv-icon-redraw |
| &#xe84d; | fit | fit | vtv-icon-fit |
| &#xe84e; | 连线 | connect | vtv-icon-connect |
| &#xe84f; | 连通性测试 | linktest | vtv-icon-linktest |
| &#xe850; | 全选 | all-selection | vtv-icon-all-selection |
| &#xe851; | 布局 | layout | vtv-icon-layout |
| &#xe852; | 下拉 | angle | vtv-icon-angle |
| &#xe853; | 向上箭头 | full-arrow-up | vtv-icon-full-arrow-up |
| &#xe854; | 浏览 | browse | vtv-icon-browse |
| &#xe855; | 云眼 | visioner | vtv-icon-visioner |
| &#xe856; | 查看详情 | check-detail | vtv-icon-check-detail |
| &#xe857; | 上传 | ele-upload | vtv-icon-ele-upload |
| &#xe858; | 折叠-减 | ele-fold-minus | vtv-icon-ele-fold-minus |
| &#xe859; | 视图 | view | vtv-icon-view |
| &#xe85a; | AF | af | vtv-icon-af |
| &#xe85b; | 云镜 | host-security | vtv-icon-host-security |
| &#xe85c; | 云盾 | cloud-waf | vtv-icon-cloud-waf |
| &#xe85d; | 云守 | security-butler | vtv-icon-security-butler |
| &#xe85e; | 责任架构 | erp | vtv-icon-erp |
| &#xe85f; | 折叠-加 | ele-fold-add | vtv-icon-ele-fold-add |
| &#xe860; | time-arrow | ele-time-arrow | vtv-icon-ele-time-arrow |
| &#xe861; | 端到端追踪 | end-to-end-tracking-fill | vtv-icon-end-to-end-tracking-fill |
| &#xe862; | 火焰图 | flame-graph-fill | vtv-icon-flame-graph-fill |
| &#xe863; | 细粒度控制 | fine-grained-control-fill | vtv-icon-fine-grained-control-fill |
| &#xe864; | 集中化展示 | centralized-display-fill | vtv-icon-centralized-display-fill |
| &#xe865; | 用户访问监测 | user-access-monitoring-fill | vtv-icon-user-access-monitoring-fill |
| &#xe866; | 真实需求追踪 | real-demand-tracking-fill | vtv-icon-real-demand-tracking-fill |
| &#xe867; | 全链路洞察访问 | full-link-insight-fill | vtv-icon-full-link-insight-fill |
| &#xe868; | 威胁情报 | bar-edit | vtv-icon-bar-edit |
| &#xe869; | 统一搜索查询 | unified-search-query-fill | vtv-icon-unified-search-query-fill |
| &#xe86a; | 灵活日志处理 | flexible-log-processing-fill | vtv-icon-flexible-log-processing-fill |
| &#xe86b; | 日志关联查询 | log-correlation-query-fill | vtv-icon-log-correlation-query-fill |
| &#xe86c; | 灵活场景布局 | flexible-scene-layout-fill | vtv-icon-flexible-scene-layout-fill |
| &#xe86d; | 丰富图表选择 | rich-chart-selection-fill | vtv-icon-rich-chart-selection-fill |
| &#xe86e; | 拉拽式交互 | pull-and-drop-interaction-fill | vtv-icon-pull-and-drop-interaction-fill |
| &#xe86f; | 高效数据展示 | efficient-data-display-fill | vtv-icon-efficient-data-display-fill |
| &#xe870; | 返回 | back | vtv-icon-back |
| &#xe871; | 上月 | prev-month | vtv-icon-prev-month |
| &#xe872; | 上一年 | prev-year | vtv-icon-prev-year |
| &#xe873; | 下一年 | next-year | vtv-icon-next-year |
| &#xe874; | 下月 | next-month | vtv-icon-next-month |
| &#xe875; | 指标数据整体管理 | indicator-data-management-fill | vtv-icon-indicator-data-management-fill |
| &#xe876; | 运行状态效率 | operating-efficiency-fill | vtv-icon-operating-efficiency-fill |
| &#xe877; | 可视化分析趋势 | visual-analysis-trends-fill | vtv-icon-visual-analysis-trends-fill |
| &#xe878; | 回收 | cycle | vtv-icon-cycle |
| &#xe879; | 美金计费 | dollar-billing | vtv-icon-dollar-billing |
| &#xe87a; | 扫描 | scan | vtv-icon-scan |
| &#xe87b; | 轮播 | carousel | vtv-icon-carousel |
| &#xe87c; | 配置 | config | vtv-icon-config |
| &#xe87d; | 批量编辑 | multi-edit | vtv-icon-multi-edit |
| &#xe87e; | 高级模式 | advance | vtv-icon-advance |
| &#xe87f; | 批量处理撤销 | batch-undo | vtv-icon-batch-undo |
| &#xe880; | 启用审核 | start-audit | vtv-icon-start-audit |
| &#xe881; | 批量操作 | multi-operate | vtv-icon-multi-operate |
| &#xe882; | 弹窗-信息 | win-info | vtv-icon-win-info |
| &#xe883; | 日志解析进程 | analysis-list | vtv-icon-analysis-list |
| &#xe884; | pin-fill | pin | vtv-icon-pin |
| &#xe885; | 统一指标集中管理 | unified-indicator-management-fill | vtv-icon-unified-indicator-management-fill |
| &#xe886; | das | das | vtv-icon-das |
| &#xe887; | 摄像头 | camera | vtv-icon-camera |
| &#xe888; | 政府 | government | vtv-icon-government |
| &#xe889; | 数据库 | database | vtv-icon-database |
| &#xe88a; | 搜索框 | comp-search | vtv-icon-comp-search |
| &#xe88b; | 通报 | notify | vtv-icon-notify |
| &#xe88c; | 下拉框 | comp-angle-down | vtv-icon-comp-angle-down |
| &#xe88d; | 设置 | set | vtv-icon-set |
| &#xe88e; | 同步 | sync | vtv-icon-sync |
| &#xe88f; | 无需通报 | no-notification | vtv-icon-no-notification |
| &#xe890; | 教育 | edu | vtv-icon-edu |
| &#xe891; | 医疗 | medicine | vtv-icon-medicine |
| &#xe892; | 锁定 | lock | vtv-icon-lock |
| &#xe893; | 系统通知 | notification | vtv-icon-notification |
| &#xe894; | 一键隔离 | quarantine | vtv-icon-quarantine |
| &#xe895; | 一键信任 | trust | vtv-icon-trust |
| &#xe896; | 云端获取 | cloud-get | vtv-icon-cloud-get |
| &#xe897; | 云端下发 | cloud-push | vtv-icon-cloud-push |
| &#xe898; | 信息 | message | vtv-icon-message |
| &#xe899; | 自定义 | self-defined | vtv-icon-self-defined |
| &#xe89a; | 转为终端 | to-console | vtv-icon-to-console |
| &#xe89b; | 转为服务器 | to-server | vtv-icon-to-server |
| &#xe89c; | 企业 | enterprise | vtv-icon-enterprise |
| &#xe89d; | 下拉框-向上 | comp-angle-up | vtv-icon-comp-angle-up |
| &#xe89e; | 选择 | comp-select | vtv-icon-comp-select |
| &#xe89f; | 隔离终端 | quarantine-console | vtv-icon-quarantine-console |
| &#xe8a0; | 黑名单 | blacklist | vtv-icon-blacklist |
| &#xe8a1; | 更多 | comp-more | vtv-icon-comp-more |
| &#xe8a2; | 箭头 | moving | vtv-icon-moving |
| &#xe8a3; | 成功提示12 | comp-notify-ok | vtv-icon-comp-notify-ok |
| &#xe8a4; | 下发策略 | strategy | vtv-icon-strategy |
| &#xe8a5; | bvt | bvt | vtv-icon-bvt |
| &#xe8a6; | las | las | vtv-icon-las |
| &#xe8a7; | osm | osm | vtv-icon-osm |
| &#xe8a8; | 跳转 | skip | vtv-icon-skip |
| &#xe8a9; | 重置密码 | reset-password | vtv-icon-reset-password |
| &#xe8aa; | 移动 | mobile-network | vtv-icon-mobile-network |
| &#xe8ab; | 弹窗-提示 | win-tip-brand | vtv-icon-win-tip-brand |
| &#xe8ac; | 成功12 | normal-brand | vtv-icon-normal-brand |
| &#xe8ad; | 挂起 | pause-brand | vtv-icon-pause-brand |
| &#xe8ae; | 关机 | offline-brand | vtv-icon-offline-brand |
| &#xe8af; | 无效12 | failure-brand | vtv-icon-failure-brand |
| &#xe8b0; | 失败12 | warning-brand | vtv-icon-warning-brand |
| &#xe8b1; | 等待12 | waiting-brand | vtv-icon-waiting-brand |
| &#xe8b2; | 22资料、手册 | handbook | vtv-icon-handbook |
| &#xe8b3; | 官方社区 | community | vtv-icon-community |
| &#xe8b4; | 筛选-正常 | comp-ok-border | vtv-icon-comp-ok-border |
| &#xe8b5; | 筛选-选中 | comp-ok-circle | vtv-icon-comp-ok-circle |
| &#xe8b6; | 邮件 | mail | vtv-icon-mail |
| &#xe8b7; | 中间件 | middleware | vtv-icon-middleware |
| &#xe8b8; | 用户组管理 | oa | vtv-icon-oa |
| &#xe8b9; | 告警 | bell | vtv-icon-bell |
| &#xe8ba; | 云主机 | virtual | vtv-icon-virtual |
| &#xe8bb; | 灯泡 | lamp | vtv-icon-lamp |
| &#xe8bc; | 一站式事件查看 | one-stop-event-viewing-fill | vtv-icon-one-stop-event-viewing-fill |
| &#xe8bd; | 事件聚合匹配 | event-aggregation-matching-fill | vtv-icon-event-aggregation-matching-fill |
| &#xe8be; | 异常定位分析 | abnormal-location-analysis-fill | vtv-icon-abnormal-location-analysis-fill |
| &#xe8bf; | 实时监控查询 | real-time-monitoring-query-fill | vtv-icon-real-time-monitoring-query-fill |
| &#xe8c0; | 集中化接入 | centralized-access-fill | vtv-icon-centralized-access-fill |
| &#xe8c1; | 关键性指标反馈 | key-indicator-feedback-fill | vtv-icon-key-indicator-feedback-fill |
| &#xe8c2; | 排序 | ele-drag | vtv-icon-ele-drag |
| &#xe8c3; | 智能事件中心 | intelligent-event-center-line | vtv-icon-intelligent-event-center-line |
| &#xe8c4; | 趋势分析 | trend-analysis-line | vtv-icon-trend-analysis-line |
| &#xe8c5; | 监控 | monitor-line | vtv-icon-monitor-line |
| &#xe8c6; | 业务组 | business-group-line | vtv-icon-business-group-line |
| &#xe8c7; | 业务拨测 | business-call-testing-line | vtv-icon-business-call-testing-line |
| &#xe8c8; | 数据库智能诊断 | database-intelligent-diagnosis-line | vtv-icon-database-intelligent-diagnosis-line |
| &#xe8c9; | 采集管理 | collection-management-line | vtv-icon-collection-management-line |
| &#xe8ca; | 创建可视化大屏 | create-visual-screen-fill | vtv-icon-create-visual-screen-fill |
| &#xe8cb; | 连接多类型数据库 | connect-multiple-types-fill | vtv-icon-connect-multiple-types-fill |
| &#xe8cc; | 设置指标信息 | set-indicator-information-fill | vtv-icon-set-indicator-information-fill |
| &#xe8cd; | 分析模块制作和共享 | analysis-module-production-fill | vtv-icon-analysis-module-production-fill |
| &#xe8ce; | 高速引擎 | high-speed-engine-fill | vtv-icon-high-speed-engine-fill |
| &#xe8cf; | 通过API二次开发 | develop-via-api-fill | vtv-icon-develop-via-api-fill |
| &#xe8d0; | 数据访问权限管理 | data-access-rights-fill | vtv-icon-data-access-rights-fill |
| &#xe8d1; | 建立指标关联 | create-indicator-associations-fill | vtv-icon-create-indicator-associations-fill |
| &#xe8d2; | 多语言编写和运行代码 | write-and-run-code-fill | vtv-icon-write-and-run-code-fill |
| &#xe8d3; | view-list | view-list-brand | vtv-icon-view-list-brand |
| &#xe8d4; | 多种数据处理工作 | data-processing-work-fill | vtv-icon-data-processing-work-fill |
| &#xe8d5; | 访问服务 | access-services-fill | vtv-icon-access-services-fill |
| &#xe8d6; | 数据打通并关联分析 | data-correlation-analysis-fill | vtv-icon-data-correlation-analysis-fill |
| &#xe8d7; | 数据即席分析运算 | data-analysis-operations-fill | vtv-icon-data-analysis-operations-fill |
| &#xe8d8; | 数据集成和管理 | data-integration-fill | vtv-icon-data-integration-fill |
| &#xe8d9; | 建筑 | building-fill1 | vtv-icon-building-fill1 |
| &#xe8da; | 云端代理管理 | cloud-proxy-management-line | vtv-icon-cloud-proxy-management-line |
| &#xe8db; | 分析预测 | analysis-and-prediction-line | vtv-icon-analysis-and-prediction-line |
| &#xe8dc; | 统一定价 | unified-pricing-line1 | vtv-icon-unified-pricing-line1 |
| &#xe8dd; | 独立定价 | independent-pricing-line1 | vtv-icon-independent-pricing-line1 |
| &#xe8de; | 折扣 | discount-fill | vtv-icon-discount-fill |
| &#xe8df; | sql | sql-fill | vtv-icon-sql-fill |
| &#xe8e0; | 关闭 | close-line | vtv-icon-close-line |
| &#xe8e1; | 最小化 | minimize-line | vtv-icon-minimize-line |
| &#xe8e2; | 最大化 | maximize-line | vtv-icon-maximize-line |
| &#xe8e3; | 向下还原 | restore-downwards | vtv-icon-restore-downwards |
| &#xe8e4; | 铃铛 | bell-fill | vtv-icon-bell-fill |
| &#xe8e5; | 华三云 | h3c_cas | vtv-icon-h3c_cas |
| &#xe8e6; | 瀑布流表格 | Waterfall-flow-table-line | vtv-icon-Waterfall-flow-table-line |
| &#xe8e7; | 表格 | tabulation-line | vtv-icon-tabulation-line |
| &#xe8e8; | Agent采集指标 | Agent-collection-metrics-fill | vtv-icon-Agent-collection-metrics-fill |
| &#xe8e9; | kafka | kafka-line | vtv-icon-kafka-line |
| &#xe8ea; | 并行 | parallelism-line | vtv-icon-parallelism-line |
| &#xe8eb; | MySQL | MySQL-line | vtv-icon-MySQL-line |
| &#xe8ec; | SQLserver | SQLserver-line | vtv-icon-SQLserver-line |
| &#xe8ed; | rabbitmq | rabbitmq-line | vtv-icon-rabbitmq-line |
| &#xe8ee; | 自定义函数 | Custom-functions-line | vtv-icon-Custom-functions-line |
| &#xe8ef; | 函数 | function-line | vtv-icon-function-line |
| &#xe8f0; | 分支判断 | if-line | vtv-icon-if-line |
| &#xe8f1; | 流程管理 | process-management-line | vtv-icon-process-management-line |
| &#xe8f2; | 延时 | delayed-line | vtv-icon-delayed-line |
| &#xe8f3; | 运行记录 | operation-record-line | vtv-icon-operation-record-line |
| &#xe8f4; | 错误 | fail-12 | vtv-icon-fail-12 |
| &#xe8f5; | 授权 | authorization-fill | vtv-icon-authorization-fill |
| &#xe8f6; | 稳定 | stable-fill | vtv-icon-stable-fill |
| &#xe8f7; | 关机 | shutdown-line | vtv-icon-shutdown-line |
| &#xe8f8; | 最快时间 | best-time-fill | vtv-icon-best-time-fill |
| &#xe8f9; | 双列展示 | double-column-display-fill | vtv-icon-double-column-display-fill |
| &#xe8fa; | 补丁 | patch | vtv-icon-patch |
| &#xe8fb; | 三列展示 | three-column-display-fill | vtv-icon-three-column-display-fill |
| &#xe8fc; | 单列展示 | single-column-display-fill | vtv-icon-single-column-display-fill |
| &#xe8fd; | 升级 | product-upgrade | vtv-icon-product-upgrade |
| &#xe8fe; | 跳转 | jump-line | vtv-icon-jump-line |
| &#xe8ff; | 目录展开 | left-menu-expand | vtv-icon-left-menu-expand |
| &#xe900; | 目录收起 | left-menu-collapse | vtv-icon-left-menu-collapse |
| &#xe901; | 导航左菜单-上箭头 | comp-arrow-up-big | vtv-icon-comp-arrow-up-big |
| &#xe902; | loss曲线 | loss-curve-fill | vtv-icon-loss-curve-fill |
| &#xe903; | 弹性伸缩 | slasticity-stretching-fill | vtv-icon-slasticity-stretching-fill |
| &#xe904; | 并行结束 | parallelism-end-line | vtv-icon-parallelism-end-line |
| &#xe905; | 应用全链路观测平台 | application-full-link-observation-platform-line | vtv-icon-application-full-link-observation-platform-line |
| &#xe906; | 链接跳转 | link-jump-line | vtv-icon-link-jump-line |
| &#xe907; | 复制 | copy-light | vtv-icon-copy-light |
| &#xe908; | 比例 | ratio-fill | vtv-icon-ratio-fill |
| &#xe909; | 服务器管理 | node-setting-fill | vtv-icon-node-setting-fill |
| &#xe90a; | 存储管理 | storage-setting-fill | vtv-icon-storage-setting-fill |
| &#xe90b; | 主机磁盘 | vm-disk-fill | vtv-icon-vm-disk-fill |
| &#xe90c; | 服务器检测 | node-detection-fill | vtv-icon-node-detection-fill |
| &#xe90d; | 存储扩容 | storage-add-fill | vtv-icon-storage-add-fill |
| &#xe90e; | 服务器维护 | node-maintain-fill | vtv-icon-node-maintain-fill |
| &#xe90f; | 平均值 | average-fill | vtv-icon-average-fill |
| &#xe910; | 切换 | switch-fill1 | vtv-icon-switch-fill1 |
| &#xe911; | 合并 | merge-fill | vtv-icon-merge-fill |
| &#xe912; | 拆分 | resolution-fill | vtv-icon-resolution-fill |
| &#xe913; | 虚拟交换机 | ds-switch-fill | vtv-icon-ds-switch-fill |
| &#xe914; | 主控节点 | main-control-fill | vtv-icon-main-control-fill |
| &#xe915; | 控制节点 | control-fill | vtv-icon-control-fill |
| &#xe916; | 创建快照 | add-snapshoot-fill | vtv-icon-add-snapshoot-fill |
| &#xe917; | 创建备份 | add-backup-fill | vtv-icon-add-backup-fill |
| &#xe918; | 虚拟共享盘 | v-shared-disk-line | vtv-icon-v-shared-disk-line |
| &#xe919; | IP | ip-fill | vtv-icon-ip-fill |
| &#xe91a; | 告警 | urgent-warning-fill | vtv-icon-urgent-warning-fill |
| &#xe91b; | scsi控制器 | scsi-controller-fill | vtv-icon-scsi-controller-fill |
| &#xe91c; | 云主机 | vm-cloud-fill | vtv-icon-vm-cloud-fill |
| &#xe91d; | 运维服务 | user-maintenance-fill | vtv-icon-user-maintenance-fill |
| &#xe91e; | 过期 | expire-fill | vtv-icon-expire-fill |
| &#xe91f; | 体验 | experience-fill | vtv-icon-experience-fill |
| &#xe920; | view-grid | view-grid-brand | vtv-icon-view-grid-brand |
| &#xe921; | 优秀 | excellent-fill | vtv-icon-excellent-fill |
| &#xe922; | 告警 | risk-12 | vtv-icon-risk-12 |
| &#xe923; | 数据管理 | data-management-line | vtv-icon-data-management-line |
| &#xe924; | 智能评估 | intelligent-assessment-line | vtv-icon-intelligent-assessment-line |
| &#xe925; | 接口 | interface | vtv-icon-interface |
| &#xe926; | 召回重排 | recall-and-reranking-fill | vtv-icon-recall-and-reranking-fill |
| &#xe927; | 知识检索 | knowledge-retrieval-fill | vtv-icon-knowledge-retrieval-fill |
| &#xe928; | 网络对象 | network-objects | vtv-icon-network-objects |
| &#xe929; | 标注数据检索 | annotated-data-retrieval-fill | vtv-icon-annotated-data-retrieval-fill |
| &#xe92a; | 业务 | business-line | vtv-icon-business-line |
| &#xe92b; | 生成回答 | generate-responses-fill | vtv-icon-generate-responses-fill |
| &#xe92c; | 服务 | service | vtv-icon-service |
| &#xe92d; | 智能 | intelligence-line | vtv-icon-intelligence-line |
| &#xe92e; | 问题重写 | question-rewriting-fill | vtv-icon-question-rewriting-fill |
| &#xe92f; | 字符 | character-light | vtv-icon-character-light |
| &#xe930; | 召回 | recall-light | vtv-icon-recall-light |
| &#xe931; | 大屏 | big-screen1 | vtv-icon-big-screen1 |
| &#xe932; | 手动添加 | add-manually-light | vtv-icon-add-manually-light |
| &#xe933; | 邮箱设置 | email-settings-line | vtv-icon-email-settings-line |
| &#xe934; | 用户安全 | user-security | vtv-icon-user-security |
| &#xe935; | 管理员账号 | account-line | vtv-icon-account-line |
| &#xe936; | 资源申请 | resource-application-line | vtv-icon-resource-application-line |
| &#xe937; | 报表模板 | report-template-line | vtv-icon-report-template-line |
| &#xe938; | 报表管理 | report-management-line | vtv-icon-report-management-line |
| &#xe939; | 资源标签 | resource-tag-line | vtv-icon-resource-tag-line |
| &#xe93a; | 触发条件策略 | trigger-condition-strategy-line | vtv-icon-trigger-condition-strategy-line |
| &#xe93b; | 推送策略 | push-strategy-line | vtv-icon-push-strategy-line |
| &#xe93c; | 服务设计 | service-design-line | vtv-icon-service-design-line |
| &#xe93d; | 通知策略 | notification-strategy-line | vtv-icon-notification-strategy-line |
| &#xe93e; | 通知模板 | notification-template-line | vtv-icon-notification-template-line |
| &#xe93f; | 回收站 | recycle-line | vtv-icon-recycle-line |
| &#xe940; | 星光 | starlight-fill | vtv-icon-starlight-fill |
| &#xe941; | 发布 | publish | vtv-icon-publish |
| &#xe942; | 策略 | strategy-light | vtv-icon-strategy-light |
| &#xe943; | 断开 | disconnect | vtv-icon-disconnect |
| &#xe944; | 分配 | distribution-light | vtv-icon-distribution-light |
| &#xe945; | 快照 | snapshot-light | vtv-icon-snapshot-light |
| &#xe946; | 连通性测试 | connected-fill | vtv-icon-connected-fill |
| &#xe947; | usb2 | usb-fill | vtv-icon-usb-fill |
| &#xe948; | 云主机申请-专用 | cloud-host-application-dedicated-fill | vtv-icon-cloud-host-application-dedicated-fill |
| &#xe949; | 云主机申请-动态分配 | cloud-host-application-dynamic-allocation-fill | vtv-icon-cloud-host-application-dynamic-allocation-fill |
| &#xe94a; | GPU | gpu-line | vtv-icon-gpu-line |
| &#xe94b; | 云主机扩容 | expansion-of-cloud-hosts-fill | vtv-icon-expansion-of-cloud-hosts-fill |
| &#xe94c; | 帮助 | help-line | vtv-icon-help-line |
| &#xe94d; | 小三角-右箭头 | triangle-fold-small | vtv-icon-triangle-fold-small |
| &#xe94e; | 重新获取 | reacquire-light | vtv-icon-reacquire-light |
| &#xe94f; | 报表中心 | report-center-fill | vtv-icon-report-center-fill |
| &#xe950; | 资源服务 | resource-service-fill | vtv-icon-resource-service-fill |
| &#xe951; | 用户与访问管理 | user-and-Access-management-fill | vtv-icon-user-and-Access-management-fill |
| &#xe952; | 系统管理 | system-management-fill | vtv-icon-system-management-fill |
| &#xe953; | 告警中心 | alarm-center-fill | vtv-icon-alarm-center-fill |
| &#xe954; | 资源管理 | resource-management-fill | vtv-icon-resource-management-fill |
| &#xe955; | 火苗 | flames-fill | vtv-icon-flames-fill |
| &#xe956; | 特别关注 | special-attention-fill | vtv-icon-special-attention-fill |
| &#xe957; | 分支 | conditional-branch-fill | vtv-icon-conditional-branch-fill |
| &#xe958; | 大模型 | large-language-model-fill | vtv-icon-large-language-model-fill |
| &#xe959; | 系统参数 | system-parameter-fill | vtv-icon-system-parameter-fill |
| &#xe95a; | API | api-fill | vtv-icon-api-fill |
| &#xe95b; | VPC打通 | vpc-interconnection-fill | vtv-icon-vpc-interconnection-fill |
| &#xe95c; | ARM | arm-small | vtv-icon-arm-small |
| &#xe95d; | 海外自营 | self-operated-overseas-fill | vtv-icon-self-operated-overseas-fill |
| &#xe95e; | XAAS海外 | xaas-overseas-fill | vtv-icon-xaas-overseas-fill |
| &#xe95f; | 托管云 | managed-cloud-fill | vtv-icon-managed-cloud-fill |
| &#xe960; | XAAS国内 | xaas-in-the-domestic-market-fill | vtv-icon-xaas-in-the-domestic-market-fill |
| &#xe961; | 中转 | transfer-fill | vtv-icon-transfer-fill |
| &#xe962; | 文本处理 | text-processing-fill | vtv-icon-text-processing-fill |
| &#xe963; | 高可用管理 | high-availability-management-fill | vtv-icon-high-availability-management-fill |
| &#xe964; | 任务管理 | task-management-fill | vtv-icon-task-management-fill |
| &#xe965; | 整理节点 | organize-nodes-line | vtv-icon-organize-nodes-line |
| &#xe966; | 运行 | run-line | vtv-icon-run-line |
| &#xe967; | 中止 | discountinue-line | vtv-icon-discountinue-line |
| &#xe968; | 项目 | project-fill | vtv-icon-project-fill |
| &#xe969; | minus | minus | vtv-icon-minus |
| &#xe96a; | plus | plus | vtv-icon-plus |
| &#xe96b; | intel | intel | vtv-icon-intel |
| &#xe96c; | nvidia | nvidia | vtv-icon-nvidia |
| &#xe96d; | aluvatar | aluvatar | vtv-icon-aluvatar |
| &#xe96e; | metax | metax | vtv-icon-metax |
| &#xe96f; | hygon | hygon | vtv-icon-hygon |
| &#xe970; | ascend | ascend | vtv-icon-ascend |
| &#xe971; | deepseek | deepseek | vtv-icon-deepseek |
| &#xe972; | 站点对连接 | site-connect | vtv-icon-site-connect |
| &#xe973; | 切换 | switch-light | vtv-icon-switch-light |
| &#xe974; | hba | hba-card-fill | vtv-icon-hba-card-fill |
| &#xe975; | 编码卡 | code-card-fill | vtv-icon-code-card-fill |
| &#xe976; | raid | raid-card-fill | vtv-icon-raid-card-fill |
| &#xe977; | 研发 | development-fill | vtv-icon-development-fill |
| &#xe978; | 托管云POC测 | managed-cloud-poc-fill | vtv-icon-managed-cloud-poc-fill |
| &#xe979; | 深信服社区 | sangfor-community-line | vtv-icon-sangfor-community-line |
| &#xe97a; | pod | pod-line | vtv-icon-pod-line |
| &#xe97b; | 数据库智能管家 | intelligent-database-butler-fill | vtv-icon-intelligent-database-butler-fill |
| &#xe97c; | 备件管理 | spare-parts-management-line | vtv-icon-spare-parts-management-line |
| &#xe97d; | 容器 | container-line | vtv-icon-container-line |
| &#xe97e; | 导航 | nav-line | vtv-icon-nav-line |
| &#xe97f; | 回滚 | rollback-fill | vtv-icon-rollback-fill |
| &#xe980; | 数据库容灾 | database-disaster-recovery-fill | vtv-icon-database-disaster-recovery-fill |
| &#xe981; | file-management-line | wenjianguanli | vtv-icon-wenjianguanli |
| &#xe982; | application-management-line | yingyongguanli | vtv-icon-yingyongguanli |
| &#xe983; | 屏蔽 | notification-mask-fill | vtv-icon-notification-mask-fill |
| &#xe984; | 授权 | authorization-line | vtv-icon-authorization-line |
| &#xe985; | 已收藏 | collected | vtv-icon-collected |
| &#xe986; | 收藏 | no-collect | vtv-icon-no-collect |
| &#xe987; | 拖拽排序 | drag | vtv-icon-drag |
| &#xe988; | 线性删除 | line-delete | vtv-icon-line-delete |
| &#xe989; | user-hover | user-hover | vtv-icon-user-hover |
| &#xe98a; | user-normal | user-normal | vtv-icon-user-normal |
| &#xe98b; | 云容灾 | cloud-disaster-recovery-line | vtv-icon-cloud-disaster-recovery-line |
| &#xe98c; | 高可用管理 | high-availability-management-line | vtv-icon-high-availability-management-line |
| &#xe98d; | 接入管理 | access-management-line | vtv-icon-access-management-line |
| &#xe98e; | 机房选址 | computer-room-site-selection-line | vtv-icon-computer-room-site-selection-line |
| &#xe98f; | 信创麒麟 | kylin-fill | vtv-icon-kylin-fill |
| &#xe990; | 扫描 | scan-line | vtv-icon-scan-line |
| &#xe991; | 增购 | purchase-an-additional-vehicle-fill | vtv-icon-purchase-an-additional-vehicle-fill |
| &#xe992; | 监控 | surveillance-camera-line | vtv-icon-surveillance-camera-line |
| &#xe993; | 在线扩容 | online-expansion-line | vtv-icon-online-expansion-line |
| &#xe994; | 跳过 | skip-fill | vtv-icon-skip-fill |
| &#xe995; | 共享带宽 | shared-bandwidth-fill | vtv-icon-shared-bandwidth-fill |
| &#xe996; | 资源工单申请 | application-order | vtv-icon-application-order |
| &#xe997; | 资源管理 | resource-adiministration | vtv-icon-resource-adiministration |
| &#xe998; | 主页 | home | vtv-icon-home |
| &#xe999; | 聚合路由 | aggregate-route-line | vtv-icon-aggregate-route-line |
| &#xe99a; | 语义路由 | semantic-routing-line | vtv-icon-semantic-routing-line |
| &#xe99b; | 应用路由 | yingyongluyou | vtv-icon-yingyongluyou |
| &#xe99c; | 主页 | home-light | vtv-icon-home-light |
| &#xe99d; | 商店 | store-light | vtv-icon-store-light |
| &#xe99e; | 跳转链接 | jump-link-light | vtv-icon-jump-link-light |
| &#xe99f; | mcp广场 | mcp | vtv-icon-mcp |
| &#xe9a0; | 模型连接 | moxinglianjie | vtv-icon-moxinglianjie |
| &#xe9a1; | 模型发布 | a-moxingfabu3 | vtv-icon-a-moxingfabu3 |
| &#xe9a2; | 箭头 | barrow-left-fill | vtv-icon-barrow-left-fill |
| &#xe9a3; | 权限策略 | access-policy-line | vtv-icon-access-policy-line |
| &#xe9a4; | 标签 | sold-out-fill | vtv-icon-sold-out-fill |
| &#xe9b1; | tree-已展开 | tree-expanded | vtv-icon-tree-expanded |
| &#xe9b2; | tree-已收起 | tree-folded | vtv-icon-tree-folded |
| &#xe9c5; | 导航地图 | nav-map | vtv-icon-nav-map |
| &#xe9e7; | 快照 | menu-snapshot | vtv-icon-menu-snapshot |
| &#xe9f0; | 悬浮球-其他 | float-other | vtv-icon-float-other |
| &#xe9f1; | 悬浮球-返回顶部 | float-top | vtv-icon-float-top |
| &#xe9f2; | 悬浮球- 任务 | float-task | vtv-icon-float-task |
| &#xe9f3; | 悬浮球-智能客服 | float-robot | vtv-icon-float-robot |
| &#xea07; | 上传图像 | upload-image | vtv-icon-upload-image |
| &#xea4e; | 分组折叠表格_已展开 | group-table-expanded | vtv-icon-group-table-expanded |
| &#xea4f; | 分组折叠表格_已收起 | group-table-folded | vtv-icon-group-table-folded |
| &#xea50; | 跳转 | goto | vtv-icon-goto |
| &#xea74; | 通知-线性 | notice | vtv-icon-notice |
| &#xebba; | 轮播按钮-left | carousel-left | vtv-icon-carousel-left |
| &#xebbb; | 轮播按钮-right | carousel-right | vtv-icon-carousel-right |
| &#xebfd; | aDesk | adesk | vtv-icon-adesk |
| &#xec0d; | 图片加载失败 | error-img-brand | vtv-icon-error-img-brand |
| &#xfb89; | 发票 | bill | vtv-icon-bill |
| &#xe657b; | storage-line-color | storage-line-color | vtv-icon-storage-line-color |
| &#xe657c; | 反选 | invert-selection-fill | vtv-icon-invert-selection-fill |


---

## 快速索引

### 按类别查找

#### 基础操作

#### 基础操作

| 图标名称 | Symbol ID |
|---------|-----------|
| 提示-关闭 | vtv-icon-comp-tip-close |
| 置零 | vtv-icon-setzero |
| 编辑 | vtv-icon-edit-line |
| 更多 | vtv-icon-more-line |
| 用户-关闭 | vtv-icon-user-close-fill |
| cssp-close | vtv-icon-cssp-close-line |
| 新增 | vtv-icon-add |
| 删除 | vtv-icon-delete |
| 批量新增 | vtv-icon-batch-add |
| 新增分组 | vtv-icon-add-group |
| 弹窗关闭 | vtv-icon-win-close |
| Tab关闭 | vtv-icon-tab-close |
| 刷新 | vtv-icon-refresh |
| 搜索 | vtv-icon-search |
| 编辑 | vtv-icon-edit |
| 弹窗-永久删除 | vtv-icon-win-delete |
| 更多-圆 | vtv-icon-more-round-fill |
| 更多菜单 | vtv-icon-menu-more |
| 分配配置 | vtv-icon-setting |
| 信用卡 | vtv-icon-credit-card-color |
| 采编 | vtv-icon-collecting-and-editing-color |
| 创建 | vtv-icon-add-12 |
| 编辑 | vtv-icon-edit-12 |
| 更多-light | vtv-icon-more |
| 预训练数据集 | vtv-icon-pre-training-dataset-color |
| 微调数据集 | vtv-icon-Fine-tune-the-dataset |
| 编辑 | vtv-icon-edit-light |
| 删除 | vtv-icon-delete-light |
| 刷新 | vtv-icon-refresh-light |
| 加号 | vtv-icon-ele-add |
| 保存 | vtv-icon-save |
| 折叠-加 | vtv-icon-ele-fold-add |
| 威胁情报 | vtv-icon-bar-edit |
| 统一搜索查询 | vtv-icon-unified-search-query-fill |
| 批量编辑 | vtv-icon-multi-edit |
| 搜索框 | vtv-icon-comp-search |
| 设置 | vtv-icon-set |
| 更多 | vtv-icon-comp-more |
| 重置密码 | vtv-icon-reset-password |
| 设置指标信息 | vtv-icon-set-indicator-information-fill |
| 关闭 | vtv-icon-close-line |
| 服务器管理 | vtv-icon-node-setting-fill |
| 存储管理 | vtv-icon-storage-setting-fill |
| 存储扩容 | vtv-icon-storage-add-fill |
| 创建快照 | vtv-icon-add-snapshoot-fill |
| 创建备份 | vtv-icon-add-backup-fill |
| 手动添加 | vtv-icon-add-manually-light |
| 邮箱设置 | vtv-icon-email-settings-line |
| 线性删除 | vtv-icon-line-delete |
| 增购 | vtv-icon-purchase-an-additional-vehicle-fill |

#### 导航菜单

| 图标名称 | Symbol ID |
|---------|-----------|
| 展开 | vtv-icon-expand |
| 收起 | vtv-icon-unexpand |
| 收起-01 | vtv-icon-fold |
| 展开-01 | vtv-icon-unfold |
| 双箭头-向上 | vtv-icon-double-arrow-up |
| 双箭头-向下 | vtv-icon-double-arrow-down |
| 分组 | vtv-icon-file-folder-line |
| 文件夹 展开 | vtv-icon-file-expand |
| 导航左菜单-收起 | vtv-icon-comp-arrow-right-big |
| 导航左菜单-展开 | vtv-icon-comp-arrow-down-big |
| 折叠 | vtv-icon-triangle-fold |
| 展开 | vtv-icon-triangle-unfold |
| 更多菜单箭头 | vtv-icon-arrow-right |
| 更多菜单 | vtv-icon-menu-more |
| nav消息 | vtv-icon-nav-info |
| 标签s | vtv-icon-tag-expand |
| 左侧导航-收起 | vtv-icon-comp-menu-collapse |
| 左侧导航-展开 | vtv-icon-comp-menu-expand |
| 听诊器 | vtv-icon-echometer-color |
| nav-紧急漏洞检测 | vtv-icon-badsector-scan |
| nav-事件统计分析 | vtv-icon-badsector-analyse |
| 更多菜单箭头-上 | vtv-icon-arrow-up |
| 更多菜单箭头-下 | vtv-icon-arrow-down |
| 更多菜单箭头-左 | vtv-icon-arrow-left |
| 导航 | vtv-icon-navigator |
| 收起 | vtv-icon-menu-fold |
| 展开 | vtv-icon-menu-unfold |
| 侧栏-展开 | vtv-icon-menu-expand |
| 侧栏-收起 | vtv-icon-menu-collapse |
| 指针 | vtv-icon-arrow |
| 下拉 | vtv-icon-angle |
| 向上箭头 | vtv-icon-full-arrow-up |
| 折叠-减 | vtv-icon-ele-fold-minus |
| 折叠-加 | vtv-icon-ele-fold-add |
| time-arrow | vtv-icon-ele-time-arrow |
| 下拉框 | vtv-icon-comp-angle-down |
| 下拉框-向上 | vtv-icon-comp-angle-up |
| 目录展开 | vtv-icon-left-menu-expand |
| 目录收起 | vtv-icon-left-menu-collapse |
| 导航左菜单-上箭头 | vtv-icon-comp-arrow-up-big |
| 小三角-右箭头 | vtv-icon-triangle-fold-small |
| 导航 | vtv-icon-nav-line |
| 主页 | vtv-icon-home |
| 主页 | vtv-icon-home-light |
| 箭头 | vtv-icon-barrow-left-fill |
| tree-已展开 | vtv-icon-tree-expanded |
| tree-已收起 | vtv-icon-tree-folded |
| 导航地图 | vtv-icon-nav-map |
| 快照 | vtv-icon-menu-snapshot |
| 分组折叠表格_已展开 | vtv-icon-group-table-expanded |
| 分组折叠表格_已收起 | vtv-icon-group-table-folded |

#### 文件操作

| 图标名称 | Symbol ID |
|---------|-----------|
| 隔离文件 | vtv-icon-quarantine-file |
| 分组 | vtv-icon-file-folder-line |
| 下载 | vtv-icon-download-line |
| 导入 | vtv-icon-import |
| 文件夹 展开 | vtv-icon-file-expand |
| 文件夹 | vtv-icon-file |
| Virus isolation | vtv-icon-virus-file-isolation |
| 导出 | vtv-icon-export |
| 文件漏洞 | vtv-icon-filevulnerability |
| 上传 | vtv-icon-upload |
| 下载 | vtv-icon-download |
| 上传 | vtv-icon-ele-upload |
| file-management-line | vtv-icon-wenjianguanli |
| 上传图像 | vtv-icon-upload-image |

#### 状态指示

| 图标名称 | Symbol ID |
|---------|-----------|
| 暂停 | vtv-icon-pause |
| 容灾状态 | vtv-icon-dr-status |
| 重启 | vtv-icon-restart |
| 关闭审核 | vtv-icon-stop-audit |
| 自定义表单 | vtv-icon-custom-form |
| 关闭电源 | vtv-icon-power-off |
| 重启 | vtv-icon-reboot |
| 开机 | vtv-icon-power-on |
| 关机 | vtv-icon-shutdown |
| 平台 | vtv-icon-platform-line |
| 弹窗-停止服务 | vtv-icon-win-stop |
| 弹窗-关机 | vtv-icon-win-shutdown |
| 弹窗-重启 | vtv-icon-win-reboot |
| form待激活 | vtv-icon-form-waiting |
| form挂起 | vtv-icon-form-suspend |
| form-告警 | vtv-icon-form-alert |
| form离线 | vtv-icon-form-offline |
| form关机 | vtv-icon-form-shutdown |
| form失败 | vtv-icon-form-failed |
| form运行中 | vtv-icon-form-running |
| form执行中 | vtv-icon-form-executing |
| form极速恢复 | vtv-icon-rapid-recovery |
| 格式化 | vtv-icon-format |
| 平台 | vtv-icon-platform-color |
| 性能型 | vtv-icon-performance |
| 高性能 | vtv-icon-high-performance |
| 设备运行 | vtv-icon-status |
| form完成 | vtv-icon-form-finish |
| 启用审核 | vtv-icon-start-audit |
| 挂起 | vtv-icon-pause-brand |
| 一站式事件查看 | vtv-icon-one-stop-event-viewing-fill |
| 设置指标信息 | vtv-icon-set-indicator-information-fill |
| 关机 | vtv-icon-shutdown-line |
| 应用全链路观测平台 | vtv-icon-application-full-link-observation-platform-line |

#### 业务功能

| 图标名称 | Symbol ID |
|---------|-----------|
| 安全_01 | vtv-icon-security-alert-line |
| 备份 | vtv-icon-backups |
| 云IT | vtv-icon-cloud-it |
| 灾备集群 | vtv-icon-acloud |
| 阿里云 | vtv-icon-ali-acloud |
| security-line-color | vtv-icon-security-line-color |
| 策略 | vtv-icon-policy-line |
| 应用 | vtv-icon-application |
| 云环境 | vtv-icon-cloud-line |
| 资产态势监控 | vtv-icon-monitor |
| 立即备份 | vtv-icon-backup-now |
| qingcloud | vtv-icon-qingcloud |
| Tencent cloud | vtv-icon-qcloud |
| xyclouds | vtv-icon-xyclouds |
| acloud | vtv-icon-acloud-type |
| 监控信息 | vtv-icon-monitor-info |
| cloud | vtv-icon-cloud |
| ecloud | vtv-icon-ecloud |
| 安全 | vtv-icon-security-line |
| 应用软件漏洞 | vtv-icon-application-loophole |
| 备份管理 | vtv-icon-backup-manage |
| application-new | vtv-icon-application-system |
| 创建备份 | vtv-icon-backup |
| 加入监控中心 | vtv-icon-join-monitor |
| 证券 | vtv-icon-security-color |
| 集成 | vtv-icon-backup-color |
| 云服务器 | vtv-icon-cloud-server |
| 备份 | vtv-icon-backup-line |
| 云间互联-新 | vtv-icon-cloud-connect |
| 安全事件 | vtv-icon-security-ingident-fill |
| 云安全资源池 | vtv-icon-security-resource |
| 安全 | vtv-icon-security-light |
| 安全升级 | vtv-icon-security-update-fill |
| 策略检查 | vtv-icon-policy-check-fill |
| 策略调优 | vtv-icon-policy-tuning-fill |
| 云镜 | vtv-icon-host-security |
| 云盾 | vtv-icon-cloud-waf |
| 云守 | vtv-icon-security-butler |
| 用户访问监测 | vtv-icon-user-access-monitoring-fill |
| 云端获取 | vtv-icon-cloud-get |
| 云端下发 | vtv-icon-cloud-push |
| 实时监控查询 | vtv-icon-real-time-monitoring-query-fill |
| 监控 | vtv-icon-monitor-line |
| 云端代理管理 | vtv-icon-cloud-proxy-management-line |
| 应用全链路观测平台 | vtv-icon-application-full-link-observation-platform-line |
| 创建备份 | vtv-icon-add-backup-fill |
| 云主机 | vtv-icon-vm-cloud-fill |
| 用户安全 | vtv-icon-user-security |
| 资源申请 | vtv-icon-resource-application-line |
| 云主机申请-专用 | vtv-icon-cloud-host-application-dedicated-fill |
| 云主机申请-动态分配 | vtv-icon-cloud-host-application-dynamic-allocation-fill |
| 云主机扩容 | vtv-icon-expansion-of-cloud-hosts-fill |
| 托管云 | vtv-icon-managed-cloud-fill |
| 托管云POC测 | vtv-icon-managed-cloud-poc-fill |
| application-management-line | vtv-icon-yingyongguanli |
| 云容灾 | vtv-icon-cloud-disaster-recovery-line |
| 资源工单申请 | vtv-icon-application-order |
| 权限策略 | vtv-icon-access-policy-line |

#### 数据管理

| 图标名称 | Symbol ID |
|---------|-----------|
| servers | vtv-icon-server-circle |
| 角色 | vtv-icon-role-line |
| 物理机 | vtv-icon-server-line |
| 用户组 | vtv-icon-user-group--line |
| user | vtv-icon-user-thin |
| 存储 | vtv-icon-storage-line |
| 用户-关闭 | vtv-icon-user-close-fill |
| 服务器 | vtv-icon-server-color |
| 成员 | vtv-icon-user |
| 存储适配器 | vtv-icon-storage-adapter-fill |
| 用户组 | vtv-icon-user-group-color |
| 存储 | vtv-icon-storage |
| 存储s | vtv-icon-storage-lack |
| 64-存储总数 | vtv-icon-storage-large |
| 云服务器 | vtv-icon-cloud-server |
| 设备-asan | vtv-icon-storage-asan |
| 设备-FC | vtv-icon-storage-fc |
| 设备-ISCSI | vtv-icon-storage-iscsi |
| 服务器 | vtv-icon-server |
| 设备-SQLServer-single | vtv-icon-database-sqlserver-single |
| 设备-SQLServer-alwayso | vtv-icon-database-sqlserver-alwayson |
| 设备-oracle-rac | vtv-icon-database-oracle-rac |
| 设备-SQLServer | vtv-icon-database-sqlserver |
| 设备-SQLServer-Disable | vtv-icon-database-sqlserver-single-disabled |
| 设备-oracle-rac-gray | vtv-icon-database-oracle-rac-disabled |
| 设备-oracle-single | vtv-icon-database-oracle-single |
| 数据库容灾 | vtv-icon-database-dr |
| 网络 | vtv-icon-network |
| 用户访问监测 | vtv-icon-user-access-monitoring-fill |
| 数据库 | vtv-icon-database |
| 转为服务器 | vtv-icon-to-server |
| 移动 | vtv-icon-mobile-network |
| 数据库智能诊断 | vtv-icon-database-intelligent-diagnosis-line |
| SQLserver | vtv-icon-SQLserver-line |
| 存储管理 | vtv-icon-storage-setting-fill |
| 存储扩容 | vtv-icon-storage-add-fill |
| 运维服务 | vtv-icon-user-maintenance-fill |
| 网络对象 | vtv-icon-network-objects |
| 用户安全 | vtv-icon-user-security |
| 用户与访问管理 | vtv-icon-user-and-Access-management-fill |
| 数据库智能管家 | vtv-icon-intelligent-database-butler-fill |
| 数据库容灾 | vtv-icon-database-disaster-recovery-fill |
| user-hover | vtv-icon-user-hover |
| user-normal | vtv-icon-user-normal |
| storage-line-color | vtv-icon-storage-line-color |

#### 设备管理

| 图标名称 | Symbol ID |
|---------|-----------|
| 云主机 | vtv-icon-vm |
| HDD | vtv-icon-disk |
| VMware集群 | vtv-icon-vmware |
| vm-line-color | vtv-icon-vm-line-color |
| VMWARE | vtv-icon-vmware-type |
| vmware | vtv-icon-vmware-line |
| disk-HDD | vtv-icon-disk-hdd |
| disk-SSD | vtv-icon-disk-ssd |
| 集群 | vtv-icon-cluster-line |
| 更换硬盘 | vtv-icon-change-disk |
| 主机 | vtv-icon-host |
| 主机s | vtv-icon-host-lack |
| 集群 | vtv-icon-cluster |
| 集群s | vtv-icon-cluster-lack |
| 内存 | vtv-icon-memory |
| CPU | vtv-icon-cpu |
| 集群 | vtv-icon-cluster-fill |
| 云主机 | vtv-icon-vm-root |
| 云主机 | vtv-icon-virtual-host |
| 云镜 | vtv-icon-host-security |
| 主机磁盘 | vtv-icon-vm-disk-fill |
| 虚拟共享盘 | vtv-icon-v-shared-disk-line |
| 云主机 | vtv-icon-vm-cloud-fill |
| 云主机申请-专用 | vtv-icon-cloud-host-application-dedicated-fill |
| 云主机申请-动态分配 | vtv-icon-cloud-host-application-dynamic-allocation-fill |
| 云主机扩容 | vtv-icon-expansion-of-cloud-hosts-fill |


---

## 示例代码

```html
<!-- 在 HTML 中使用图标 -->

<!-- 1. 确保在 <body> 后引入了图标定义 -->
<svg xmlns="http://www.w3.org/2000/svg" style="display:none">
  <symbol id="vtv-icon-add" viewBox="0 0 1024 1024">
    <path d="..."/>
  </symbol>
  <!-- 更多图标... -->
</svg>

<!-- 2. 使用图标 -->
<button>
  <svg class="icon"><use href="#vtv-icon-add"></use></svg>
  新增
</button>

<!-- 3. 控制大小 -->
<svg class="icon icon-lg"><use href="#vtv-icon-search"></use></svg>

<!-- 4. 控制颜色 -->
<svg class="icon" style="color: #1770E6;"><use href="#vtv-icon-home"></use></svg>
```

```css
/* 图标基础样式 */
.icon {
  width: 16px;
  height: 16px;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  flex-shrink: 0;
}

/* 尺寸类 */
.icon-xs  { width: 12px; height: 12px; }
.icon-sm  { width: 14px; height: 14px; }
.icon-md  { width: 16px; height: 16px; }
.icon-lg  { width: 20px; height: 20px; }
.icon-xl  { width: 24px; height: 24px; }
.icon-2xl { width: 28px; height: 28px; }
.icon-3xl { width: 40px; height: 40px; }
.icon-4xl { width: 48px; height: 48px; }
```
