---
version: 内测
name: SangforCloud
description: 深信服云产品是面向企业级云的管理后台。品牌色来自波塞冬蓝（Poseidon Blue）/石墨烯黑的搭配，零星的有一些白俄罗斯绿的点缀，这是一种沉稳专业、严谨又带一些科技感的感受营造。系统采用深色顶部导航（石墨烯黑）+纯白色侧边导航，与浅色内容（蓝灰度背景）的经典B端布局范式。界面风格沉稳专业，通过阴影来打造界面层级。字体采用系统默认字体栈（PingFang SC / Microsoft YaHei / Source Han Sans），确保跨平台一致性。  

colors:
  primary: "#1770E6"
  primary-hover: "#1876F2"
  primary-disabled: "#9FC8F7"
  ink: "#000000"
  body: "#333333"
  body-strong: "#333333"
  muted: "#666666"
  muted-soft: "#999999"
  on-primary: "#FFFFFF"
  on-dark: "#FFFFFF"
  on-dark-secondary: "#CCCCCC"
  hairline: "#DCE0E6"
  hairline-soft: "#DCE0E6"
  hairline-secondary: "#EBECF0"
  border: "#CCD1D9"
  blue-gray-default: "#CCD1D9"
  canvas: "#EBEDF0"
  surface-card: "#FFFFFF"
  surface-soft: "#FAFBFC"
  surface-header: "#242A33"
  surface-hover: "#F7F8FA"
  surface-disabled: "#F3F3F3"
  surface-page: "#F5F6FA"
  surface-feature: "#F0F1F5"
  surface-belarus-green: "#50B371"
  accent-belarus-green: "#50B371"
  accent-golden-yellow: "#FF9500"
  success: "#50B371"
  success-hover: "#73E699"
  success-light: "#EDFCF2"
  warning: "#FF9500"
  warning-hover: "#FFAA33"
  warning-light: "#FFF5E6"
  error: "#E64545"
  error-hover: "#EB5252"
  error-light: "#FFF2F2"
  overlay-mask: "rgba(0, 0, 0, 0.4)"


typography:
  display-8xl:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 64px
    fontWeight: 600
    lineHeight: 77px
    letterSpacing: 0
  display-5xl:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 40px
    fontWeight: 600
    lineHeight: 67px
    letterSpacing: 0
  display-4xl:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 32px
    fontWeight: 500
    lineHeight: 38px
    letterSpacing: 0
  display-3xl:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 28px
    fontWeight: 500
    lineHeight: 34px
    letterSpacing: 0
  title-lg:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 24px
    fontWeight: 500
    lineHeight: 33px
    letterSpacing: 0
  title-page:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 20px
    fontWeight: 500
    lineHeight: 28px
    letterSpacing: 0
  title-model:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 16px
    fontWeight: 500
    lineHeight: 22px
    letterSpacing: 0
  title-card:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 14px
    fontWeight: 500
    lineHeight: 20px
    letterSpacing: 0
  body-md:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 22px
    letterSpacing: 0
  body-sm:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 12px
    fontWeight: 400
    lineHeight: 20px
    letterSpacing: 0
  caption:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 12px
    fontWeight: 400
    lineHeight: 17px
    letterSpacing: 0
  caption-strong:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 12px
    fontWeight: 500
    lineHeight: 20px
    letterSpacing: 0
  code:
    fontFamily: "'ALIBABA Font', 'SF Mono', 'Roboto Mono', monospace"
    fontSize: 13px
    fontWeight: 400
    lineHeight: 1.6
    letterSpacing: 0
  button:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 22px
    letterSpacing: 0
  nav-link:
    fontFamily: "'PingFang SC', 'Microsoft YaHei', 'Source Han Sans', 'Noto Sans CJK SC', sans-serif"
    fontSize: 12px
    fontWeight: 400
    lineHeight: 20px
    letterSpacing: 0

rounded:
  xs: 2px
  sm: 4px
  default: 6px
  lg: 8px
  xl: 16px
  circle: 50%

spacing:
  xxs: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  section: 96px

breakpoints:
  xs: 320px
  sm: 576px
  md: 768px
  lg: 992px
  xl: 1200px
  2xl: 1920px

animation:
  duration-fast: 150ms
  duration-normal: 200ms
  duration-slow: 300ms
  duration-slower: 400ms
  easing-standard: "cubic-bezier(0.4, 0, 0.2, 1)"
  easing-decelerate: "cubic-bezier(0, 0, 0.2, 1)"
  easing-accelerate: "cubic-bezier(0.4, 0, 1, 1)"
  easing-bounce: "cubic-bezier(0.34, 1.56, 0.64, 1)"

shadows:
  0: "1px solid rgba(0, 0, 0, 0.2)"
  sm: "0px 1px 3px 0px rgba(0, 0, 0, 0.08)"
  md: "0px 1px 4px 0px rgba(0, 0, 0, 0.08)"
  lg: "2px 6px 12px 0px rgba(0, 0, 0, 0.16)"
  xl: "0px 8px 24px 0px rgba(0, 0, 0, 0.16)"

components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.text-on-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    padding: 0 12px
    height: 32px
    border: "1px solid {colors.primary}"
    transition: "{animation.duration-fast} {animation.easing-standard}"
  button-primary-active:
    backgroundColor: "#156AD9"
    textColor: "{colors.text-on-primary}"
    border: "1px solid #1464CC"
  button-primary-disabled:
    backgroundColor: "rgba(23, 112, 230, 0.4)"
    textColor: "rgba(255, 255, 255, 0.4)"
    border: "1px solid rgba(15, 91, 196, 0.4)"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
    textColor: "{colors.text-on-primary}"
    border: "1px solid {colors.primary}"
  button-secondary:
    backgroundColor: "{colors.gray-white}"
    textColor: "{colors.text-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    padding: 0 12px
    height: 32px
    border: "1px solid {colors.blue-gray-default}"
  button-secondary-hover:
    backgroundColor: "{colors.gray-white}"
    border: "1px solid {colors.blue-gray-d20}"
  button-secondary-active:
    backgroundColor: "{colors.gray-white}"
    textColor: "{colors.text-primary}"
    border: "1px solid {colors.primary-light}"
  button-secondary-disabled:
    backgroundColor: "rgba(255, 255, 255, 0.4)"
    textColor: "rgba(64, 70, 85, 0.4)"
    border: "1px solid rgba(217, 221, 229, 0.4)"
  button-ghost:
    backgroundColor: "transparent"
    textColor: "{colors.text-primary}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    padding: 0 12px
    height: 32px
    border: "1px solid {colors.blue-gray-default}"
  button-ghost-active:
    backgroundColor: "transparent"
    border: "1px solid #1464CC"
  button-ghost-disabled:
    backgroundColor: "transparent"
    textColor: "rgba(64, 70, 85, 0.4)"
    border: "1px solid rgba(0, 0, 0, 0.4)"
  button-text:
    backgroundColor: "transparent"
    textColor: "{colors.primary}"
    typography: "{typography.button}"
    border: "none"
  button-icon-only:
    backgroundColor: "transparent"
    textColor: "rgba(67, 67, 67, 0.8)"
    border: "none"
    size: 32px
  top-nav:
    backgroundColor: "{colors.graphite-black}"
    textColor: "{colors.on-primary}"
    height: 52px
    zIndex: 1000
  sidebar:
    backgroundColor: "{colors.gray-l60}"
    textColor: "{colors.text-on-primary}"
    width: 224px
    collapsedWidth: 52px
  text-input:
    backgroundColor: "{colors.gray-white}"
    textColor: "{colors.text-primary}"
    typography: "{typography.body-sm}"
    rounded: "{rounded.xs}"
    padding: 6px 12px
    height: 32px
    border: "1px solid {colors.blue-gray-default}"
    transition: "{animation.duration-fast} {animation.easing-standard}"
  text-input-focus:
    backgroundColor: "{colors.gray-white}"
    border: "1px solid {colors.primary}"
    shadow: "0 0 0 3px rgba(23, 112, 230, 0.2)"
  text-input-error:
    backgroundColor: "{colors.gray-white}"
    border: "1px solid {colors.error}"
  text-input-disabled:
    backgroundColor: "{colors.gray-l20}"
    textColor: "{colors.gray-d40}"
    border: "1px solid {colors.blue-gray-default}"
  card:
    backgroundColor: "{colors.surface-card}"
    textColor: "{colors.text-primary}"
    rounded: "{rounded.default}"
    padding: 24px
    border: "1px solid {colors.blue-gray-l20}"
    transition: "{animation.duration-fast} {animation.easing-standard}"
  card-hover:
    border: "1px solid {colors.blue-gray-d20}"
    shadow: "{shadows.lg}"
  card-disabled:
    opacity: 0.5
    cursor: not-allowed
  feature-card:
    backgroundColor: "{colors.surface-card}"
    textColor: "{colors.text-primary}"
    rounded: "{rounded.default}"
    padding: 24px
    border: "1px solid {colors.blue-gray-l20}"
  data-table:
    backgroundColor: "{colors.surface-card}"
    textColor: "{colors.text-primary}"
    headerBackground: "{colors.blue-gray-l60}"
    rowHover: "{colors.blue-gray-l50}"
    border: "1px solid {colors.blue-gray-l20}"
  dialog:
    backgroundColor: "{colors.surface-card}"
    textColor: "{colors.text-primary}"
    rounded: "{rounded.lg}"
    shadow: "{shadows.xl}"
    overlay: "{colors.overlay-mask}"
    transition: "{animation.duration-slow} {animation.easing-decelerate}"
  dropdown-menu:
    backgroundColor: "{colors.gray-white}"
    textColor: "{colors.text-primary}"
    rounded: "{rounded.default}"
    shadow: "{shadows.lg}"
    border: "1px solid {colors.blue-gray-l20}"
  badge:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.text-on-primary}"
    typography: "{typography.caption}"
    rounded: "{rounded.circle}"
    padding: 0 8px
    height: 18px
  tag:
    backgroundColor: "{colors.blue-gray-l60}"
    textColor: "{colors.blue-gray-d50}"
    typography: "{typography.caption}"
    rounded: "{rounded.xs}"
    padding: 0 8px
    height: 18px
    border: "1px solid {colors.blue-gray-l20}"
  alert-success:
    backgroundColor: "{colors.success-light}"
    textColor: "{colors.success}"
    border: "1px solid {colors.success}"
    rounded: "{rounded.default}"
  alert-warning:
    backgroundColor: "{colors.warning-light}"
    textColor: "{colors.warning}"
    border: "1px solid {colors.warning}"
    rounded: "{rounded.default}"
  alert-error:
    backgroundColor: "{colors.error-light}"
    textColor: "{colors.error}"
    border: "1px solid {colors.error}"
    rounded: "{rounded.default}"
  alert-info:
    backgroundColor: "{colors.primary-light}"
    textColor: "{colors.primary}"
    border: "1px solid {colors.primary}"
    rounded: "{rounded.default}"
  tooltip:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.on-primary}"
    typography: "{typography.caption}"
    rounded: "{rounded.sm}"
    padding: 4px 8px
  pagination:
    backgroundColor: "transparent"
    textColor: "{colors.text-primary}"
    rounded: "{rounded.xl}"
    activeBackground: "{colors.primary-light}"
    activeTextColor: "{colors.primary}"
    transition: "{animation.duration-fast} {animation.easing-standard}"
  pagination-item-hover:
    backgroundColor: "{colors.surface-hover}"
  loading-spinner:
    color: "{colors.primary}"
    size: 16px
  skeleton:
    backgroundColor: "{colors.blue-gray-l30}"
    shimmerColor: "{colors.blue-gray-l20}"
    rounded: "{rounded.sm}"
  select:
    backgroundColor: "{colors.surface-card}"
    textColor: "{colors.body}"
    border: "1px solid {colors.hairline}"
    rounded: "{rounded.xs}"
    height: 32px
    transition: "{animation.duration-fast} {animation.easing-standard}"
  select-hover:
    border: "1px solid {colors.muted}"
  select-focus:
    border: "1px solid {colors.primary}"
  select-disabled:
    backgroundColor: "{colors.surface-disabled}"
    textColor: "{colors.muted-soft}"
    border: "1px solid {colors.hairline}"
  select-error:
    border: "1px solid {colors.error}"
  select-compact:
    height: 24px
  checkbox:
    size: 16px
    border: "1px solid {colors.hairline}"
    backgroundColor: "{colors.surface-card}"
    rounded: "{rounded.xs}"
    transition: "{animation.duration-fast} {animation.easing-standard}"
  checkbox-checked:
    backgroundColor: "{colors.primary}"
    border: "1px solid {colors.primary}"
    iconColor: "{colors.on-primary}"
  checkbox-indeterminate:
    backgroundColor: "{colors.primary}"
    border: "1px solid {colors.primary}"
    iconColor: "{colors.on-primary}"
  checkbox-disabled:
    backgroundColor: "{colors.surface-disabled}"
    border: "1px solid {colors.hairline}"
    textColor: "{colors.muted-soft}"
  radio:
    size: 14px
    border: "1px solid {colors.hairline}"
    backgroundColor: "{colors.surface-card}"
    transition: "{animation.duration-fast} {animation.easing-standard}"
  radio-checked:
    backgroundColor: "{colors.primary}"
    border: "1px solid {colors.primary}"
    dotColor: "{colors.on-primary}"
    dotSize: 6px
  radio-disabled:
    backgroundColor: "{colors.surface-disabled}"
    border: "1px solid {colors.hairline}"
    textColor: "{colors.muted-soft}"
  switch:
    width: 32px
    height: 16px
    rounded: "{rounded.xl}"
    thumbSize: 12px
    thumbColor: "{colors.on-primary}"
    transition: "{animation.duration-normal} {animation.easing-standard}"
  switch-on:
    backgroundColor: "{colors.primary}"
  switch-off:
    backgroundColor: "{colors.muted-soft}"
  switch-large:
    width: 40px
    height: 20px
    thumbSize: 16px
  switch-disabled:
    opacity: 0.4
  tabs:
    height: 36px
    padding: 0 20px
    backgroundColor: "{colors.canvas}"
    rounded: "{rounded.xs}"
    transition: "{animation.duration-fast} {animation.easing-standard}"
  tabs-active:
    backgroundColor: "{colors.surface-card}"
    textColor: "{colors.primary}"
    indicatorColor: "{colors.primary}"
    indicatorHeight: 2px
  tabs-disabled:
    textColor: "{colors.muted-soft}"
    opacity: 0.4
  tabs-underline:
    borderBottom: "1px solid {colors.hairline}"
    backgroundColor: "transparent"
  breadcrumb:
    height: 40px
    fontSize: 14px
    textColor: "{colors.muted}"
  breadcrumb-link-hover:
    textDecoration: underline
  breadcrumb-current:
    textColor: "{colors.body}"
  breadcrumb-separator:
    textColor: "{colors.muted-soft}"
  drawer:
    width: 480px
    backgroundColor: "{colors.surface-card}"
    shadow: "{shadows.xl}"
    transition: "{animation.duration-slow} {animation.easing-decelerate}"
  drawer-header:
    height: 56px
    padding: 0 16px
    borderBottom: "1px solid {colors.hairline}"
  drawer-footer:
    height: 64px
    padding: 0 16px
    borderTop: "1px solid {colors.hairline}"
  progress-line:
    height: 6px
    rounded: "{rounded.xl}"
    trackColor: "{colors.canvas}"
    barColor: "{colors.primary}"
    transition: "{animation.duration-slow} {animation.easing-standard}"
  progress-line-sm:
    height: 2px
  progress-success:
    barColor: "{colors.success}"
  progress-error:
    barColor: "{colors.error}"
  progress-warning:
    barColor: "{colors.warning}"
  progress-circle:
    size: 64px
    strokeWidth: 3px
  empty:
    iconSize: 48px
    titleColor: "{colors.body}"
    descriptionColor: "{colors.muted}"
    padding: 24px
    gap: 16px
  notification:
    width: 320px
    backgroundColor: "{colors.surface-card}"
    rounded: "{rounded.xs}"
    shadow: "{shadows.md}"
    padding: 12px 16px
    transition: "{animation.duration-slow} {animation.easing-decelerate}"
  notification-icon:
    size: 24px
  notification-title:
    typography: "{typography.body-md}"
    textColor: "{colors.body-strong}"
  notification-description:
    typography: "{typography.body-sm}"
    textColor: "{colors.body}"
  collapse:
    rounded: "{rounded.default}"
    transition: "{animation.duration-normal} {animation.easing-standard}"
  collapse-header:
    height: 48px
    padding: 0 16px
    backgroundColor: "{colors.surface-card}"
    textColor: "{colors.body}"
    typography: "{typography.title-card}"
  collapse-header-active:
    textColor: "{colors.primary}"
  collapse-content:
    padding: 16px
    backgroundColor: "{colors.surface-hover}"
    borderTop: "1px solid {colors.hairline}"
  steps:
    stepCircleSize: 24px
    connectorColor: "{colors.hairline}"
  steps-active:
    circleBackground: "{colors.primary}"
    circleTextColor: "{colors.on-primary}"
  steps-completed:
    circleBackground: "{colors.success}"
    circleTextColor: "{colors.on-primary}"
  steps-inactive:
    circleBorder: "1px solid {colors.hairline}"
    circleTextColor: "{colors.muted-soft}"
  toolbar:
    height: 52px
    padding: 10px 0
    backgroundColor: "transparent"
  toolbar-sm:
    height: 40px
    padding: 8px 0
---

## 概述

深信服云BG设计系统是面向企业级云计算管理后台的专业设计规范，服务于深信服云BG旗下所有产品界面。系统以**波塞冬蓝** (`{colors.primary}` — #1770E6) 为核心品牌色，采用**深色顶部导航 + 白色侧边导航 + 浅色产品色块区域** 的经典B端布局范式，营造沉稳、专业、可信赖的企业级产品氛围。

与消费级产品的活泼风格不同，深信服云BG设计系统强调：
1. **信息密度** — 适度密度的数据展示以提升查阅体验与操作效率
2. **层级清晰** — 通过严谨的色阶和间距系统构建明确的信息层级
3. **专业沉稳又不显沉闷** — 深色导航头（石墨烯黑）奠定专业基调，蓝色品牌色传递科技感，绿色品牌色传递创新感与新鲜感（白俄罗斯绿）

系统通常使用**浅色页面背景** (`{colors.surface-page}` — #F5F6FA) 作为默认内容区域背景，蓝灰色调营造专业感。全局导航采用**深色导航表面** (`{colors.surface-header}` — #242A33) ，与浅色内容区域形成对比，营造沉稳的企业级氛围。而**白色卡片表面** (`{colors.surface-card}` — #FFFFFF) 却作为侧边导航内容卡片、表格、弹窗背景，保持内容区域的清晰度和专业性。 另外还用**绿色表面**(`{colors.surface-belarus-green}`-#50B371）表示成功状态、完成标记、正向反馈，可视化图表中使用的绿色部分如进度条、折线趋势等，说明性插图的强调部分，以营造系统的科技感和创新感。

**核心特征：**
- 波塞冬蓝品牌色 (`{colors.primary}` — #1770E6) 用于主要按钮、链接、选中状态，传递专业科技感
- 石墨烯黑顶部导航 (`{colors.graphite-black}` — #242A33) 营造沉稳的企业级氛围
- 蓝灰度中性色系 (`{colors.blue-gray-default}` — #CCD1D9) 用于边框、分割线、背景，避免纯灰的单调感
- 浅石墨烯黑图标体系 (`{colors.graphite-black-l30}` — #3E4A59) 用于图标、小部件（已完成）等，营造沉稳的企业级氛围
- 内容区通常是在浅色背景上放置白色卡片表面容器，再配合阴影效果，用于将内容与背景分离，突出内容区域。内容区域可以是由多个大卡片组成，每个卡片之间通过间距隔开。
- 6级圆角体系：从2px到50%，覆盖标签到头像的全部场景
- 5层阴影层级：从线框到模态，精确表达元素层级关系


## 颜色

### 品牌与强调色
- **波塞冬蓝/主色** (`{colors.primary}` — #1770E6): 深信服云BG核心品牌识别色。用于主要按钮背景、重要链接、选中状态、品牌标识。是系统中最具辨识度的颜色。
- **波塞冬蓝悬浮** (`{colors.primary-hover}` — #1876F2): 按钮和链接的悬浮状态。
- **波塞冬蓝点击** (`{colors.primary-active}` — #156AD9): 按钮点击、激活状态。
- **波塞冬蓝禁用** (`{colors.primary-disabled}` — #9FC8F7): 按钮禁用状态，40%透明度。
- **波塞冬蓝浅色** (`{colors.primary-light}` — #E6F1FF): 浅色背景、hover背景、信息提示背景。

### 分类强调色
- **白俄罗斯绿/成功色** (`{colors.success}` — #50B371): 强调成功状态、完成标记、正向反馈。对应HSB: H140 S55 B70。
- **金黄/警告色** (`{colors.warning}` — #FF9500): 强调警告提示、需关注信息、进行中状态。对应HSB: H35 S100 B100。
- **柠檬黄/轻微警告色** (`{colors.warning-lemon}` — #FFD500): 强调警告提示、需关注信息、进行中状态。对应HSB: H255 S213 B0。
- **古典红/错误色** (`{colors.error}` — #E64545): 强调错误提示、失败状态、危险操作。对应HSB: H360 S70 B90。
- **石墨烯黑/信息色** (`{colors.info}` — #596A80): 强调常规状态、没问题无需太多关注。对应HSB: H214 S30 B20。

### 背景色
- **蓝灰背景** (`{colors.canvas}` — #EBEDF0): 页面背景
- **卡片背景** (`{colors.surface-card}` — #FFFFFF): 使用频率最高的背景色，卡片、菜单、面板、侧边导航、表格白色行背景等等。
- **柔和背景** (`{colors.surface-soft}` — #FAFBFC): 表格行灰色背景
- **悬浮背景** (`{colors.surface-hover}` — #F7F8FA): 表格行悬浮背景、选择器选项悬浮背景。
- **特色背景** (`{colors.surface-feature}` — #F0F1F5): 表格表头的背景。
- **分割线** (`{colors.hairline}` — #DCE0E6):1px 主要分割线
- **次要分割线** (`{colors.hairline-secondary}` — #EBECF0): 1px 表格行分割线
- **边框线** (`{colors.border}` — #CCD1D9): 最主要的边框色，次要按钮边框、输入框边框、选择器边框、搜索框边框、滚动条填充
- 

### 文字色
- **灰度** (`{colors.gray-default}` — #CCCCCC): 标准中性灰，用于次要场景的提示文字，如输入框提示文字。
- **一级文字** (`{colors.gray-d60}` — #000000): 主标题，重要文字
- **二级文字** (`{colors.gray-d50}` — #333333): 副标题，正文
- **三级文字** (`{colors.gray-d40}` — #666666): 描述、说明文字
- **弱化** (`{colors.gray-d30}` — #999999): 禁用文字、占位符
- **导航文字** (`{colors.graphite-black-l30}` — #3E4A59): 侧边导航上的黑色字
- **深色背景文字** (`{colors.text-on-dark}` — #FFFFFF): 深色背景上的文字，如全局导航上的文字
- **深色背景弱化文字** (`{colors.text-on-dark-weak}` — #FFFFFF40): 深色背景上降低透明度的白色

### 品牌渐变
- **波塞冬蓝&白俄罗斯绿渐变** — AI业务中的品牌渐变，GPT对话框的边框及消息发送按钮，从波塞冬蓝渐变到白俄罗斯绿。对应60度角度。

## 排版

### 字体家族
**苹方**：简洁现代的无衬线字体，中文。英文则用SF Pro display。用于苹果操作系统。
**思源黑体**：用于Windows、Linux等操作系统。英文则用Source Han Sans。
**阿里巴巴普惠体**：用于数字专用字体

### 层级

| Token | 大小 | 字重 | 行高 | 用途 |
|---|---|---|---|---|
| `{typography.display-8xl}` | 64px | 600 | 77px | 超大标题 |
| `{typography.display-5xl}` | 40px | 600 | 67px | 大标题 |
| `{typography.display-4xl}` | 32px | 500 | 38px | 页面大标题 |
| `{typography.display-3xl}` | 28px | 500 | 34px | 区域标题 |
| `{typography.title-lg}` | 24px | 500 | 33px | 卡片标题、模块标题 |
| `{typography.title-page}` | 20px | 500 | 28px | 列表标题、表单分组 |
| `{typography.title-model}` | 16px | 500 | 22px | 表格列标题、标签 |
| `{typography.title-card}` | 14px | 500 | 20px | 小标签、徽章文字 |
| `{typography.body-md}` | 14px | 400 | 22px | 默认正文 |
| `{typography.body-sm}` | 12px | 400 | 20px | 辅助文字、表格内容 |
| `{typography.caption}` | 12px | 400 | 17px | 说明文字、提示 |
| `{typography.caption-strong}` | 12px | 500 | 20px | 强调说明文字 |
| `{typography.code}` | 13px | 400 | 1.6 | 代码块、等宽文字 |
| `{typography.button}` | 14px | 400 | 22px | 按钮标签 |
| `{typography.nav-link}` | 12px | 400 | 20px | 导航菜单项 |

### 原则
- 标题使用字重500（中等），正文使用字重400（常规）
- 中文字重仅可在400/500/600中选择
- 数字场景使用等宽字体，确保对齐
- 保持字体层级简洁，不超过3种字体混排

## 布局

### 间距系统
- **基础单位：** 4px
- **Token：** `{spacing.xxs}` 4px · `{spacing.xs}` 8px · `{spacing.sm}` 12px · `{spacing.md}` 16px · `{spacing.lg}` 24px · `{spacing.xl}` 32px · `{spacing.xxl}` 48px
- **区域垂直内边距** 产品色块区域使用 `{spacing.lg}` (24px)
- **区域水平内边距** 列表页、详情页产品色块区域使用 `{spacing.xxl}` (48px)，dashboard页产品色块区域使用至 `{spacing.xl}` (32px)
- **色块内边距** 承载表格的产品色块内边距使用`{spacing.md}` (16px)，其他产品色块内边距使用 `{spacing.lg}` (24px)
- **卡片边距** 垂直方向`{spacing.sm}` (12px) ，水平方向 `{spacing.md}` (16px)

### 网格与容器
- 不带侧边导航时最大容器宽度：
  - 1366px 以下：1280px
  - 1920px 以上：1820px
- 带侧边导航时最大容器宽度：
  - 1366px 以下：1078px
  - 1920px 以上：1600px
- 详情页：
  - 垂直排列：面包屑 → 产品色块（产品详情字段） → 产品色块（产品相关列表或表单），间距8px，
  - 面包屑：直接置于产品色块区域内，无独立背景
- 列表页：
  - 垂直排列：面包屑 → 工具栏（操作按钮） → 产品色块（产品列表或表格），间距8px
  - 面包屑：直接置于产品色块区域内，无独立背景
  - 工具栏：直接置于产品色块区域内，无独立背景
- 带统计功能的列表页：
  - 面包屑与工具栏之间存在2~4个产品色块，展示统计信息，间距8px
  - 统计信息：位于产品色块内，水平排列，间距8px
  - 工具栏：移动至产品列表或表格上方，与产品列表或表格同处一个产品色块内，间距8px
- Dashboard页：采用24栅格布局，每行可最多显示4个产品色块，间距12px


### 区域布局

**带Header和侧边栏的标准布局：**

| 区域 | 宽度 | 高度 | 定位 |
|------|------|------|------|
| Header | 通栏撑满 | 52px | 固定顶部 |
| Sidebar | 224px（展开）/ 52px（收起） | 视口高度 | 固定左侧 |
| content | 自适应 | 自适应 | Sidebar右侧，Header下方 |

### 留白理念
sangfor cloud是一个基于云的平台，需要高效、实用的布局，但其设计理念又是简单高于一切，因此在布局上也会采取适度的留白，即能让用户高效的获取信息完成任务，又能感受到一定的呼吸感，不至于过于拥挤而产生紧张局促。

内容区域在某些情况下的内容较少，但为了保持布局的平衡，会使用产品色块填充剩余空间，在产品色块中保持留白

### 阴影层级

| 层级 | 处理方式 | 用途 |
|---|---|---|
| 0（平面） | 无阴影，`{colors.hairline}` 边框；如果是强调元素，无阴影，无边框，填充 `{colors.blue-gray-l70}` #fafbfc 背景 | 默认卡片，描边卡片 |
| 1（微弱） | rgba(0,0,0,0.08) 0px 1px 2px 0px | 小元素、次要组件，系统很少使用 |
| 2（卡片） | rgba(0,0,0,0.08) 0px 1px 4px 0px | 投影卡片、浮层默认 |
| 3（模拟） | rgba(0,0,0,0.16) 2px 6px 12px 0px | 悬浮球、下拉框 |
| 4（模态） | rgba(0,0,0,0.16) 0px 8px 24px rgba(0,0,0,0.16) | 模态框、重要浮层 |

层级哲学： **阴影强度反映元素层级**，距离越远阴影越大、模糊值越高。

### 装饰性深度
- 需要强调元素时，可使用`波塞冬蓝浅色`填充背景，以突出显示重要信息。
- 顶部导航的菜单展开时，在菜单区域增加顶部边框波塞冬蓝，1px,与导航栏分隔开。
- 表格冻结列时，在冻结列右侧增加阴影 rgba(0,0,0,0.08) 1px 0px 6px 0px,与表格内容分隔开；如果是表格最后一列，则增加左侧阴影 rgba(0,0,0,0.08) -1px 0px 6px 0px。
- 可以点击的卡片一般在鼠标操作时不改变阴影

## 形状

### 圆角比例

| Token | 值 | 用途 |
|---|---|---|
| `{rounded.xs}` | 2px | 产品色块，标签、徽章、小按钮、输入框 |
| `{rounded.sm}` | 4px | 按钮、输入框、选择器 |
| `{rounded.default}` | 6px | 卡片、下拉菜单、面板、提示 |
| `{rounded.lg}` | 8px | 弹窗、抽屉、大卡片 |
| `{rounded.xl}` | 16px | 分页器、胶囊按钮、圆角徽章 |
| `{rounded.circle}` | 50% | 头像、状态点、圆形按钮 |

**层级递进原则：**
- 外层圆角 ≥ 内层圆角
- 容器圆角 > 交互元素圆角
- 同类组件统一圆角

## 组件

### 顶部导航

**`top-nav`** — 深色导航栏固定在每个页面顶部。52px高，`{colors.graphite-black}` (#242A33) 背景。左侧承载导航菜单按钮、LOGO（深信服云计算平台）、数据中心定位、全局搜索；右侧承载快速导航（工单/告警/语言切换）和用户信息。菜单项使用 `{typography.nav-link}`（12px / 400）。

导航菜单按钮：52×52px正方形，默认背景 `{colors.graphite-black-l10}`，悬浮 `{colors.primary-light}`，禁用 `{colors.primary-disabled}`。

### 侧边导航

**`sidebar`** — 侧边导航栏固定在每个页面左侧。展开宽224px，收起宽52px，`{colors.gray-l60}` 背景，右侧阴影 `2px 0 4px 0` `{colors.graphite-black-l30}` (8%)。三段式结构：顶部固定区（52px，Logo图标28px + 子系统名称16px标题字）、菜单滚动区（一级导航40px高/14px标题字，二级导航36px高/12px正文，支持向下推拉折叠）、底部操作区（收纳切换按钮 + 用户信息）。表格页/表单页导航项采用模板全宽样式：外边距0、圆角0，hover/active 背景横向铺满侧边导航。

导航项状态：默认 `{colors.graphite-black-l30}` 文字，悬浮 `{colors.blue-gray-l50}` 背景，选中 `{colors.poseidon-blue-default}` 背景 + `{colors.gray-l60}` 白色文字。二级缩进与一级文字对齐，推拉动画 `height 0.2s ease-in-out`，收起态通过 Dropdown 侧向弹出二级菜单。

### 按钮

**`button-primary`** — 标志性波塞冬蓝CTA，主要操作。
- 背景 `{colors.poseidon-blue.default}`，文字 `{colors.gray.l60}`，图标 `{colors.gray.l60}`，边框 1px `{colors.poseidon-blue.d10}`，排版 `{typography.button}`，高度32px，圆角 `{rounded.sm}` (4px)，内边距 0 12px。
- 悬浮状态背景 `{colors.poseidon-blue.l10}`，边框 `{colors.poseidon-blue.default}`。
- 点击状态背景 `{colors.poseidon-blue.d10}`，边框 `{colors.poseidon-blue.d20}`。
- 聚焦状态背景 `{colors.poseidon-blue.l20}`，边框 `{colors.poseidon-blue.default}` 20%透明度 3px。
- 禁用状态全部40%透明度。

**`button-secondary`** — 白色背景按钮带蓝灰边框，次要操作。
- 背景 `{colors.gray.l60}`，文字 `{colors.gray.d50}`，图标 `{colors.graphite-black.l30}`，边框 1px `{colors.blue-gray.default}`，排版 `{typography.button}`，高度32px，圆角 `{rounded.sm}` (4px)，内边距 0 12px。
- 悬浮状态边框 `{colors.blue-gray.d20}`。
- 点击状态边框 `{colors.poseidon-blue.l20}`。

**`button-ghost`** — 透明背景边框按钮，层级关系场景。
- 背景 transparent，文字 `{colors.gray.d50}`，图标 `{colors.graphite-black.l30}`，边框 1px `{colors.blue-gray.default}`，排版 `{typography.button}`，高度32px，圆角 `{rounded.sm}` (4px)，内边距 0 12px。
- 悬浮状态边框 `{colors.blue-gray.d20}`。
- 点击状态边框 `{colors.poseidon-blue.d20}`。

**`button-link`** — 隐藏边框按钮，紧凑空间内联操作。
- 背景 transparent，文字 `{colors.gray.d50}`，图标 `{colors.graphite-black.l30}`，无边框。
- 悬浮状态边框 `{colors.blue-gray.d20}` (1px全框)。
- 点击状态边框 `{colors.poseidon-blue.d20}` (1px全框)。

**`button-text`** — 文字按钮，最小化视觉干扰。
- 背景 transparent，文字 `{colors.poseidon-blue.d10}`，图标 `{colors.poseidon-blue.d10}`，无边框，内边距 0。
- 悬浮状态文字 `{colors.poseidon-blue.l10}`。
- 点击状态文字 `{colors.poseidon-blue.d30}`。
- 禁用状态文字 `{colors.poseidon-blue.d10}` 40%透明度。

**`button-icon`** — 32px正方形单图标按钮，工具栏等简洁空间。
- 背景 transparent，图标 `{colors.graphite-black.l30}` (80%透明度)，无边框。
- 悬浮状态图标 `{colors.graphite-black.l30}` (100%)。
- 点击状态图标 `{colors.poseidon-blue.default}`。

按钮尺寸规格：小尺寸(24px/12px字体/圆角2px) · 默认(32px/14px字体/圆角4px) · 大尺寸(36px/14px字体/圆角4px)。图标统一16px。

### 卡片与容器

**`card-shadow`** — 投影卡片。背景 `{colors.gray.l60}` (#FFFFFF)，无边框，阴影 `shadow.md` (0px 1px 4px 0px rgba(0,0,0,0.08))，圆角 `{rounded.xs}` (2px)。

**`card-outline`** — 描边卡片。背景 `{colors.gray.l60}` (#FFFFFF)，边框 1px solid `{colors.blue-gray.default}`，无阴影，圆角 `{rounded.xs}` (2px)。同一页面禁止混用投影和描边卡片。

**`display-card-metric`** — 概览指标卡。展示核心数据指标（概要区：数值 40px/700 + 标签 14px/500 + 辅助信息 12px/400）。六种布局：单指标无标题/单指标+图表/单指标有标题/多指标主次/多指标同级/单指标+图表。有标题布局内容区边距：上8px 左右32px 下16px；无标题布局四边统一16px。趋势下降用 `{colors.belarus-green}` + `trend-down`，趋势上升用 `{colors.classical-red}` + `trend-up`。

**`display-card-chart`** — 分析图表卡。卡头三段式：标题区(必需) + 分析维度区(可选筛选) + 整体操作区(可选按钮)。内容区内边距：上8px 左右24px 下24px。图表色通过 Token 引用（`chart.primary` / `chart.warning` / `chart.positive` / `chart.negative` / `chart.track`）。


### 输入框与表单

**`text-input`** — 标准文本输入框，收集用户单行输入。
- 背景 `{colors.gray.l60}`，边框 1px `{colors.blue-gray.default}`，圆角 `{rounded.xs}` (2px)，文字 12px/400，占位符 `{colors.gray.default}`，输入值 `{colors.gray.d60}`。
- 标准尺寸(32px)：内边距 6px 12px；紧凑尺寸(24px)：内边距 2px 8px。
- 悬浮状态边框 `{colors.blue-gray.d20}`。
- 聚焦/点击状态边框 `{colors.poseidon-blue.default}`。
- 错误状态边框 `{colors.classical-red.default}`，错误提示浮层（绝对定位，距输入框下方4px，背景 `{colors.classical-red.default}`，文字 `{colors.gray.l60}` 12px）。
- 禁用状态背景 `{colors.gray.l20}`，占位符 `{colors.gray.d10}`，已有值 `{colors.gray.d40}`。

**`text-input-affix`** — 前后缀输入框，支持带下拉的前缀/后缀。
- 前后缀与输入区用 `{colors.blue-gray.l10}` 分隔线隔开。下拉图标 `vtv-icon-comp-angle-down` (16px)。下拉菜单：背景 `{colors.gray.l60}`，边框 1px `{colors.poseidon-blue.l20}`，阴影 `2px 4px 16px 0px shadow.stroke`，圆角 2px，距输入框 3px。

**`text-input-password`** — 密码输入框，支持明文/密文切换。
- 默认密文态图标 `vtv-icon-hide-password`，点击切换为 `vtv-icon-show-group` 明文显示。默认边框 `{colors.blue-gray.d20}`。

**`text-input-unit`** — 带单位输入框。
- 单位位于输入框外部右侧，间距 8px。

**`search-input`** — 搜索框，常规搜索与分类搜索。
- 背景 `{colors.gray.l60}`，边框 `{colors.blue-gray.default}`，圆角 2px。标准32px/紧凑24px。
- 搜索图标 `vtv-icon-search` (16px, `{colors.gray.default}`)，清除图标 `vtv-icon-comp-tip-close` (16px, `{colors.graphite-black.l30}`)。
- 聚焦/点击边框 `{colors.poseidon-blue.default}`，错误边框 `{colors.classical-red.default}`，禁用背景 `{colors.gray.l20}`。
- 分类搜索：左侧分类选择区（最小64px宽），下拉箭头 `vtv-icon-comp-angle-down`，分隔线 `{colors.blue-gray.l10}`。

**`form`** — 表单容器，收集和提交用户输入。
- 四种类型：常规表单 / 带标题表单 / 信息展示表单 / 带标题信息展示表单。
- 容器最小宽度 600px，内边距 上下16px 左右20px。表单项间距 8px，标签与控件间距 4px。
- 常规表单项高度 32px，标签 12px/400 `{colors.gray.d50}`；信息展示表单项高度 24px，标签 `{colors.gray.d40}`，值 `{colors.gray.d50}`，两列布局（列间距24px）。
- 标题 14px/600 `{colors.gray.d60}`，标题与表单项间距 24px。
- 对话框中表单：去除对话框内容区内边距，表单容器左右间距固定 20px，对话框最小宽度 640px。表单规范优先于对话框内容区规范。

### 对话框

**`modal`** — 模态对话框。背景 `{colors.surface-card}`，圆角 `{rounded.lg}` (8px)，阴影 `{shadows.xl}`，遮罩层 `{colors.overlay-mask}` (rgba(0,0,0,0.4))。

**关键规则**：对话框按钮顺序——**确认在左，取消在右**（与主流框架相反）。

### 下拉菜单

**`dropdown-menu`** — 下拉面板。背景 `{colors.gray-white}`，圆角 `{rounded.default}` (6px)，阴影 `2px 4px 16px rgba(0,0,0,0.2)`，边框 1px `{colors.primary-light}`。

### 标签与徽章

**`badge`** — 徽标数。背景 `{colors.error}`，文字 `{colors.text-on-primary}`，圆角 `{rounded.circle}` (50%)，高度16px，用于消息角标。

**`tag`** — 标签，标记属性和维度，支持属性展示、分类筛选、动态控制（可移除/添加）。
- 统一高度 18px，字体 12px，图标 12px，关闭按钮 8px。多标签水平/垂直间距 8px。
- 两种形态：矩形标签（圆角 2px）和圆角标签（圆角 20px，胶囊型）。
- 两种颜色类型：边框类（带边框+浅背景）和填充类（无边框+实色背景）。禁止混合两类样式。
- **边框类**：主色(文字 `{poseidon-blue.default}`，边框 `{poseidon-blue.l50}`，背景 `{poseidon-blue.l60}`) · 成功(`{belarus-green}`) · 普通告警(`{golden-yellow}`) · 重要告警(`{classical-red}`) · 轻微告警(`{golden-yellow.d40/l60/l70}`) · 中性(文字 `{graphite-black.l50}`，边框 `{blue-gray.l10}`，背景 `{blue-gray.l60}`) · 次要/失效(文字 `{blue-gray.d50}`，边框 `{blue-gray.l20}`，背景 `{blue-gray.l80}`)。
- **填充类**：主色(背景 `{poseidon-blue.default}`，文字 `{gray.l60}`) · 成功(`{belarus-green.default}`) · 普通告警(`{golden-yellow.default}`) · 重要告警(`{classical-red.d30}`) · 轻微告警(背景 `{lemon-yellow.l10}`，文字 `{lemon-yellow.d50}`) · 中性(背景 `{graphite-black.l60}`) · 次要/失效(背景 `{blue-gray.d10}`)。
- 关闭按钮交互：默认 60% 透明度，悬浮 100%，禁用 24%。与文字间距 4px。

### 表格

**`table`** — 基础表格，结构化展示多条数据集合。
- 表头背景 `{colors.blue-gray.l40}`，文本 12px/400 `{colors.gray.d60}`，边框 `{colors.blue-gray.l10}`；表体文本 12px/400 `{colors.gray.d50}`，边框 `{colors.blue-gray.l30}`。
- 斑马纹：白底 `{colors.gray.l60}` + 灰底 `{colors.blue-gray.l80}` 交替。悬浮底色 `{colors.blue-gray.l60}`，选中底色 `{colors.poseidon-blue.l60}`，禁用 40% 透明度。
- 两种尺寸：默认(表头34px/行高40px) · 小尺寸(表头26px/行高32px)。单元格水平内边距 8px，垂直居中。
- 列分区：功能区(复选框/序号40px) → 主体区 → 属性区 → 操作区(次要按钮 Small 24px，最多3个，超出折叠为「更多」下拉)。
- 边框规则：行边框仅下边框(表头上下均有)，列边框仅表头非首列有左边框，表体无列边框。
- 分页器必须调用分页器组件，靠右对齐，默认每页20条。

### 分页器

**`pagination`** — 分页组件，用于将大体量数据划分成多个页面展示，支持页面跳转和定位当前位置。
- **两种类型**：常规分页器（高度40px，功能完整） · 精简型分页器（高度32px，空间受限场景）。
- **颜色规范**：
  - 页码：默认透明背景，文字 `{colors.gray.d50}`；悬浮背景 `{colors.blue-gray.l60}`，文字 `{colors.gray.d50}`；选中背景 `{colors.poseidon-blue.l60}`，文字 `{colors.poseidon-blue.default}`；禁用40%透明度。
  - 省略号：图标 `vtv-icon-comp-more`，颜色 `{colors.graphite-black.l30}` 80%透明度。
  - 上一页/下一页按钮：默认图标 `{colors.graphite-black.l30}` 80%透明度；悬浮 `{colors.graphite-black.l30}`；点击 `{colors.poseidon-blue.default}`；禁用40%透明度。
  - 总条数：文字 `{colors.gray.d30}`。
- **尺寸规范**：
  - 页码：容器尺寸32×32px，按钮尺寸24×24px（实际可点击区域），圆角50%（圆形按钮），字体大小12px。
  - 省略号：容器尺寸32×32px，内边距8px，图标大小16×16px。
  - 上一页/下一页按钮：容器尺寸32×32px，按钮尺寸24×24px，图标大小16px。
  - 分页器主容器：常规分页器高度40px，内边距4px 8px；精简型分页器高度32px，内边距上下0左右8px，顶部边框1px solid `{colors.blue-gray.l20}`。
- **组成结构**：
  - 常规分页器：共X项 → 上一页按钮 → 页码 → 省略号 → 下一页按钮 → 每页X条 → 前往X页。
  - 精简型分页器：共X项 → 上一页按钮 → X/X（当前页输入框/总页数） → 下一页按钮。
- **交互约束**：跳转输入框按Enter回车键触发跳转，无需额外按钮；每页默认20条；分页器靠右对齐。

## 注意事项

### 应该做
- 所有颜色值通过Token引用，使用CSS变量格式 `--color-{颜色名}-{色阶}`
- 页面背景默认使用蓝灰度系统 (`blue-gray.l50` — #F5F6FA) 以增强科技感
- 主要操作按钮使用品牌蓝色 (`poseidon-blue.default`)
- 状态色专色专用：成功/警告/错误色仅用于对应状态
- 确保文字与背景对比度 ≥ 4.5:1，满足WCAG AA标准
- 渐变步数不超过3步，避免视觉混乱
- 使用24栅格系统规划页面布局
- 保持圆角层级关系：外层圆角 ≥ 内层圆角
- 对话框按钮顺序：确认在左，取消在右
- 图标使用系统统一图标库，前缀为 `vtv-icon-`

### 不应该做
- 不要硬编码颜色值，所有颜色必须通过Token引用
- 不要使用冷灰色或纯白色作为页面背景（应使用蓝灰度）
- 不要在彩色背景上使用彩色文字（对比度不足）
- 不要混用不同功能色表达相同状态
- 不要使用非标准圆角值（如3px、5px、7px）
- 不要内层圆角大于外层圆角
- 不要多层叠加阴影
- 不要使用彩色阴影
- 不要在 GoldenYellow 和 LemonYellow 基础色上使用白色文字

## 响应式行为

### 断点

| 断点 | 触发宽度 | 设备类型 | 布局行为 |
|------|----------|----------|----------|
| XS | <576px | 手机 | 侧边栏隐藏；单列堆叠；表格横向滚动 |
| SM | ≥576px | 大手机/平板 | 侧边栏收起（52px）；2列卡片 |
| MD | ≥768px | 平板 | 侧边栏可收起；表格适配；2列卡片 |
| LG | ≥992px | 笔记本/桌面 | 完整侧边栏（224px）；16栅格；2–3列卡片 |
| XL | ≥1200px | 桌面 | 完整侧边栏；24栅格；2–4列卡片 |
| 2XL | ≥1920px | 大桌面 | 最大内容宽度 1400px 居中；更大呼吸空间 |

#### 断点栅格配置

| 断点 | 屏幕宽度 | 栅格栏数 | 栏间距 | 页面边距 | 容器宽度 |
|------|----------|----------|--------|----------|----------|
| XS | <576px | 4栏 | 8px | 16px | 100% |
| SM | ≥576px | 8栏 | 16px | 24px | 540px |
| MD | ≥768px | 12栏 | 16px | 32px | 720px |
| LG | ≥992px | 16栏 | 24px | 40px | 960px |
| XL | ≥1200px | 24栏 | 24px | 40px | 1200px |
| 2XL | ≥1920px | 24栏 | 24px | 40px | 1400px |

### 触摸目标
- 按钮最小 32 × 32px（默认尺寸）
- 图标按钮 32 × 32px
- 输入框高度 32px
- 导航菜单按钮 52 × 52px

## 迭代指南

1. 一次专注于一个组件。
2. 直接引用组件名称和 Token
3. 现有组件的变体（`-hover`、`-active`、`-disabled`、`-focus`、`-error`）作为`components:`中的单独条目存在。
4. 波塞冬蓝 + 石墨烯黑 + 蓝灰度是三位一体。不要引入第四种主色调。
5. 对强调有疑问时：使用更大的字重或品牌蓝色，而非新增颜色。
6. 在所有界面保持波塞冬蓝作为主要 CTA

