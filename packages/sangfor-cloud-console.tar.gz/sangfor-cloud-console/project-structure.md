# 多页面项目结构

一个项目由多个单文件 HTML 组成，一个页面一个 HTML。

## 推荐结构

```text
project-name/
├── index.html
├── resource-list.html
├── resource-create.html
├── resource-detail.html
└── assets/
    ├── images/
    └── iconfont/
```

## 生成规则

- HTML 页面之间使用相对路径跳转。
- 每个 HTML 默认内联自己的 CSS 和 JavaScript。
- 图片和图标资源可以共享。
- 从功能介绍页模板生成页面时，需要同步复制模板依赖的 `image/` 资源，或改写为项目 `assets/images/` 下的相对路径。
- 从服务目录导航模板生成页面时，需要同步复制 `templates/service-catalog-nav/image/` 资源，或改写为项目公共资源路径。
- 多页面必须保持全局导航、侧边导航、选中态和视觉密度一致。
- 多页面项目中，每个带顶部导航的 HTML 都要自动关联服务目录浮层，点击左上角菜单按钮时行为一致。
- 当前页侧边导航项必须高亮。
- 如果生成的是样例项目，mock 数据写在页面内即可。
