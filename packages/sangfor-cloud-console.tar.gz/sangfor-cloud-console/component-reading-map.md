# 组件读取地图

组件详细规范保留在本 skill 的 `references/components`。生成页面时按需读取，不要一次性加载全部组件文档。

## 组件使用前置流程

生成页面正文前，先列出本页实际会用到的组件清单，再按清单读取对应文档。读取组件文档后，必须复用文档中的 DOM 层级、class、尺寸、状态、图标和交互规则；只允许替换字段名、选项、文案、默认值、mock 数据和业务事件。

生成交互前还必须按 `interaction-patterns.md` 列出本页动作清单，并标注动作载体。动作载体对应的组件文档必须读取：对话框读取 `对话框-Dialog.md`，抽屉读取 `抽屉-Drawer.md`，确认/错误反馈读取 `通知-Notification.md` 或 `对话框-Dialog.md`，加载过程读取 `加载状态-Loading.md`。

常用映射：

- 表单字段：`references/components/表单-From.md`
- 输入框：`references/components/输入框-Input.md`
- 数字输入框：`references/components/数字输入框-InputNumber.md`
- 选择器：`references/components/选择器-Select.md`
- 搜索框：`references/components/搜索框-Search.md`
- 按钮：`references/components/按钮-Button.md`
- 警告条或提示条：`references/components/警告条-Alert.md`
- 通知反馈：`references/components/通知-Notification.md`
- 错误或确认对话框：`references/components/对话框-Dialog.md`
- 右侧抽屉：`references/components/抽屉-Drawer.md`
- 加载态：`references/components/加载状态-Loading.md`
- 表格：`references/components/基础表格-basicTable.md`
- 分页：`references/components/分页器-Pagination.md`
- 标签：`references/components/标签-Tag.md`
- 步骤条：`references/components/步骤条-Steps.md`
- 对话框：`references/components/对话框-Dialog.md`
- 抽屉：`references/components/抽屉-Drawer.md`

禁止在未读取对应组件文档的情况下手写组件。禁止用原生 `<select>`、临时 `.input`、`.select`、`.alert`、`.notice`、`.tip` 等泛化 class 冒充设计系统组件。禁止通过业务区内联 `style` 拼出表单、选择器、提示条、按钮组、底部操作区等组件布局。

如果没有完全匹配的组件文档，选择最接近的已有组件组合，并在交付说明中说明映射关系；不得自造新组件规范或新增未登记的基础组件 class。

## 通用壳层

- 顶部导航：`references/components/全局导航-GlobalNavigation.md`
- 侧边导航：`references/components/侧边导航-SideNavigation.md`
- 面包屑：`references/components/面包屑-Breadcrumb.md`
- 标题栏：`references/components/标题栏-Title.md`
- 图标资源：`assets/iconfont/icon-symbols.html`
- 图标清单：`assets/iconfont/ICON_REFERENCE.md`
- 服务目录导航：`service-catalog-nav.md`

## 表格页

- 表格页模板：`references/components/表格页模板-TablePage.md`
- 工具栏：`references/components/工具栏-Toolbar.md`
- 基础表格：`references/components/基础表格-basicTable.md`
- 分页器：`references/components/分页器-Pagination.md`
- 搜索框：`references/components/搜索框-Search.md`
- 选择器：`references/components/选择器-Select.md`
- 空状态：`references/components/空状态-Empty.md`

## 表单页

- 面包屑：`references/components/面包屑-Breadcrumb.md`
- 表单：`references/components/表单-From.md`
- 输入框：`references/components/输入框-Input.md`
- 数字输入框：`references/components/数字输入框-InputNumber.md`
- 选择器：`references/components/选择器-Select.md`
- 日期选择器：`references/components/日期选择器-DatePicker.md`
- 上传：`references/components/上传-Upload.md`
- 步骤条：`references/components/步骤条-Steps.md`
- 按钮：`references/components/按钮-Button.md`

表单页读取顺序建议：

1. 先读取 `form-page.md` 和 `templates/form-page/form-page.html`，确认页面结构和 `.form-panel`、`.form-scroll`、`.form-body`、`.form-section`、`.form-footer` 的实际 DOM/CSS。
2. 再读取面包屑、表单、按钮；有步骤条时读取步骤条。
3. 根据字段类型读取输入框、选择器、日期选择器、上传等组件文档。
4. 最后按 `side-navigation.md` 和 iconfont 文件确认侧边导航、步骤条、面包屑等图标。

表单类页面、详情页、配置页和测试页的主内容卡片必须复用 `templates/form-page/form-page.html` 的 `.form-panel` 体系。如果组件文档中的“卡片”“面板”描述与模板 CSS 冲突，以模板 HTML 的实际 class 和 CSS 为准。不要把 `.panel`、`.card`、`.content-card`、`.compare-card` 或 `.trace-canvas` 当作这些页面的主内容卡片。

详情页、编辑页、配置页等下钻页面还必须读取 `references/components/面包屑-Breadcrumb.md`，并复用 `templates/form-page/form-page.html` 的面包屑区域。不要用 `.title-bar`、蓝色竖线标题、普通 H1 标题区或独立“返回 xxx”按钮替代面包屑。

## 功能介绍页

- 功能介绍页规则：`feature-intro-page.md`
- 功能介绍页模板：`templates/feature-intro-page/feature-intro-page.html`
- 顶部导航：`global-navigation.md`
- 图标资源：`assets/iconfont/icon-symbols.html`
- 对话框：`references/components/对话框-Dialog.md`
- 选择器：`references/components/选择器-Select.md`
- 输入框：`references/components/输入框-Input.md`
- 按钮：`references/components/按钮-Button.md`

功能介绍页读取顺序建议：

1. 先读取 `feature-intro-page.md` 和功能介绍页模板，确认页面正文规范。
2. 如果用户提供已有 HTML，保留正文结构，只按需求替换导航或局部组件。
3. 替换导航时读取 `global-navigation.md`、`service-catalog-nav.md` 和 iconfont 文件，确保左上角菜单按钮能打开服务目录。
4. 服务目录实现从 `templates/service-catalog-nav/service-catalog-nav.html` 抽取，作为壳层浮层接入，不作为功能介绍页正文。
5. 修改配置弹窗时，再读取对话框、选择器、输入框和按钮组件文档。

## 弹层和反馈

- 对话框：`references/components/对话框-Dialog.md`
- 抽屉：`references/components/抽屉-Drawer.md`
- 通知：`references/components/通知-Notification.md`
- 警告条：`references/components/警告条-Alert.md`
- 加载状态：`references/components/加载状态-Loading.md`

使用规则：

- 短创建/编辑/配置表单优先使用对话框，并继续读取表单、输入框、选择器、上传、按钮等字段组件。
- 行内查看、测试、诊断、地址、日志、结果对比优先使用抽屉，并继续读取抽屉内部实际组件。
- 删除、批量删除、重试、启停等危险或状态动作使用确认对话框或通知反馈，不生成页面。
- 提交校验失败时，字段组件必须有错误态；错误较多或阻断提交时，用对话框或通知列出字段错误。
